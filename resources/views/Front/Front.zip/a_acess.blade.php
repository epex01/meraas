@include('include.header')

        <main class="main">
            
            

<div id="banner" class="simple-banner style1  "
style="background-image: url(images/access_stock_bg.jpg);"
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>Access the Stock Market with&nbsp;<strong>Vertexmining Exchange</strong></p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p>Invest in some of the most influential companies</p></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="images/access_stock_img.png" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p>Invest in some of the most influential companies</p></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="access" class="simple-banner style2  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p>At Vertexmining Exchange, we’re committed to delivering a premium stock trading experience to anyone, regardless of your account size. We offer reliable trading platforms, reasonable fees, transparent pricing, and outstanding customer support.</p>

<h2>Access more than 600 stocks</h2>

<h4>from Europe, North America, and Asia</h4>
<div>

	<p><strong>Diversify your investments</strong></p>

	<p>Access a broad range of companies, from small to large capitalisations</p>
</div>
<div>

	<p><strong>Earn dividends</strong></p>

	<p>for holding shares on the ex. dividend date</p>
</div>
<div>

	<p><strong>Receive leading market research</strong></p>

	<p>to help you navigate the markets</p>
</div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

        
                     <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                <script src="https://widget.bm-tech.co/trade-currency-table?token=N78mzhVxWwnC4XKcMDY9UbCxHjyFBW3vYLJR9nOH3BJcUK" crossorigin="anonymous"></script>
            </div>
        
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p>At Vertexmining Exchange, we’re committed to delivering a premium stock trading experience to anyone, regardless of your account size. We offer reliable trading platforms, reasonable fees, transparent pricing, and outstanding customer support.</p>

<h2>Access more than 600 stocks</h2>

<h4>from Europe, North America, and Asia</h4>
<div>

	<p><strong>Diversify your investments</strong></p>

	<p>Access a broad range of companies, from small to large capitalisations</p>
</div>
<div>

	<p><strong>Earn dividends</strong></p>

	<p>for holding shares on the ex. dividend date</p>
</div>
<div>

	<p><strong>Receive leading market research</strong></p>

	<p>to help you navigate the markets</p>
</div></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        
            <div id="fees" class="list-with-icons style1 theme1"
     style="background-image: url(images/access_fees_bg.jpg);">
    <div class="container">
        <div class="list-with-icons__title title title_center" data-aos="fade-up"><p>Transparent Fees</p></div>

        
        
        <ul class="list-with-icons__list">
                    <li class="list-with-icons__list-item" data-aos="fade-right" data-aos-delay="550">
                <div class="list-with-icons__list-block">
                                        <div class="list-with-icons__list-icon">
                        <div class="list-with-icons__list-icon-inner" style="background-image: url(../storage/app/media/index)"></div>
                    </div>
                    <div class="list-with-icons__list-title">
                        <p>Commissions</p>

                    </div>
                    <div class="list-with-icons__list-text">
                        <p>Discount calculated over a current day rolling period.</p>

<p>$0 to $10,000 - 10%</p>

<p>$10,001 to $50,000 – 7.5%</p>

<p>&gt;$50,001 - 5%</p>

                    </div>
                                    </div>
            </li>
                    <li class="list-with-icons__list-item" data-aos="fade-right" data-aos-delay="700">
                <div class="list-with-icons__list-block">
                                        <div class="list-with-icons__list-icon">
                        <div class="list-with-icons__list-icon-inner" style="background-image: url(../storage/app/media/index)"></div>
                    </div>
                    <div class="list-with-icons__list-title">
                        <p>Custodian fee</p>

                    </div>
                    <div class="list-with-icons__list-text">
                        <p style="text-align: center;"><img src="images/access2.png" style="width: 300px;" class="fr-fic fr-dib"></p>

                    </div>
                                    </div>
            </li>
                    <li class="list-with-icons__list-item" data-aos="fade-right" data-aos-delay="850">
                <div class="list-with-icons__list-block">
                                        <div class="list-with-icons__list-icon">
                        <div class="list-with-icons__list-icon-inner" style="background-image: url(../storage/app/media/index)"></div>
                    </div>
                    <div class="list-with-icons__list-title">
                        <p>Data Fee and Platform Rental</p>

                    </div>
                    <div class="list-with-icons__list-text">
                        <p style="text-align: center;    margin-bottom: 5px;"><img src="images/access_free.png" style="width: 300px;" class="fr-fic fr-dib"></p>

                    </div>
                                    </div>
            </li>
                </ul>
    </div>
</div>        
            <div id="level" class="list-with-icons style1 theme1"
     style="">
    <div class="container">
        <div class="list-with-icons__title title title_center" data-aos="fade-up"><p>Take Your Investing to the Next Level</p></div>

        
        
        <ul class="list-with-icons__list">
                    <li class="list-with-icons__list-item" data-aos="fade-right" data-aos-delay="550">
                <div class="list-with-icons__list-block">
                                        <div class="list-with-icons__list-icon">
                        <div class="list-with-icons__list-icon-inner" style="background-image: url(images/access_level1.png)"></div>
                    </div>
                    <div class="list-with-icons__list-title">
                        <p>Complete the Account Registration, It only takes a few minutes </p>

                    </div>
                    <div class="list-with-icons__list-text">
                        

                    </div>
                                    </div>
            </li>
                    <li class="list-with-icons__list-item" data-aos="fade-right" data-aos-delay="700">
                <div class="list-with-icons__list-block">
                                        <div class="list-with-icons__list-icon">
                        <div class="list-with-icons__list-icon-inner" style="background-image: url(images/access_level2.png)"></div>
                    </div>
                    <div class="list-with-icons__list-title">
                        <p>Fund Your Account Credit
	<br>card, EFT and more! </p>

                    </div>
                    <div class="list-with-icons__list-text">
                        

                    </div>
                                    </div>
            </li>
                    <li class="list-with-icons__list-item" data-aos="fade-right" data-aos-delay="850">
                <div class="list-with-icons__list-block">
                                        <div class="list-with-icons__list-icon">
                        <div class="list-with-icons__list-icon-inner" style="background-image: url(images/access_level3.png)"></div>
                    </div>
                    <div class="list-with-icons__list-title">
                        <p>Get Started Trading and Access a variety of Opportunities </p>

                    </div>
                    <div class="list-with-icons__list-text">
                        

                    </div>
                                    </div>
            </li>
                </ul>
    </div>
</div>        
            
<div id="button-block" class="simple-text style1   "
     style="">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"></div>

                <div class="simple-text__button" data-aos="fade-up" data-aos-delay="400">
            <a href="https://moneyroute-exchange.com/account"  class="btn btn-orange">Open Account</a>

            <div class="warning-text">
                
            </div>
        </div>
        
            </div>
</div>        
            
<div id="broker" class="simple-block left theme1 style1  " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/access_laptop.png" alt="Trusted broker of" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>Trusted broker of</p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p class="investing">
	<a href="#" rel="noopener noreferrer" target="_blank"><img src="images/access_inversting.png" style="width: 300px;" class="fr-fic fr-dib"></a></p>

<p class="apps">
	<a href="https://vintag-markets.com/#app-coningsoon" rel="noopener noreferrer" target="_blank"><img src="images/access_appstore.png" style="max-width: 185px;" class="fr-fic fr-dib"></a>
	<a href="https://vintag-markets.com/#app-coningsoon" rel="noopener noreferrer" target="_blank"><img src="images/access_googleplay.png" style="max-width: 185px;" class="fr-fic fr-dib"></a></p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
    
  
            <div id="social-links" class="social-links" >
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>

<script>
$('.lazy').lazy({
    scrollDirection: 'vertical',
    effect: 'fadeIn',
    visibleOnly: true,
  beforeLoad: function(element){
      console.log('image is about to be loaded');
  },
  afterLoad: function(element) {
      console.log('image was loaded successfully');
  },
  onError: function(element) {
      console.log('image could not be loaded');
  },
  onFinishedAll: function() {
      console.log('finished loading elements');
      console.log('lazy instance is about to be destroyed')
  }
});
</script>

<script>
    $('#level .list-with-icons__list-icon').on('click', function (){
        $(".btn-orange")[0].click();
    });
</script>


<script>/*console.log();*/</script>


<style>.container {
        max-width: 1200px !important;
    }
    /*.header {
        position: relative !important;
        background: #090909 !important;
        animation: none !important;
        padding: 10px 0;
    }*/
   /* .header .container {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .lang-switch__list-item {
        display: none;
    }
    .lang-switch__list-item[data-request-data="locale: 'de'"] {
        display: block;
    }
    .lang-switch__list-item[data-request-data="locale: 'en'"] {
        display: block;
    }*/


    #banner {
        padding: 10px 0 0;
        overflow: hidden;
        background-color: #141414;
    }
    #banner .container {

    }
    #banner .simple-banner__content {
        width: 70%;
    }
    #banner .simple-banner__desktop {
        display: block !important;
    }
    #banner .simple-banner__mobile {
        display: none !important;
    }
    #banner .simple-banner__content-wrap {
        max-width: 100%;
    }
    #banner .simple-banner__title {
        color: #FFFFFF;
        font-size: 60px;
    }
    #banner .simple-banner__title strong {
        color: #aa8a5c;
    }
    #banner .simple-banner__text {
        color: #FFFFFF;
        font-size: 22px;
        margin-bottom: 80px;
    }
    #banner .simple-banner__image {
        margin-bottom: -20px;
        margin-right: -100px;
    }
    #banner .simple-banner__image img {
        position: relative;
        animation: move-img 2s ease-in-out infinite;
        animation-delay: 2s;
    }

    @keyframes move-img {
        0% {
            bottom: 0;
        }
        50% {
            bottom: -20px;
        }
        100% {
            bottom: 0;
        }
    }

    #banner .btn-orange {
        font-size: 23px;
        text-transform: uppercase;
        padding: 22px 40px;
    }

    #access {
        padding-top: 20px;
        padding-bottom: 45px;
        background: #FFFFFF;
        overflow: hidden;
    }
    #access .container {
        min-height: auto;
        position: relative;
    }
    #access .container:before {
        content: '';
        display: block;
        border-radius: 50%;
        position: absolute;
        top: -210px;
        right: -430px;
        background: #fafafa;
        width: 650px;
        height: 650px;
    }
    #access .simple-banner__content {
        order: 2;
        padding: 0 0 0 20px;
    }
    #access .simple-banner__text {
        text-align: left;
        font-size: 15px;
    }
    #access h2 {
        margin-top: 75px;
        font-weight: bold;
        font-size: 60px;
    }
    #access h4 {
        margin-bottom: 20px;
    }
    #access .simple-banner__text div {
        margin-bottom: 20px;
    }
    #access .simple-banner__text div p {
        margin-top: 0;
    }
    #access .simple-banner__text div p:last-child {
        font-size: 12px;
    }
    #access .simple-banner__image {
        width: 50%;
        padding-right: 20px;
    }

    #fees {
        position: relative;
        overflow: hidden;
        color: #FFFFFF;
        padding-top: 50px;
        padding-bottom: 60px;
    }
    #fees .list-with-icons__title {
        text-align: left;
        font-size: 60px;
        font-weight: bold;
        margin-bottom: 50px;
    }
    #fees .list-with-icons__title:after {
        display: none;
    }
    #fees .list-with-icons__list {
        margin-left: 0;
    }
    #fees .list-with-icons__list-item {
        width: 33.333%;
        padding: 0;
    }
    #fees .list-with-icons__list-icon {
        display: none;
    }
    #fees .list-with-icons__list-block {
        display: flex;
        justify-content: flex-end;
        flex-direction: column;
        max-width: 100%;
        height: 100%;
    }
    #fees .list-with-icons__list-title {
        order: 3;
        color: #ffffff;
        max-width: 100%;
        width: 100%;
        font-weight: normal;
    }
    #fees .list-with-icons__list-text {
        text-align: left;
        color: #fff;
        font-size: 16px;
    }
    #fees .list-with-icons__list-text img {
        width: auto !important;
    }

    #level {
        background: #FFFFFF;
        padding-top: 55px;
        padding-bottom: 0;
    }
    #level .list-with-icons__title {
        font-size: 60px;
        font-weight: bold;
        margin-bottom: 50px;
    }
    #level .list-with-icons__title:after {
        display: none;
    }
    #level .list-with-icons__list-item {
        width: 33.3333%;
    }
    #level .list-with-icons__list-title {
        color: #000000;
        font-size: 16px;
    }
    #level .list-with-icons__list-icon {
        -webkit-box-shadow: none;
        -moz-box-shadow: none;
        -o-box-shadow: none;
        box-shadow: none;
        background: none;
        width: 190px;
        height: 150px;
        margin-bottom: 0;
        cursor: pointer;
    }
    #button-block {
        padding-top: 15px;
        padding-bottom: 20px;
        background: #FFFFFF;
    }
    #button-block .simple-text__button {
        padding: 0;
        margin: 0;
    }
    #button-block .btn-orange {
        font-size: 23px;
        text-transform: uppercase;
        padding: 22px 40px;
    }

    #broker {
        background: none;
        padding-top: 50px;
        padding-bottom: 50px;
    }
    #broker .simple-block__content {
        padding: 0 0 0 45px;
    }
    #broker .simple-block__title:after {
        display: none;
    }
    #broker .simple-block__text img {
        width: auto !important;
    }
    #broker .simple-block__text a + a {
        margin-left: 20px;
    }
    #broker .investing {
        margin-bottom: 50px;
    }
    #broker .investing img {
        width: 310px !important;
    }
    #broker .apps {
        display: flex;
    }

    #risk {
        background: #FFFFFF;
        font-size: 18px;
        padding-bottom: 45px;
    }

    #risk .simple-text__title {
        text-align: left;
        border-bottom: 1px solid #bb4311;
        font-size: 18px;
        margin: 0 0 15px;
        padding-bottom: 7px;
    }
    #risk .simple-text__title:after {
        display: none;
    }
    #risk .grey {
        background: #fafafa;
        border-left: 1px solid #bb4311;
        padding-left: 3px;
    }

    .access-stocks-footer {
        font-size: 18px;
        padding: 15px 0;
    }
    .access-stocks-footer .container {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .social {
        display: flex;
        list-style: none;
    }

    .social li+li {
        margin-left: 10px;
    }
</style>
<style>@media (max-width: 1024px) {
        #banner {
            text-align: center;
            padding-top: 110px;
        }
        #banner .simple-banner__content {
            width: 100%;
        }
        #banner .simple-banner__title {
            font-size: 45px;
        }
        #banner .simple-banner__image {
            margin-right: 0;
        }
        #banner .simple-banner__image {
            max-width: 400px;
        }


        #access .simple-banner__content {
            padding: 0;
        }
        #access .simple-banner__image {
            padding: 0;
            width: 100%;
        }
        #access h2 {
            font-size: 45px;
        }
        #access .simple-banner__text {
            text-align: center;
        }

        #fees {
            padding-bottom: 20px;
        }
        #fees .list-with-icons__title {
            font-size: 45px;
        }

        #level .list-with-icons__title {
            font-size: 45px;
        }
        #level .list-with-icons__list-icon-inner {
            background-size: contain;
        }

        #broker {
            padding-top: 0;
        }
        #broker .simple-block__content {
            padding: 0;
            text-align: center;
        }
        #broker .investing {
            text-align: center;
        }
        #broker .apps {
            justify-content: center;
        }
        #broker .simple-block__title {
            font-weight: bold;
        }
    }

    @media (max-width: 768px) {
        #banner .simple-banner__title {
            font-size: 30px;
        }
        #banner .simple-banner__text {
            font-size: 14px;
            margin-bottom: 50px;
        }
        #banner .btn-orange {
            font-size: 16px;
            padding: 14px 30px;
        }
        #banner .simple-banner__image {
            max-width: 250px;
        }

        #access h2 {
            font-size: 30px;
            margin-bottom: 15px;
        }
        #access h4 {
            font-size: 16px;
        }

        #fees {
            padding-top: 35px;
            padding-bottom: 0px;
        }
        #fees .list-with-icons__title {
            font-size: 30px;
            text-align: center;
            margin-bottom: 30px;
        }
        #fees .list-with-icons__list-item {
            width: 100%;
            margin-bottom: 35px;
        }
        #fees .list-with-icons__list {
            flex-direction: column;
            align-items: center;
        }
        #fees .list-with-icons__list-title p{
            text-align: center !important;
        }
        #fees .list-with-icons__list-text {
            font-size: 14px;
            text-align: center;
        }

        #level {
            padding-top: 35px;
        }
        #level .list-with-icons__title {
            font-size: 30px;
            margin-bottom: 30px;
        }
        #level .list-with-icons__list {
            flex-direction: column;
            align-items: center;
        }
        #level .list-with-icons__list-item {
            width: 100%;
            margin-bottom: 35px;
        }
        #level .list-with-icons__list-title {
            max-width: 100%;
        }
        #level .list-with-icons__list-block {
            max-width: 205px;
        }
        #level .list-with-icons__list-icon {
            width: 135px;
            height: 120px;
        }

        #button-block .btn-orange {
            font-size: 16px;
            padding: 14px 30px;
        }

        #broker {
            padding-bottom: 15px;
        }
        #broker .simple-block__title {
            font-size: 35px;
        }
        #broker .investing img{
            width: 300px !important;
        }
        #broker .apps img{
            width: 130px !important;
        }

        #risk {
            font-size: 16px;
        }
        #risk .simple-text__title {
            font-size: 16px;
        }

        .access-stocks-footer .container {
            justify-content: center;
        }
        .access-stocks-footer__text {
            display: none;
        }
    }
</style>        </main>

        
     @include('include.footer')