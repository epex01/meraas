@include('include.header')

<main class="main">
            
            

<div id="Deposits &amp; Withdrawals" class="simple-banner style5  "
style="background-image: url(images/deposits-banner-new2-min.png);background-color: #280a00;"
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Deposits &amp; Withdrawals</h1></div>
                
                <div class="">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><div style="max-width: 600px;">

	<p>Deposit and withdraw from your trading account using Europe’s more reliable payment methods.</p>
</div></div>

                                        <div class="simple-banner__image" data-aos="fade-up" data-aos-delay="200">
                        <img src="images/deposits-banner-new2-min.png" alt="Deposits &amp;amp; Withdrawals">
                    </div>
                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try On Demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Start Trading</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p><span style="color: rgb(239, 239, 239);">* Start Trading Now.</span></p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><div style="max-width: 600px;">

	<p>Deposit and withdraw from your trading account using Europe’s more reliable payment methods.</p>
</div></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try On Demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Start Trading</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p><span style="color: rgb(239, 239, 239);">* Start Trading Now.</span></p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            <div id="Reliable Payment Methods" class="list-with-icons-table style2"
     style="background-image: url(images/Reliable%20Payment%20Methods-min.jpg);">
    <div class="container">
        <div class="list-with-icons-table__title title title_center" data-aos="fade-up"><p><span style="font-weight:800;color:#aa8a5c;">Reliable Payment Methods</span></p></div>

                <div class="list-with-icons-table__text" data-aos="fade-up" data-aos-delay="100"><p style="text-align: center;">All deposits to your Vertexmining Exchange trading account are processed by fully licensed and authorised payment processors based in Europe and PCI compliant. You can initiate deposits and withdrawals from our reliable, user-friendly and absolutely secure client portal, which allows you to make swift account funding operations.</p></div>
        
        
        
                <div class="list-with-icons-table__table" data-aos="fade-up" data-aos-delay="100">
                        <div class="list-with-icons-table__table-row">
                <div class="list-with-icons-table__table-item"><b>Bank Transfer</b></div>
                <div class="list-with-icons-table__table-item">Transfer money to the Company segregated Clients' accounts</div>
                                            </div>
                        <div class="list-with-icons-table__table-row">
                <div class="list-with-icons-table__table-item"><b>Visa/MasterCard</b></div>
                <div class="list-with-icons-table__table-item">Processed by SafeCharge, authorised by the Central Bank of Cyprus</div>
                                            </div>
                        <div class="list-with-icons-table__table-row">
                <div class="list-with-icons-table__table-item"><b>PayPal</b></div>
                <div class="list-with-icons-table__table-item">Licensed by the Commission de Surveillance du Secteur Financier (CSSF) in Luxembourg</div>
                                            </div>
                        <div class="list-with-icons-table__table-row">
                <div class="list-with-icons-table__table-item"><b>Skrill</b></div>
                <div class="list-with-icons-table__table-item">Regulated by the Financial Conduct Authority</div>
                                            </div>
                        <div class="list-with-icons-table__table-row">
                <div class="list-with-icons-table__table-item"><b>Klarna/SOFORT</b></div>
                <div class="list-with-icons-table__table-item">Operated by Klarna Bank AB (publ), authorised and regulated by the Swedish Financial Supervisory Authority</div>
                                            </div>
                        <div class="list-with-icons-table__table-row">
                <div class="list-with-icons-table__table-item"><b>iDEAL/PPRO</b></div>
                <div class="list-with-icons-table__table-item">Based in the Netherlands</div>
                                            </div>
                        <div class="list-with-icons-table__table-row">
                <div class="list-with-icons-table__table-item"><b>Giropay</b></div>
                <div class="list-with-icons-table__table-item">Based in Germany</div>
                                            </div>
                        <div class="list-with-icons-table__table-row">
                <div class="list-with-icons-table__table-item"><b>Bancontact/Mister Cash</b></div>
                <div class="list-with-icons-table__table-item">Authorised financial institution regulated by the Bank of Lithuania (BoL register number 25)</div>
                                            </div>
                    </div>
        
            </div>
</div>        
            <div id="deposit" class="slider-info" style="">

    <div class="container">
        <div class="slider-info__title title title_center" data-aos="fade-up"><p><span style="font-weight:800;color:#aa8a5c;">Deposit &amp; Withdrawal Information</span></p></div>
        <div data-aos="fade-up">
        <div class="slider-info__slider" data-aos="fade-up">
                        <div class="slider-info__slide">
                <div class="slider-info__slide-img">
                    <img src="images/bank_transfer.png" alt="
">
                </div>
                <div class="slider-info__slide-title">
                Bank Transfer
                </div>
            </div>
                        <div class="slider-info__slide">
                <div class="slider-info__slide-img">
                    <img src="images/visa_master.png" alt="
">
                </div>
                <div class="slider-info__slide-title">
                Visa/MasterCard
                </div>
            </div>
                        <div class="slider-info__slide">
                <div class="slider-info__slide-img">
                    <img src="images/paypal.png" alt="
">
                </div>
                <div class="slider-info__slide-title">
                PayPal
                </div>
            </div>
                        <div class="slider-info__slide">
                <div class="slider-info__slide-img">
                    <img src="images/skrill.png" alt="
">
                </div>
                <div class="slider-info__slide-title">
                Skrill
                </div>
            </div>
                        <div class="slider-info__slide">
                <div class="slider-info__slide-img">
                    <img src="images/sofart.png" alt="
">
                </div>
                <div class="slider-info__slide-title">
                Klarna/SOFORT
                </div>
            </div>
                        <div class="slider-info__slide">
                <div class="slider-info__slide-img">
                    <img src="images/deal.png" alt="
">
                </div>
                <div class="slider-info__slide-title">
                iDEAL
                </div>
            </div>
                        <div class="slider-info__slide">
                <div class="slider-info__slide-img">
                    <img src="images/giropay.png" alt="
">
                </div>
                <div class="slider-info__slide-title">
                Giropay
                </div>
            </div>
                    </div>

                <div class="slider-info__tabs active" data-number-block="1">
            <div class="slider-info__tabs-head">
                                <div data-number-tab="1" class="slider-info__tabs-heading active">
                    Deposit
                </div>
                                <div data-number-tab="2" class="slider-info__tabs-heading ">
                    Withdrawal
                </div>
                            </div>

            <div class="slider-info__tabs-content">
                        <div data-number-tab="1" class="slider-info__tabs-block active">
                <table style="width: 100%;">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p>Currency:</p>
			</td>
			<td style="width: 50.0000%;">

				<p>EUR, USD, GBP</p>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">

				<p>Min. transaction:</p>
			</td>
			<td style="width: 50.0000%;">250
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">

				<p>Max. transaction:</p>
			</td>
			<td style="width: 50.0000%;">50,000
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">3-10 business days
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        <div data-number-tab="2" class="slider-info__tabs-block ">
                <table style="width: 100%;">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR, USD, GBP
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">24 hours
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        </div>
        </div>
                <div class="slider-info__tabs " data-number-block="2">
            <div class="slider-info__tabs-head">
                                <div data-number-tab="1" class="slider-info__tabs-heading active">
                    Deposit
                </div>
                                <div data-number-tab="2" class="slider-info__tabs-heading ">
                    Withdrawal
                </div>
                            </div>

            <div class="slider-info__tabs-content">
                        <div data-number-tab="1" class="slider-info__tabs-block active">
                <table style="width: 100%;">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR, USD, GBP
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">250
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">USD 100,000
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">Instant
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        <div data-number-tab="2" class="slider-info__tabs-block ">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR, USD, GBP
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">24 hours
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        </div>
        </div>
                <div class="slider-info__tabs " data-number-block="3">
            <div class="slider-info__tabs-head">
                                <div data-number-tab="1" class="slider-info__tabs-heading active">
                    Deposit
                </div>
                                <div data-number-tab="2" class="slider-info__tabs-heading ">
                    Withdrawal
                </div>
                            </div>

            <div class="slider-info__tabs-content">
                        <div data-number-tab="1" class="slider-info__tabs-block active">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR, USD, GBP
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">250
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">30,000
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">Instant
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        <div data-number-tab="2" class="slider-info__tabs-block ">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR, USD, GBP
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">24 hours
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        </div>
        </div>
                <div class="slider-info__tabs " data-number-block="4">
            <div class="slider-info__tabs-head">
                                <div data-number-tab="1" class="slider-info__tabs-heading active">
                    Deposit
                </div>
                                <div data-number-tab="2" class="slider-info__tabs-heading ">
                    Withdrawal
                </div>
                            </div>

            <div class="slider-info__tabs-content">
                        <div data-number-tab="1" class="slider-info__tabs-block active">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR, USD, GBP
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">250
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">30,000
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">Instant
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        <div data-number-tab="2" class="slider-info__tabs-block ">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR, USD, GBP
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">24 hours
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        </div>
        </div>
                <div class="slider-info__tabs " data-number-block="5">
            <div class="slider-info__tabs-head">
                                <div data-number-tab="1" class="slider-info__tabs-heading active">
                    Deposit
                </div>
                                <div data-number-tab="2" class="slider-info__tabs-heading ">
                    Withdrawal
                </div>
                            </div>

            <div class="slider-info__tabs-content">
                        <div data-number-tab="1" class="slider-info__tabs-block active">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR, GBP, CHF
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">250
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">EUR 12,000
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">Instant
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        <div data-number-tab="2" class="slider-info__tabs-block ">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">24 hours
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        </div>
        </div>
                <div class="slider-info__tabs " data-number-block="6">
            <div class="slider-info__tabs-head">
                                <div data-number-tab="1" class="slider-info__tabs-heading active">
                    Deposit
                </div>
                                <div data-number-tab="2" class="slider-info__tabs-heading ">
                    Withdrawal
                </div>
                            </div>

            <div class="slider-info__tabs-content">
                        <div data-number-tab="1" class="slider-info__tabs-block active">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">250
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">EUR 20,000
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">Instant
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        <div data-number-tab="2" class="slider-info__tabs-block ">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">24 hours
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        </div>
        </div>
                <div class="slider-info__tabs " data-number-block="7">
            <div class="slider-info__tabs-head">
                                <div data-number-tab="1" class="slider-info__tabs-heading active">
                    Deposit
                </div>
                                <div data-number-tab="2" class="slider-info__tabs-heading ">
                    Withdrawal
                </div>
                            </div>

            <div class="slider-info__tabs-content">
                        <div data-number-tab="1" class="slider-info__tabs-block active">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">USD
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">250
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">EUR 10,000
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">Instant
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        <div data-number-tab="2" class="slider-info__tabs-block ">
                <table style="width: 100%; margin-left: calc(0%);">
	<tbody>
		<tr>
			<td style="width: 50.0000%;">

				<p dir="ltr">Currency:</p>
			</td>
			<td style="width: 50.0000%;">EUR
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Min. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Max. transaction:
				<br>
			</td>
			<td style="width: 50.0000%;">None
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 50.0000%;">Processing time:
				<br>
			</td>
			<td style="width: 50.0000%;">24 hours
				<br>
			</td>
		</tr>
	</tbody>
</table>

            </div>
                        </div>
        </div>
                </div>

                <div class="slider-info__bottom-text" data-aos="fade-up" data-aos-delay="100"><p><span lang="en-US">* Please note that the processing time for the
deposit methods may vary depending on the payment service provider
and method selected.</span></p></div>
            </div>
</div>        
            
<div id="Additional Deposit Information" class="simple-block right theme1 style1 small_padding  wide_content round_image " style="background: #f3f3f3;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/deposits-img.jpg" alt="Additional Deposit Information" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>Additional <span style="font-weight:800;color:#aa8a5c;">Deposit Information</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>Vertexmining Exchange does not charge any fees for processing deposits or withdrawals. However, the payment provider you choose to use might set their own fees outside of our control. To be certain of the possible charges for depositing or withdrawing funds from your Vertexmining Exchange trading, check the terms of the payment method you intend to use.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>Limitations on the amount you can send may be lower than specified in the table above due to the payment method’s conditions.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>To deposit funds via a debit/credit card, we require a clear scanned copy of your credit/debit card (front and back). The scan should clearly show the cardholder’s name, bank of issue, expiry dates, and the first and last four digits of the card; you should cover the CVV number. Alternatively, you can provide a credit/debit card statement showing the details mentioned earlier.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="900">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>We only accept deposits from bank accounts and credit/debit cards issued to our customers. Vertexmining Exchange does not accept funds from a third-party.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="1050">
                        <div class="simple-block__list-caption">
</div>
                                                
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                                                
                                <div class="simple-block__link simple-block__link_center" data-aos="fade-left" data-aos-delay="300">
                                        <a href="register" class="btn btn-big btn-orange">Open Account</a>
                    <div class="warning-text">
                        <p>* Start Trading Now.</p>
                    </div>
                    
                                    </div>
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="Additional Withdrawal Information" class="simple-block left theme1 style1 small_padding  wide_content round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/deposits-info.jpg" alt="Additional Withdrawal Information" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>Additional <span style="font-weight:800;color:#aa8a5c;">Withdrawal Information</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>All withdrawals will be made in the same currency as your trading account.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>All withdrawal requests will be processed on the same day as the request is made, or the following working day if your request is made outside of normal working hours. Kindly note, the time needed for the funds to reach your account may vary, depending on the selected payment method.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>Withdrawals should be made using the same method used to fund your trading account and to the same remitter. We reserve the right to decline a withdrawal via a particular payment method and suggest using an alternative method for you to make a new withdrawal request.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="900">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>Confirmation of your withdrawal of funds from your Vertexmining Exchange trading account will always be sent to you via email.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="1050">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>We only allow withdrawing funds from your trading account back to you. We do not allow customers to withdraw funds to a third party.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="1200">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>The amount you request to withdraw shall not exceed the balance or amount of funds available in your trading account.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="1350">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>Your withdrawal will not be processed or confirmed until your account verification documents have been received and approved by us.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="1500">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>Please note that we do not cover any charges/fees from your bank or payment provider. They are applied to each client, based on the amount withdrawn and according to the payment method.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            <div id="daw-social-links" class="social-links" >
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

       @include('include.footer')