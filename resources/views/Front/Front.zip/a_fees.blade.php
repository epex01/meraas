@include('include.header')

<main class="main">
            
            

<div id="banner" class="simple-banner style5  "
style="background-image: url(images/fees-banner-new2-min.png);"
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Trading Fees</h1></div>
                
                <div class="">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><div style="max-width:565px;">

	<p>We offer a range of competitive and compelling investment products spanning various asset classes. The costs associated with trading CFDs are commissions, spreads and swaps.</p>
</div></div>

                                        <div class="simple-banner__image" data-aos="fade-up" data-aos-delay="200">
                        <img src="images/fees-banner-new2-min.png" alt="Trading Fees">
                    </div>
                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Start trading</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><div style="max-width:565px;">

	<p>We offer a range of competitive and compelling investment products spanning various asset classes. The costs associated with trading CFDs are commissions, spreads and swaps.</p>
</div></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Start trading</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            
<div id="сommissions" class="simple-block right theme1 style1 small_padding  empty_padding_bottom round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/fees-commision-min.jpg" alt="Commissions" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title title_center" data-aos="fade-left"><p><span style="font-weight:800;color:#aa8a5c;">Commissions</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>A commission is a fee charged for every trade you make. Trading commissions are charged in two parts, as a CFD consists of two transactions, an opening deal and a closing deal. Commissions are determined based on the size of your order. At vertex mining exchange, we charge a fee for each Lot traded. The price you pay depends on your trading account, the most you’ll pay is 12 dollars per lot, the least you’ll pay is 7 dollars per lot. We offer lower prices to more active traders who maintain larger accounts. If the commission to trade with your account is 10 dollars per lot, and you open 0.5 Lots, the trade will cost 5 dollars. Understandably, commissions affect the profitability of your trades.</p></div>

                
                
                
                                                                
                                <div class="simple-block__link simple-block__link_center" data-aos="fade-left" data-aos-delay="300">
                    
                                        <a href="tradingaccounts.html" class="btn btn-little btn-orange">View account comparison</a>
                                    </div>
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="spreads" class="simple-block left theme1 style1  empty_padding_top empty_padding_bottom round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/fees-spreads-min.jpg" alt="Spreads" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title title_center" data-aos="fade-left"><p><span style="font-weight:800;color:#aa8a5c;">Spreads</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>The spread is the difference between the buy and sell quotes you see in the platform. As a broker, vertex mining exchange makes a profit by marking up on the wholesale prices we can access from institutional brokers. Essentially what it means is we sell to you at slightly higher prices, and we buy from you at slightly lower prices. The spread is a cost which is less apparent but still very important as it influences your profitability since the larger the spread, the more the market has to move before your position can break even and move in profitable territory. How much we markup on the bid and ask price depends on your trading account. Premium accounts have better conditions.</p></div>

                
                
                
                                                                
                                <div class="simple-block__link simple-block__link_center" data-aos="fade-left" data-aos-delay="300">
                    
                                        <a href="tradingaccounts.html" class="btn btn-little btn-orange">View account comparison</a>
                                    </div>
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="swaps" class="tariffs style7  "
     style="background-image: url(images/swaps-fees-min.jpg);     ">

    <div class="container">
                <div class="tariffs__title title title_center" data-aos="fade-up"><p>Swaps</p></div>
                        <div class="tariffs__subtitle" data-aos="fade-up" data-aos-delay="100"><p>Swaps are charged when you keep a position open overnight. At 22:00, as the New York trading session rolls into the Australian trading session, a commission is charged or paid to traders holding positions at that moment. Interest rates determine the Swap rate.</p></div>
                        <div class="tariffs__text" data-aos="fade-up" data-aos-delay="100"><p>As interest rates change over time, so do Swap rates. It’s not entirely accurate to consider Swaps as a fee since there are cases where Swap rates are positive; in that case, the broker pays Swaps to the trader. The Swap rate also depends on whether your position is long or short. You can find the current Swap rates of each trading instrument inside either of our trading platforms.</p></div>
        
        
        
        
                <div class="tariffs__equal-list">
                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>Find Swap rates&nbsp;</p>

<p>in MT4</p>
</div>
                <div class="tariffs__equal-list-content style3">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Right-click on any instrument in the watchlis</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Click “Specification”</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Scroll down</div>
                                                    </li>
                                            </ul>

                                            
                        
                                            <a href="https://download.mql5.com/cdn/web/14742/mt4/vertex mining exchange4setup.exe" class="tariffs__equal-list-link btn btn-orange btn-little">Download MT4</a>
                                            
                                    </div>

            </div>

                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>Find Swap rates&nbsp;</p>

<p>in vertex mining exchange Trader</p>
</div>
                <div class="tariffs__equal-list-content style3">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Select any instrument</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Click the “Information” tab</div>
                                                    </li>
                                            </ul>

                                            
                        
                                            <a href="register" class="tariffs__equal-list-link btn btn-orange btn-little">Launch vertex mining exchange web</a>
                                            
                                    </div>

            </div>

                                </div>
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"></div>
    </div>
</div>        
            <div id="social-links" class="social-links" style="background: #ffffff;">
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

      @include('include.footer')