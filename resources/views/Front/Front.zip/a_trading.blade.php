@include('include.header')


<main class="main">            
            

<div id="" class="simple-banner style8" style="">

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1><span style="color: rgb(23, 24, 29);">Find your</span>
	<br><span style="font-weight:800;">Trading Account</span></h1></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p>As the home of investing, we welcome various traders with a comprehensive range of trading accounts. Whether you want to begin with €250 or €250,000, our door is always open.</p></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="images/why-block__image-min.png" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p>As the home of investing, we welcome various traders with a comprehensive range of trading accounts. Whether you want to begin with €250 or €250,000, our door is always open.</p></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            <div id="" class="accounts" >
    <div class="accounts__top" style="background-image: url(images/offer-accounts.jpg)">
        <div class="container">
            <div class="accounts__title title title_center" data-aos="fade-up"><p>What <span style="font-weight:800;">We Offer</span></p></div>
            <div class="accounts__text text" data-aos="fade-up" data-aos-delay="100"><p>Every trader has their own demands and ambitions, which is why our team of financial markets professionals has crafted a menu of trading accounts to suit different traders.</p></div>
        </div>
    </div>

    <div class="accounts__bottom">
        <div class="container">
            <div class="accounts__list" data-aos="fade-up" data-aos-delay="200">
                                                                <div class="accounts__list-heading">
                    <div class="accounts__list-col"></div>
                                        <div class="accounts__list-col">
                        <div class="accounts__list-heading-name accounts__list-text">Trader</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_text btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                        <div class="accounts__list-col">
                        <div class="accounts__list-heading-name accounts__list-basic">basic</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_basic btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                        <div class="accounts__list-col">
                        <div class="accounts__list-heading-name accounts__list-bronze">bronze</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_bronze btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                        <div class="accounts__list-col">
                        <div class="accounts__list-heading-name accounts__list-silver">SILVER</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_silver btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                        <div class="accounts__list-col">
                        <div class="accounts__list-heading-name accounts__list-gold">GOLD</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_gold btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                        <div class="accounts__list-col">
                        <div class="accounts__list-heading-name accounts__list-platinum">Premium</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_platinum btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                    </div>

                <div class="accounts__list-heading accounts__list-slider">
                                        <div class="accounts__list-slide">
                        <div class="accounts__list-heading-name accounts__list-text">Trader</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_text btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                        <div class="accounts__list-slide">
                        <div class="accounts__list-heading-name accounts__list-basic">basic</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_basic btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                        <div class="accounts__list-slide">
                        <div class="accounts__list-heading-name accounts__list-bronze">bronze</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_bronze btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                        <div class="accounts__list-slide">
                        <div class="accounts__list-heading-name accounts__list-silver">SILVER</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_silver btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                        <div class="accounts__list-slide">
                        <div class="accounts__list-heading-name accounts__list-gold">GOLD</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_gold btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                        <div class="accounts__list-slide">
                        <div class="accounts__list-heading-name accounts__list-platinum">Premium</div>

                        <div>
                                                        <a href="register" class="accounts__list-btn accounts__list-btn_platinum btn">Open Account</a>
                            
                                                    </div>
                    </div>
                                    </div>

                <div class="accounts__list-tabs">
                                        <div class="accounts__list-tabs-item accounts__list-text active" data-slide="1">Trader</div>
                                        <div class="accounts__list-tabs-item accounts__list-basic " data-slide="2">basic</div>
                                        <div class="accounts__list-tabs-item accounts__list-bronze " data-slide="3">bronze</div>
                                        <div class="accounts__list-tabs-item accounts__list-silver " data-slide="4">SILVER</div>
                                        <div class="accounts__list-tabs-item accounts__list-gold " data-slide="5">GOLD</div>
                                        <div class="accounts__list-tabs-item accounts__list-platinum " data-slide="6">Premium</div>
                                    </div>
                                                
                <div class="accounts__list-content">
                                                                                                    <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Min. deposit
                                <span class="accounts__list-link-empty">Deposit funds using one of our many reliable payment processors.</span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        €250
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        €250
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        €1,000
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        €2,500
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        €5,000
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        €50,000
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Practice account
                                <span class="accounts__list-link-empty">Create multiple demo accounts to test different platforms or trading strategies.</span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Online chat support
                                <span class="accounts__list-link-empty">Our highly-trained support agents are available to address your questions or concerns. </span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Access to all trading platforms
                                <span class="accounts__list-link-empty">Trade on either MetaTrader 4, MetaTrader 5 or our very own vertex mining exchange Trader. Or all of them.</span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Maximum leverage
                                <span class="accounts__list-link-empty">Leverage is available for traders who understand the risks of misusing leverage.</span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        1:1
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        1:30
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        1:30
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        1:30
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        1:30
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        1:30
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Stop out level
                                <span class="accounts__list-link-empty">According to ESMA regulations, clients may not have margin level lower than 50%. This mechanism prevents traders from excessive losses.</span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        50%
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        50%
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        50%
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        50%
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        50%
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        50%
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Relationship manager
                                <span class="accounts__list-link-empty">Our relationship managers go above and beyond to ensure our clients have what they need to prosper in the financial markets.</span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/close.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/hours.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Trading Central daily newsletter
                                                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/close.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/hours.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Trading Central premium signals
                                                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/close.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/hours.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/hours.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                One-on-one trading academy sessions
                                <span class="accounts__list-link-empty">If you’re new to investing and trading, our trading academy is an excellent place to begin. </span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/close.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        1
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        3
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        4
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        ∞
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                vertex mining exchange investments
                                                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/close.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/close.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Variable floating spread
                                <span class="accounts__list-link-empty">To stay competitive in the industry, we prioritise offering competitive quotes to our traders.</span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        0.1 pip floating
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        0.1 pip floating
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        0.1 pip floating
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        0.1 pip floating
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        0.1 pip floating
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        0.1 pip floating
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                Trading commissions per Lot from
                                <span class="accounts__list-link-empty">We offer competitive trading commissions for traders at different levels.</span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        20 €/$/£
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        12 €/$/£
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        12 €/$/£
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        11 €/$/£
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        10 €/$/£
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        7 €/$/£
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                                                <div class="accounts__list-item">
                        <div class="accounts__list-row">
                            <div class="accounts__list-col accounts__list-caption account-list-first-title">
                                VIP services
                                <span class="accounts__list-link-empty">Our VIP services are only available for clients depositing more than €200,000. Some of our advanced accounts are eligible for a VIP service trial.</span>                            </div>
                                                        <div class="accounts__list-col accounts__list-value active" data-slide="1">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/success.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="2">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/close.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="3">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/close.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="4">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/hours.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="5">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/hours.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                        <div class="accounts__list-col accounts__list-value " data-slide="6">
                                <div class="accounts__list-col-inner">
                                                                        <div class="marked-icon-block">
                                        <img src="images/hours.png" >
                                    </div>
                                                                    </div>
                            </div>
                                                    </div>
                        
                    </div>
                                                        </div>

                                                                <div class="accounts__list-tabs">
                                        <div class="accounts__list-tabs-item accounts__list-text active" data-slide="1">Trader</div>
                                        <div class="accounts__list-tabs-item accounts__list-basic " data-slide="2">basic</div>
                                        <div class="accounts__list-tabs-item accounts__list-bronze " data-slide="3">bronze</div>
                                        <div class="accounts__list-tabs-item accounts__list-silver " data-slide="4">SILVER</div>
                                        <div class="accounts__list-tabs-item accounts__list-gold " data-slide="5">GOLD</div>
                                        <div class="accounts__list-tabs-item accounts__list-platinum " data-slide="6">Premium</div>
                                    </div>
                                                            </div>
        </div>
    </div>
</div>        
            <div id="" class="social-links" style="background: #ffffff;">
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="images/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="images/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="images/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="images/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

 @include('include.footer')