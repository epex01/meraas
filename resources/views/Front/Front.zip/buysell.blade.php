@extends('Layouts.front')

@section('title')
    Buy & Sell | {{ config('app.name') }}
@endsection

