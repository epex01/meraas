@include('include.header')

<main class="main">
            
            
<div id="glossary" class="simple-text style6   "
     style="background: #ffffff;">

    
    <div class="container">
        <div class="simple-text__title title title_center" data-aos="fade-up"><h1><span style="font-weight:800;color:#aa8a5c;">Glossary</span></h1></div>        <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;"><span lang="en-US">Get
acquainted with the terminology you’ll rely on every day as a trader or investor.</span></p></div>

        
            </div>
</div>    <div class="glossary">
    <div class="container">

        <div class="glossary__search-container">
            <form action="#" method="get">
                <input type="text" name="s" id="s" value="" autocomplete="off" placeholder="Enter word that you need here" />
                <button type="submit">Search</button>
            </form>
        </div>

        <div class="glossary__group-list">
                            <div class="glossary__group-item">
                    <a href="#A" data-rel="1">A</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#B" data-rel="2">B</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#D" data-rel="3">D</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#E" data-rel="5">E</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#F" data-rel="9">F</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#L" data-rel="6">L</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#M" data-rel="7">M</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#P" data-rel="12">P</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#S" data-rel="4">S</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#U" data-rel="8">U</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#V" data-rel="11">V</a>
                </div>
                            <div class="glossary__group-item">
                    <a href="#W" data-rel="10">W</a>
                </div>
                    </div>
        <div class="glossary__glossary-container">
            <div class="glossary__glossary-group">

            </div>
            <div class="glossary__glossary-items">

            </div>
        </div>
    </div>
</div>
        </main>

    @include('include.footer')