@include('include.header')

<main class="main">
            
            <div id="banner" class="simple-block-top" >
    <div class="container">
        <div class="simple-block-top__content">
                        <div class="simple-block-top__title title" data-aos="fade-left"><h1><span style="font-weight:800;color:#aa8a5c;">Introduction</span> to Trading</h1></div>
            
                        <div class="simple-block-top__subtitle" data-aos="fade-left"><p>Depending on who you ask, there are varying definitions of what constitutes a successful forex trader and investor. Some believe that a professional trader is employed to trade, perhaps at a bank, broker or investment company.</p></div>
            
            <div class="simple-block-top__text text" data-aos="fade-left" data-aos-delay="100"></div>

            
                        <div class="simple-block-top__combined-links">
                <div class="combined-links">
                    <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                        
                        
                                                <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                        
                                            </div>
                </div>
            </div>

                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                <p>* Start Trading Now.</p>
            </div>
                        
            
        </div>

        <div class="simple-block-top__media">
            <div class="simple-block-top__image">
                <div data-aos="fade-right">
                    <img src="images/intro-banner-min.png" alt="Introduction to Trading">
                </div>
            </div>
        </div>
    </div>
</div>        
            
<div id="how-to-start-trading" class="simple-block left  style1  wide_content round_image " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/businessman-talking-phone%203-min.jpg" alt="Where to Begin Trading And Investing" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>Where to Begin <span style="font-weight:800;color:#aa8a5c;">Trading And Investing</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>In many cases, those employed to trade at an investment firm are only responsible for placing trades under specific conditions that the company clearly defines. Other sources may consider a professional trader as someone highly skilled and consistently profitable; others will define a professional as someone whose full-time job and primary source of income will come from trading the forex market.&nbsp;</p>

<p><span lang="en-US">A profession is a paid occupation that involves specific skills and knowledge that can take years to be acquired. Being professional is associated with knowledge and skills required to undertake the profession. Anyone can become a successful trader without necessarily being a professional.</span></p>

<p lang="en-US"><span lang="en-US">Like any skilled profession, becoming a full-time or part-time forex trader will require you to master the financial markets. In the sections that follow, we shall explore what becoming a successful forex trader entails.</span></p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            <div id="risk-management" class="text-center-block-big style1" style="background-image: url(images/stock-market-trading-PRKKJK2-min.png)">
    <div class="container">
                <div class="text-center-block-big__title title title_center" data-aos="fade-up"><p>Risk <span style="font-weight:800;color:#cbac63;">Management</span></p></div>
                        <div class="text-center-block-big__subtitle" data-aos="fade-up" data-aos-delay="100"><p><span lang="en-US">Risk management is a cornerstone principle of
investing. Many inexperienced traders focus exclusively on making a
profit, whereas an experienced trader will see two critical
objectives; achieve profits and limit losses.</span></p></div>
                <div class="text-center-block-big__text" data-aos="fade-up" data-aos-delay="200"><p><span lang="en-US">If you cannot control your losses carefully, it
really doesn’t matter how much money you make, because eventually,
you will lose it. Successful traders pay a lot of attention towards
their risk to reward ratios and position sizes.</span></p></div>

                <br /><br />
        <div data-aos="fade-up" data-aos-delay="400">
                        <a href="register" class="btn btn-white-bright-red">Open a Trading Account</a>

            <div class="warning-text warning-text_light">
                <div data-aos="fade-up" data-aos-delay="600">

	<p>* Start Trading Now.</p>
</div>
            </div>
            
                    </div>
            </div>
</div>        
            <div id="analyse-markets" class="analyse-list" style="background: #ffffff;">
    <div class="analyse-list__top" style="background-image: url(images/analyse-intoduction-min.jpg)">
        <div class="container">
            <div class="analyse-list__title title title_center" data-aos="fade-up"><p>How To <span style="font-weight:800;color:#cbac63;">Analyse Markets</span></p></div>
            <div class="analyse-list__subtitle" data-aos="fade-up" data-aos-delay="100"><p><span lang="en-US">Before you can place a forex trade, you need to
have a prediction and experienced traders but a lot of emphasis
towards this part of trading. Without a specific plan of attack, you
are simply gambling on whether you will make money, or not. Luck
should never be a component of your decision-making criteria.</span></p></div>
            <div class="analyse-list__text" data-aos="fade-up" data-aos-delay="200"><p><span lang="en-US">When placing a forex trade, you need to predict
more than just whether the market will go up or down. Traders use
different types of analysis to design what is known as trade setups.
A trade setup predicts which direction the market will head, at what
price the order should be opened, and the target to exit the
position. When opening a trade, you need to decide where to place a
take-profit, which is where the trade has succeeded, and the position
should be closed profitably. You also need to decide at which point
the trade has failed and should be closed to prevent any additional
losses.</span></p>

<p><span lang="en-US">Traders
use a variety of techniques to define precisely when to open and
close positions. The categories of market analysis used by most forex
traders are technical, fundamental and sentiment analysis. Each type
of analysis can be combined to draw actionable conclusions about a
specific financial market or security.</span></p></div>
        </div>
    </div>

    <div class="analyse-list__bottom">
        <div class="container">
            <ul class="analyse-list__list">
                                <li class="analyse-list__item" data-aos="fade-up" data-aos-delay="450">
                    <div class="analyse-list__item-title title"><p>Technical <span style="font-weight:800;color:#aa8a5c;">Analysis</span></p>
</div>
                                        <div class="analyse-list__item-text"><p>The centrepiece of every trading platform is a chart. The charts display historical price data of a particular security. Charts can display information in different formats; the most common chart type used by forex traders is a candlestick chart. Each candle reflects a variable period determined by adjustable settings, and the candle depicts the high &amp; low and open &amp; close price of the instrument.&nbsp;</p>

<p>Besides price information, other attributes can provide valuable information about the past and potentially future behaviour of a financial market. Technical analysis indicators can show information about changes in trading volume and how quickly prices have moved over a period of time.</p>

<p>Traders have dozens of technical analysis indicators at their disposal. The popular MetaTrader 4 platform has 30 technical analysis indicators, and the Vertexmining Exchangetrading platform offers 48 indicators.</p>

<p>Successful forex traders have a carefully curated toolbox of preferred technical indicators and tools. Indicators can be used to confirm the direction of a trend, indicate when a trend might stop, start and change direction.</p>
</div>
                                    </li>
                                <li class="analyse-list__item" data-aos="fade-up" data-aos-delay="600">
                    <div class="analyse-list__item-title title"><p>Fundamental <span style="font-weight:800;color:#aa8a5c;">Analysis</span></p>
</div>
                                        <div class="analyse-list__item-text"><p>Fundamental analysis is a way to assess the fundamental value of a security. Fundamental analysis is a widespread technique used to evaluate what things are worth. For example, a chocolate bar doesn’t cost €0.70 because it €0.35 to make it and the manufacturer would like to double their money. Nope. It costs €0.70 because it is comparable with all the other chocolate bars in the market and is aligned with what consumers expect it should cost.</p>

<p>What things cost are usually related to what people are prepared to pay for them, rather than the underlying costs of producing the product.&nbsp;</p>

<p>Successful traders study numerous macroeconomic indicators. Factors that influence the value of a currency pair or a commodity could be job market statistics, manufacturing output, trade balances, retail sales figures, GDP changes, elections, wars, interest rate decisions and central bank policies.</p>
</div>
                                    </li>
                                <li class="analyse-list__item" data-aos="fade-up" data-aos-delay="750">
                    <div class="analyse-list__item-title title"><p>Sentiment <span style="font-weight:800;color:#aa8a5c;">Analysis</span></p>
</div>
                                        <div class="analyse-list__item-text"><p>Sentiment analysis observes the actions of the market. Sources of sentiment analysis can be from different forex trading platforms that show the ratio of traders who are committed to the market going up with buy positions or are committed to the market going down by holding short positions.&nbsp;</p>

<p>Another source of sentiment analysis could be looking at the futures and options markets. For example, suppose there are many short futures or options contracts open. In that case, it could indicate that speculators expect the price of an asset to depreciate and intend to make a profit from the downside. However, it could mean the opposite too. Some traders may interpret that same situation as a corporation which physically holds the asset expecting the price to increase, but temporarily hedges some of the exposure.</p>

<p>Successful traders always take sentiment analysis with a grain of salt because of how subjective this form of analysis can be.</p>
</div>
                                    </li>
                            </ul>
        </div>
    </div>
</div>        
            
<div id="risk-to-reward" class="simple-block left  style2 small_padding  empty_padding_bottom " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                                    <div class="simple-block__image stick" data-sticky-class="sticking">
                <div data-aos="fade-right">
                                        <img src="images/reward-introduction.jpg" alt="Risk to Reward">
                </div>
            </div>
            
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p class="oc-text-capitalize">Risk to <span style="font-weight:800;color:#aa8a5c;">Reward</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p><span lang="en-US">Just like in every business, risk and loss are
ingrained. For example, let’s consider a restaurant. The restaurant
serves twenty dishes and has enough ingredients to prepare twenty
portions of each dish every day. The restaurant serves 100 customers
per day. This means the restaurant has enough ingredients to prepare
400 meals but will only sell 100. Therefore, the restaurant ensures
it makes a profit of at least 1:4 cost-to-reward on every meal sold.
The additional revenue offsets the losses.</span></p>

<p lang="en-US"><span lang="en-US">In reality, it would be much more complicated as
labour, utilities and other expenses would need to be considered in
the overall cost, but the principle remains the same; to make a sale,
there is a cost and a risk.&nbsp;</span></p>

<p lang="en-US"><span lang="en-US">Imagine if the restaurant had too many salmon
fillets left and decided to lower the price to prevent losing money,
meanwhile, there is only one steak left, so it decided to increase
the cost to make more money. Doing so would not be an effective
tactic and would result in a mess and most likely a loss. Risk
management, as the name suggests, the practice of managing risk.</span></p>

<p lang="en-US"><span lang="en-US"><strong>Much like how in the restaurant example, not every
portion will be sold, not every forex trade you place will be
profitable. Successful traders exercise a strict risk-to-reward
policy to ensure that profitable trades will always offset the losses
of the unprofitable ones. Therefore, traders follow something similar
to a ratio of 1:4 risk-to-reward.</strong></span></p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="position-sizing" class="simple-text style5   "
     style="background: #ffffff;">

    
    <div class="container">
        <div class="simple-text__title title title_center" data-aos="fade-up"><p>Position <span style="font-weight:800;color:#aa8a5c;">Sizing</span></p></div>        <div class="simple-text__text text" data-aos="fade-up"><div style="max-width: 925px;margin:0 auto;">

	<p style="text-align: center;">The size of your position is directly correlated with the risk it presents. A larger position means a greater amount of exposure to the market, and small price movements can significantly impact profitability. See below an example of two positions, both are for the same instrument and have the same entry price, but the first is losing $1 while the second is losing $100.</p>
</div></div>

        
            </div>
</div>        
            
<div id="position-tariffs" class="tariffs style5  "
     style="background-image: url(images/postion-tariffs-min.jpg);     ">

    <div class="container">
                        
        
        
        
                <div class="tariffs__equal-list">
                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>Position 1</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Position Size: 0.01 Lot (1,000 euros)</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Direction: Long (buy)</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Instrument: EUR/USD</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Open Price: 1.190150</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Current Price: 1.19050</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title"><b>Profit/Loss: -$1.00 (-10 Pips)</b></div>
                                                    </li>
                                            </ul>

                    
                                    </div>

            </div>

                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>Position 2</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Position Size: 1.00 Lot (100,000 euros)</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Direction: Long (buy)</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Instrument: EUR/USD</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Open Price: 1.190150</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Current Price: 1.19050</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title"><b>Profit/Loss: -$100.00 (-10 Pips)</b></div>
                                                    </li>
                                            </ul>

                    
                                    </div>

            </div>

                                </div>
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"></div>
    </div>
</div>        
            
<div id="larger-position-sizes" class="simple-text style6   "
     style="background: #ffffff;">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><p>Larger position sizes do not just affect profit and loss, but also margin consumption. If your positions are too big, you run the risk of missing other trading opportunities since all your available trading capital is allocated to maintaining just one position. Another even more critical reason is that larger positions in drawdown pose the risk of triggering margin-call or stop-out. Let’s consider a more advanced example that considers account balance margin too.</p></div>

        
            </div>
</div>        
            
<div id="positions" class="tariffs style6  "
     style="background-image: url(images/positions-introduction-min.jpg);     ">

    <div class="container">
                        
        
        
        
                <div class="tariffs__equal-list">
                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>Position 1</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Account Balance: $5,000</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Leverage: 1:30</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Position Size: 0.01 Lot (1,000 euros)</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Direction: Long (buy)</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Instrument: EUR/USD</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Open Price: 1.190150</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Current Price: 1.17650</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title"><b>Profit/Loss: -$15.00 (-150 Pips)</b></div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Used Margin: 3,971.67</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Equity: $4,985</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Margin Level: 125.5%</div>
                                                    </li>
                                            </ul>

                    
                                    </div>

            </div>

                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>Position 2</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Account Balance: $5,000</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Leverage: 1:30</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Position Size: 1.00 Lot (100,000 euros)</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Direction: Long (buy)</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Instrument: EUR/USD</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Open Price: 1.190150</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Current Price: 1.17650</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title"><b>Profit/Loss: -$1,500.00 (-150 Pips)</b></div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Used Margin: 3,971.67</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Equity: $3,500</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Margin Level: 88%</div>
                                                    </li>
                                            </ul>

                    
                                    </div>

            </div>

                                </div>
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>As you can see from the example above, by having a larger position, any pullback can have severe effects on a trading account. That is why experienced forex traders focus heavily on their position size by adopting rigid rules on how much they are prepared to risk for each trade. Some traders might, for example, impose a limit of not risking more than 2% of their account balance on each trade. Position #2 is in clear violation of this rule; however, position #1 is well within the parameters of a 2% risk allowance.</p></div>
    </div>
</div>        
            
<div id="trading-portfolio" class="simple-block left  style1  empty_padding_bottom " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/trading-portfolio-introduction-min.jpg" alt="Trading Portfolio" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>Trading <span style="font-weight:800;color:#aa8a5c;">Portfolio</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>Most online trading brokers (Vertexmining Exchangeincluded), offer dozens of currency pairs and hundreds of other financial instruments. Different instruments behave differently depending on the time of day, the week, or the season. Each instrument can have distinctive characteristics too.&nbsp;</p>

<p>For example, the characteristics of a stock market index like the S&amp;P500 could keep trending up indefinitely. A currency pair like EUR/USD is likely to trade within a certain range unless some catastrophic macroeconomic situation destabilised either the euro or the dollar.</p>

<p>Some instruments may have wider spreads which can make some trading strategies unfeasible. For example, exotic European currencies like EUR/HUF, EUR/CZK have wider spreads than other currency pairs like EUR/USD and would therefore be harder to trade using a scalping strategy.&nbsp;</p>

<p>Some currency pairs have positive and negative Swap rates. A Swap rate is similar to an interest rate that you pay or collect when holding a position overnight. If a Swap rate is negative, you pay interest for boring a currency to hold the position overnight. If the rate is positive, you earn interest on the currency you are holding. Swap rates can vary significantly depending on the instrument, and it can affect your ability to trade profitably. If you plan on holding positions for a few days, Swaps can either take from or add to your profits.</p>

<p><span lang="en-US">An experienced trader will need to understand the
unique characteristics of each financial instrument they trade. Many
expert traders focus on trading a few specific products to become a
specialist in those markets.</span></p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="trading-strategies" class="simple-block right  style1 small_padding  round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/portfolio-why-min.jpg" alt="Trading Strategies" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>Trading <span style="font-weight:800;color:#aa8a5c;">Strategies</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>A forex trading strategy is a plan of attack for approaching the markets. A trading strategy encompasses all variables involved in making trading decisions. A robust strategy should define which forms of analysis should be used and how to interpret information. A strategy will also determine what instruments will be traded and when, how big orders should be and the risk-to-reward ratio that should be followed.</p>

<p>A trading strategy is crucial for maintaining consistency. Without consistency, there is no way to retrospectively analyse the performance and pinpoint areas which could be improved.&nbsp;</p>

<p>Successful traders maintain journals of their trades and try to understand why some trades failed and how others succeeded. Making changes to a strategy requires delicacy because one minor modification could throw everything off balance.</p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="trading-psychology" class="simple-block left  style1  empty_padding_top round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/phychology-introduction-min.jpg" alt="Trading Psychology" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>Trading <span style="font-weight:800;color:#aa8a5c;">Psychology</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>Trading forex and CFDs is a rollercoaster. The one thing that keeps the trading analysis, risk management, trading portfolio and overall strategy tied together is the ability to stick to follow a plan and not listen to your emotions.</p>

<p>Losing goes hand in hand with trading forex, and that is a feeling many traders struggle to overcome. Even when trading with minimal position sizes and losing a few dollars may be inconsequential to your finances, but the feeling of failure can be consuming. As opposed to having a robust and long term strategy, some traders fall victim to the disposition effect. The phenomenon leads traders to close profitable trades early, do they feel like they won, or rather didn’t lose. Meanwhile, they let losing trades run for too long because they do not accept they were wrong, and this results in a larger loss.</p>

<p>Without a comprehensive trading strategy and the commitment to follow it, your decisions will be governed by the hundreds of biases that pollute the human mind, all of which are prepared to sabotage us.</p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="speak-account-manager" class="true-power " style="background-image: url(images/true-power-min.jpg)">
    <div class="container">
                        <div class="true-power__subtitle" data-aos="fade-up"><div style="max-width: 450px;margin-left:auto;margin-right:auto;">

	<p><span style="font-weight:800;">Speak to an account manager&nbsp;</span> to find out more.</p>
</div></div>
                
        
                <div class="combined-links">
            <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                
                                <a href="products" class="combined-links__item combined-links__right"><span>View all products</span></a>
                
                
                                <a href="contactus" class="combined-links__item combined-links__left"><span>Get in touch</span></a>
                            </div>
        </div>

                    </div>
</div>        
            <div id="social-links" class="social-links" style="background: #ffffff;">
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

    @include('include.footer')