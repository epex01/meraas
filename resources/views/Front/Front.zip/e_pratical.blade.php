@include('include.header')

<main class="main">
        <div class="single-page amzn">
    <div class="container amz-container">
            
            

<div id="amzn-sign-form" class="simple-banner style2  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

        
                     <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                <script src="https://widget.bm-tech.co/sign-up-form?token=86kzoGyihJTYQPT3f8cZ0HuX2MoJvMkUAx0Lw72QA3vt1x" crossorigin="anonymous"></script>
            </div>
        
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="practical-traders" class="simple-banner style2  "
style="background-image: url(images/block1_bg_big.jpg);"
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p class="toptext_first">Trading for</p>

<p class="toptext_second"><strong>PRACTICAL TRADERS</strong></p>

<p class="toptext_third">The difference is tangible: Start trading with the tightest spreads.</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><div class="line">
	<div>

		<p>Starting deposit</p>

		<p><span>€250</span></p>
	</div>
	<div>

		<p>Pip floating from</p>

		<p><span>0.1</span></p>
	</div>
	<div>

		<p>Stop out level</p>

		<p><span>50%</span></p>
	</div></div>
<div class="line">
	<div>

		<p>Leverage up to</p>

		<p><span>1:30</span></p>
	</div>
	<div>

		<p>Currencies, Metals &amp; Stocks</p>

		<p><span>300+</span></p>
	</div>
	<div>

		<p>Currency pairs</p>

		<p><span>50+</span></p>
	</div></div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

        
         
        
        
                    <script>
                jQuery(document).ready(function() {
                    if (jQuery(window).width() < 468) {
                        
                       let line = jQuery(".simple-banner__content-wrap .line")[1];
                       let stopout = jQuery(".line div")[8];
                       let currency_pairs = jQuery(".line div")[11];
                       
                       jQuery(stopout).hide();
                       jQuery(currency_pairs).hide();
                       
                       //let newline = '<div class="line"></div>';
                       //jQuery(newline).insertAfter(jQuery(".line")[3]);  
                       
                       
                       jQuery('<div/>', {
                            "class": 'line',
                            id: 'alsoline'
                        }).appendTo('.simple-banner__text');
                       
                       jQuery("div#alsoline").append(stopout);
                       jQuery("div#alsoline").append(currency_pairs);
                       
                       jQuery(stopout).show();
                       jQuery(currency_pairs).show();
                       console.log(jQuery("div#alsoline"));
                       
                       //jQuery(stopout).appendTo("div#alsoline");
                       //jQuery(currency_pairs).appendTo("div#alsoline");
                       
                       //console.log(newline);
                       
                       /*jQuery(stopout).insertAfter(jQuery(".line div")[9]);  
                       jQuery(currency_pairs).insertAfter(jQuery(".line div")[12]);  
                       console.log(jQuery(".line")[2]);*/
                        //jQuery(elem).insertAfter(jQuery(".numbers__list-item .numbers__list-content")[1]);                                
                        //jQuery(".numbers__list-item .numbers__list-image").eq(2).hide();
                    }
                    
                    //console.log(elems);
                        
                    /*jQuery(window).resize(function() {
                        var elem = jQuery(".numbers__list-item .numbers__list-image")[1];
                        if (jQuery(window).width() < 468) {                                   
                            jQuery(elem).insertAfter(jQuery(".numbers__list-item .numbers__list-content")[1]);                                
                            jQuery(".numbers__list-item .numbers__list-image").eq(2).hide();
                        } else {
                            jQuery(elem).insertBefore(jQuery(".numbers__list-item .numbers__list-content")[1]);   
                            jQuery(".numbers__list-item .numbers__list-image").eq(2).show();
                        }
                    })  */                          
                    
                });
            </script>
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><div class="line">
	<div>

		<p>Starting deposit</p>

		<p><span>€250</span></p>
	</div>
	<div>

		<p>Pip floating from</p>

		<p><span>0.1</span></p>
	</div>
	<div>

		<p>Stop out level</p>

		<p><span>50%</span></p>
	</div></div>
<div class="line">
	<div>

		<p>Leverage up to</p>

		<p><span>1:30</span></p>
	</div>
	<div>

		<p>Currencies, Metals &amp; Stocks</p>

		<p><span>300+</span></p>
	</div>
	<div>

		<p>Currency pairs</p>

		<p><span>50+</span></p>
	</div></div></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        
            <div id="finishing-line" class="numbers">
    <div class="container">
        <div class="numbers__title" data-aos="fade-up"><p style="text-align: center;
    font-weight: normal;
    font-size: 20px;
    line-height: 1;">Would you describe yourself as A Trader who</p>

<p style="text-align: center;"><strong>Goes The Distance?</strong></p></div>

        <div class="numbers__list">
            <div class="numbers__list-item" data-aos="fade-right" data-aos-delay="200">
                <div class="numbers__list-number"><img src="images/number1.png" alt=""></div>
                <div class="numbers__list-content">
                    <div class="numbers__list-title">Here is the Finishing Line</div>
                    <div class="numbers__list-text"><p>Vertexmining Exchange provides trading with some of the most prominent currency pairs. Trading has never been as exciting. Join us today.</p>
</div>

                    
                                    </div>
                <div class="numbers__list-image">
                    <img src="images/Vector%20Smart%20Object@1X.png" alt="Here is the Finishing Line">
                </div>
            </div>

            <div class="numbers__list-item" data-aos="fade-left" data-aos-delay="200">
                <div class="numbers__list-number"><img src="images/number2.png" alt=""></div>
                
                                    <div class="numbers__list-image">
                        <img src="images/vector-smart-object@1x-1.png" alt="Seize the Market Opportunities">
                    </div>
                    <div class="numbers__list-content">
                        <div class="numbers__list-title">Seize the Market Opportunities</div>
                        <div class="numbers__list-text"><p>With over $6 Trillion traded daily on the Foreign Exchange Markets, Vertexmining Exchange Invites you to join the excitement and trade with professionals.</p>
</div>
    
                            
                                            </div>
                
                
                    <script>
                        jQuery(document).ready(function() {
                            if (jQuery(window).width() < 768) {
                               var elem = jQuery(".numbers__list-item .numbers__list-image")[1];
                                jQuery(elem).insertAfter(jQuery(".numbers__list-item .numbers__list-content")[1]);                                
                                jQuery(".numbers__list-item .numbers__list-image").eq(2).hide();
                            }
                                
                            jQuery(window).resize(function() {
                                var elem = jQuery(".numbers__list-item .numbers__list-image")[1];
                                if (jQuery(window).width() < 768) {                                   
                                    jQuery(elem).insertAfter(jQuery(".numbers__list-item .numbers__list-content")[1]);                                
                                    jQuery(".numbers__list-item .numbers__list-image").eq(2).hide();
                                } else {
                                    jQuery(elem).insertBefore(jQuery(".numbers__list-item .numbers__list-content")[1]);   
                                    jQuery(".numbers__list-item .numbers__list-image").eq(2).show();
                                }
                            })                            
                            
                        });
                    </script>
                                
            </div>

            <div class="numbers__list-item" data-aos="fade-right" data-aos-delay="200">
                <div class="numbers__list-number"><img src="images/number3.png" alt=""></div>
                <div class="numbers__list-content">
                    <div class="numbers__list-title">Your rules at your pace!</div>
                    <div class="numbers__list-text"><p>The convenience of being able to focus on your strategy, makes Vertexmining Exchange a reasonable option. We support your growth. Trade the way you want, our strategy, tools, and content are at your disposal 24/5.</p>
</div>

                    
                                    </div>
                <div class="numbers__list-image">
                    <img src="images/vector-smart-object@1x-2.png" alt="Your rules at your pace!">
                </div>
            </div>
                            <div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="text-align:center;">
                     <p><a class="btn btn-orange" data-fancybox="" href="#" style="padding: 20px 50px;font-weight:bold;font-size:24px;font-style:normal;line-height:1;">START TRADING</a></p>
<div class="warning-text aos-init aos-animate" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">
	<br>

	<p>* Start Trading Now.</p>
</div> 
                </div>
                    </div>
    </div>
</div>        
            <div id="many-assets"  class="why-block">
    <div class="container">
        <div class="why-block__title" data-aos="fade-up"><p class="many_assets">So many assets at the palm of your hand</p>

<p>Trade commodities, Currencies and Stocks from anywhere across the</p>

<p>globe.</p></div>
        <div class="why-block__image" data-aos="fade-up" data-aos-delay="200">
            <img src="images/why-block__image-min.png" alt="" class="lazy">
        </div>
        <ul class="why-block__list">
                        <li class="why-block__list-item" data-aos="fade-up" data-aos-delay="350">
                <div class="why-block__list-icon">
                    <div class="why-block__list-icon-inner" style="background-image: url(images/Personalised_icon.svg)"></div>
                </div>
                <div class="why-block__list-title">
                    <p>Major markets have never been closer</p>

                </div>
                <div class="why-block__list-text">
                    <p>Vertexmining Exchange gives you plenty of options, with currencies, commodities and</p>

<p>digital currencies, ready to trade. From Energy Products and Agriculture to indices - you control what you trade. We are talking about full control.</p>

                </div>
            </li>
                        <li class="why-block__list-item" data-aos="fade-up" data-aos-delay="500">
                <div class="why-block__list-icon">
                    <div class="why-block__list-icon-inner" style="background-image: url(images/Safe-Icon.svg)"></div>
                </div>
                <div class="why-block__list-title">
                    <p>The initial deposit doesn't have to be huge</p>

                </div>
                <div class="why-block__list-text">
                    <p>Start trading now with deposit of only €250. The possibility to trade at the best prices is what Vertexmining Exchange is about. Invest and become a part of our community.</p>

<p>
	<br>
</p>

                </div>
            </li>
                    </ul>
    </div>
</div>        
            <div id="achieve-goals" class="security">
<!--    <div class="security__image" style="background-image: url(/storage/app/media/security-home-min.png)"></div>-->
    <div id="security-particles" class="security__particles"></div>
    <div class="container">
        <div class="security__image">
            <img src="images/security-home-min.png" alt="Achieve Your Financial Goals, sign up with Vertexmining Exchange!">
        </div>
        <div class="security__content">
            <div class="security__subtitle" data-aos="fade-up"></div>
            <div class="security__title" data-aos="fade-up" data-aos-delay="200"><p>Achieve Your Financial Goals, sign up <strong>with Vertexmining Exchange!</strong></p></div>
            <div class="security__text" data-aos="fade-up" data-aos-delay="400"><div class="line_bottom">
	<div class="line_block">
		<div class="block_icon"><img src="images/mark_icon_security.png" class="fr-fic fr-dii"></div>
		<div class="block_text b1">Almost two decades in the business, CySEC regulated</div></div>
	<div class="line_block">
		<div class="block_icon"><img src="images/mark_icon_security.png" class="fr-fic fr-dii"></div>
		<div class="block_text b2">Trained Professionals at your disposal</div></div>
	<div class="line_block">
		<div class="block_icon"><img src="images/mark_icon_security.png" class="fr-fic fr-dii"></div>
		<div class="block_text b3">Free demo account</div></div></div>
<div class="line_bottom">
	<div class="line_block">
		<div class="block_icon"><img src="images/mark_icon_security.png" class="fr-fic fr-dii"></div>
		<div class="block_text b4">Leverage of up to 1:30, variable spreads from 0.1 pips</div></div>
	<div class="line_block">
		<div class="block_icon"><img src="images/mark_icon_security.png" class="fr-fic fr-dii"></div>
		<div class="block_text b5">Customer service support</div></div>
	<div class="line_block">
		<div class="block_icon"><img src="images/mark_icon_security.png" class="fr-fic fr-dii"></div>
		<div class="block_text b6">Market Maker execution</div></div></div>
<div class="line_bottom">
	<div class="line_block">
		<div class="block_icon"><img src="images/mark_icon_security.png" class="fr-fic fr-dii"></div>
		<div class="block_text b7">Live webinars, education sessions</div></div>
	<div class="line_block">
		<div class="block_icon"><img src="images/mark_icon_security.png" class="fr-fic fr-dii"></div>
		<div class="block_text b8">Five different accounts to select from</div></div>
	<div class="line_block">
		<div class="block_icon"><img src="images/mark_icon_security.png" class="fr-fic fr-dii"></div>
		<div class="block_text b9">Fast withdrawal</div></div></div></div>

            
                                    
                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p><a class="btn btn-orange" data-fancybox="" href="#" style="padding: 20px 50px;font-weight:bold;font-size:24px;font-style:normal;">SIGN UP FOR FREE</a></p>
<div class="warning-text aos-init aos-animate" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">
	<br>

	<p>* Start Trading Now.</p>
</div>
                </div>            
                    </div>

    </div>
</div>            <script>
        /*if(!window.location.hash) {
    		window.location = window.location + '#loaded';
    		window.location.reload();
    	}*/        
        jQuery(document).ready(function() {
            jQuery(".list-with-icons-table__list-icon-inner, .list-with-icons-table__list-title")
                .attr("data-fancybox", "")
                .css('cursor', 'pointer');

            let logo = jQuery(".simple-banner__image img");
            jQuery("#practical-traders .simple-banner__image img").html('<a href="/"></a>');
            jQuery("#practical-traders .simple-banner__image a").html(logo);

            
        });

        jQuery(".btn-orange").click(function() {
            let form = jQuery("#amzn-sign-form .register-form");
            /*let form = jQuery(".register-form");*/
            let classes = 'fancybox-slide fancybox-slide--html fancybox-slide--current fancybox-slide--complete';

            setTimeout(function() {
                jQuery(".fancybox-stage .fancybox-slide.fancybox-slide--current")
                    .addClass(classes)
                    .html('<div id="amzn-sign-form"></div>');
                jQuery(".fancybox-stage .fancybox-slide.fancybox-slide--current #amzn-sign-form").html(form);

                let close = '<button type="button" data-fancybox-close="" class="fancybox-button fancybox-close-small" title="Close"><svg xmlns="http://www.w3.org/2000/svg" version="1" viewBox="0 0 24 24"><path d="M13 12l5-5-1-1-5 5-5-5-1 1 5 5-5 5 1 1 5-5 5 5 1-1z"></path></svg></button>';
                jQuery(".fancybox-stage .register-form").append(close);
            }, 100);

            let formInterval = setInterval(function(){
                let app = jQuery(".form-app");
                let fancyApp = jQuery(".fancybox-stage").html();
                if (fancyApp === undefined) {
                    app.html(form);
                    jQuery(".fancybox-close-small").hide();
                    clearInterval(formInterval);
                }
            }, 100);
        });
	    jQuery(".list-with-icons-table__list-icon-inner, .list-with-icons-table__list-title").click(function() {
	        let form = jQuery("#amzn-sign-form .register-form");
	        /*let form = jQuery(".register-form");*/

	        setTimeout(function() {
	            jQuery(".fancybox-stage .fancybox-slide.fancybox-slide--current").html('<div id="amzn-sign-form"></div>');
	            jQuery(".fancybox-stage .fancybox-slide.fancybox-slide--current #amzn-sign-form").html(form);

	            let close = '<button type="button" data-fancybox-close="" class="fancybox-button fancybox-close-small" title="Close"><svg xmlns="http://www.w3.org/2000/svg" version="1" viewBox="0 0 24 24"><path d="M13 12l5-5-1-1-5 5-5-5-1 1 5 5-5 5 1 1 5-5 5 5 1-1z"></path></svg></button>';
	            jQuery(".fancybox-stage .register-form").append(close);
	        }, 100);

            let formInterval = setInterval(function(){
                let app = jQuery(".form-app");
                let fancyApp = jQuery(".fancybox-stage").html();
                if (fancyApp === undefined) {
                    app.html(form);
                    jQuery(".fancybox-close-small").hide();
                    clearInterval(formInterval);
                }
            }, 100);
	    });

    </script>
    </div>
</div>

<script>
        App.lang = {
            'title': 'Sign up and Start Trading',
            'subtitle': 'Please fill in your details below',
            'afterText': 'CFD and Forex trading involves substantial risk and may result in the loss of the invested capital.',
            'placeholder': {
                'firstName': 'First Name',
                'lastName': 'Last Name',
                'email': 'Email Address',
                'phone': 'Phone',
                'password': 'Password',
                'confirmPassword': 'Confirm Password',
                'adulthood': 'I am over 18 years of age and confirm that I have read and agreed with the <a target="_blank" href="./terms-and-conditions">Terms and Conditions</a>, <a target="_blank" href="./privacy-policy">Privacy Policy</a>, <a target="_blank" href="./risk-disclosure">Risk Disclosure Statement</a>, <a target="_blank" href="#Order_Execution">Order Execution Policy</a><a target="_blank" href="#Conflicts_of_Interest_Policy">, Conflicts of Interest Policy</a>, <a target="_blank" href="#client-categorisation-policy">Client Categorization Policy</a>, <a target="_blank" href="#Investor_Compensation_Fund_Policy">Investor Compensation Fund Policy</a>, <a target="_blank" href="#legal">Key Information Document</a>.',
                'promotions': 'Accept Promotions.',
                'btn_default': 'Submit',
                'btn_process': 'Process...'
            },
            'smsCode': {
                'label': 'Please enter the verification code',
                'placeholder': 'Enter code here',
                'btn_default': 'Approve',
                'btn_process': 'Process...',
                'send_sms_again': 'Send SMS again?'
            },
            'error': {
                'required': 'This field is required',
                'email': 'Please enter a valid email address',
                'phone': 'Invalid phone number',
                'password': 'Must include at least one number, one uppercase letter and one lowercase letter, 6 to 12 characters',
                'confirmPassword': 'Password does not match',
            },
        }

    let search = location.search.substring(1);
    let params = search === '' ? [] : JSON.parse('{"' + search.replace(/&/g, '","').replace(/=/g, '":"') + '"}', function (key, value) {
        return key === "" ? value : decodeURIComponent(value)
    });

    let affiliateId = null;
    if(localStorage.getItem("affiliate_id") !== null){
        affiliateId = localStorage.getItem('affiliate_id');
    }
    if(params.hasOwnProperty('affiliate_id') ){
        affiliateId = params.affiliate_id
    }

    App.beforeSend = function () {
        
            }
</script>

<script>
jQuery(document).ready(function() {
    if (jQuery(window).width() < 768) {        
        $("#practical-traders").css('background-image', 'url(images/top_back_mob.jpg)');
    } else {
        $("#practical-traders").css('background-image', 'url(images/block1_bg_big.jpg)');
    }
    $(window).resize(function() {
        if (jQuery(window).width() < 768) {        
            $("#practical-traders").css('background-image', 'url(images/top_back_mob.jpg)');
        } else {
            $("#practical-traders").css('background-image', 'url(images/block1_bg_big.jpg)');
        }
    });
    
    jQuery(".line, .numbers__list-image img, .why-block__list-icon-inner, .line_block").click(function() {
        jQuery(".btn-orange")[0].click();
    });
    $(".line, .numbers__list-image img, .why-block__image img, .why-block__list-icon-inner, .line_block").hover(function() {
        $(this).css('cursor','pointer');
    });
    
    jQuery(".why-block__image").click(function() {
        let href = 'https://moneyroute-exchange.com'
        window.location = href;
    });
    /*let button = jQuery(".warning-text").clone().css('text-align', 'center');
    jQuery("#finishing-line").append(button).css('margin-bottom', '20px');*/
    setInterval(function() {
        var popform = $('.fancybox-stage #amzn-sign-form');
        if (popform !== undefined) {
            popform.removeAttr('id');
        }
    }, 1);
});
    
</script>

<style>.amz-container {
    max-width: 100%;
}
.numbers__title:after {
    display: none;
}
.numbers__list-number {
    display: none;
}
.fancybox-slide--html .fancybox-close-small, .fancybox-button.fancybox-close-small {
    right: 10px;
    top: 10px;
}
.fancybox-slide:before {
    display: none;
}
.fancybox-slide #amzn-sign-form {
    margin-top: 0;
}
.single-page.amzn {
    background-color: #fff;
    background-image: none;
    padding-bottom: 0;
}
.single-page.amzn .container {
    width: 100%;
    padding: 0;
}
.list-with-icons-table__list-icon-inner, .list-with-icons-table__list-title {
    display: block !important;
}
#many-assets .why-block__title, #many-assets .why-block__image {
    background: transparent linear-gradient(105deg, #822F1F, #351701);
    color: #fff;
    top: -105px;
    position: relative;
    margin: 0;
    
    -webkit-transition-duration: 0s;
    transition-duration: 0s;
}
#many-assets .why-block__title {
    z-index: 1;
}
#many-assets .why-block__image {
    top: -200px;
}
.why-block {
    background: #fff;
}
.why-block .container, .numbers .container {
    max-width: 100%;
}
.why-block__title:after {
    display: none;
}
.why-block__list-item {
    width: 50%;
    text-align: left;
}
.why-block__list-icon {
    background: none;
    float: left;
}
.why-block__list-title {
    color: #000;
}
.why-block__list-icon-inner {
    background-position: 50% 0;
    background-size: 50%;
}
#many-assets .why-block__image img {
    top: 130px;
    position: relative;
}
#finishing-line.numbers {
    margin-top: 0;
    background: #fff;
}
#finishing-line .container {
    padding-top: 50px;
    background: transparent -webkit-gradient(linear, left bottom, left top, from(#fff), to(#ececec));
    background: transparent linear-gradient(1turn, #fff, #ececec);
}
.numbers__list-item {
    margin-bottom: 50px;
    padding-right: 0;
}
.numbers__list {
    padding: 50px 100px;
    background: #fff;
}
.numbers__title {
    margin-bottom: 50px;    
}
.numbers__list-title {
    font-weight: normal;
    color: inherit;
}
.numbers__list-title:after {
    content: '_';
    color: teal;
    display: block;
}
.numbers__list-image {
    padding: 0 40px 0 0;
    min-width: 50%;
}
.security__image {
    margin: auto;
}
.security__content {
    width: 60%;
    margin: auto;
    text-align: center;
}
.security__title:after {
    display: none;
}
.security__text {
    margin: 0;
    width: 100%;
    max-width: 100%;
}
.security__content .line_bottom {
    clear: left;
    display: flex;
    margin-bottom: 20px;
}
.security__content .line_block {
    
    /*display: flex;*/
    justify-content: center;
    align-items: center;
    
    color: #000;
    float: left;
    padding: 20px 10px;
    margin-right: 10px;
    width: 33.33%;
    
    height: 180px;
    background: rgba(255, 255, 255, 0.7);
}
.security__content .block_icon {
    /*margin-top: -180px;
    position: absolute;
    display: flex;*/
}
.security__content .block_icon .fr-fic {
    margin-top: -120px;
    position: relative;
}
#practical-traders {
    /*background-size: 104rem;
    background-position: -150px -118px;*/
    min-height: 780px;
    
    background-size: 110%;
    background-position: top left;
    /*min-height: 520px;*/
}
#practical-traders p img {
    width: 80%;
    margin-top: -50px;
    margin-left: 40px;
}
.single-page.amzn #practical-traders {
    width: 100%;
    padding: 60px;
    margin: 0;
    top: 0;
}
.single-page .simple-banner__content {
    width: 68%;
}
.toptext_first {
    text-align: center;
    font-weight: normal;
}
.toptext_second {
    margin-top: 5px;
    font-size: 50px;
    text-align: center;
}
.toptext_third {
    text-align: center;
    font-weight:normal;
    font-size: 24px;
}
#amzn-sign-form {
    margin-top: 45px;
    display: block;
    background: none;
}
#amzn-sign-form .simple-banner__content {
    display: none;
}
#amzn-sign-form .register-form {
    /*background-color: #fff;*/
    background-image: linear-gradient(to bottom right, #fff, #D5D6D7);
    color: #000;
    border-radius: 10px;
    box-shadow: 0px 0px 10px 0px grey;
}
#amzn-sign-form .register-form .register-form__title {
    font-size: 1rem;
    font-weight: 600;
    color: #525050;
}
#amzn-sign-form .register-form .register-form__checkbox {
    font-size: 12px;
    text-align: left;
    margin-top: 20px;
}
#amzn-sign-form .register-form .submit-btn {
    background: linear-gradient(165deg, #aa8a5c, #e0a450 14.8%, #faaf45 32.2%, #cbac63 49.3%, #aa8a5c);
    color: #fff;
    -webkit-box-shadow: 2px 4px 4px rgb(0 0 0 / 19%);
    box-shadow: 2px 4px 4px rgb(0 0 0 / 19%);
    font-size: 24px;
    font-weight: 600;
    border-radius: 10px;
}
#amzn-sign-form .register-form .register-form__subtitle {display: none;}
#amzn-sign-form .simple-banner__image {
    position: absolute;
    top: 120px;
    left: 70%;
    z-index: 1;
    width: 28%;
}
#amzn-sign-form .register-form__input {
    color: #000 !important;
    border-radius: 12px !important;
}
#practical-traders.simple-banner, #practical-traders .simple-banner__title {
    color: #fff;
}
#practical-traders .simple-banner__title {
    padding-top: 0;
}
#practical-traders .simple-banner__text {
    line-height: 0.2;
    font-size: 16px;
}
#practical-traders .simple-banner__text div {
    float: left;
    width: 32%;
    margin-right: 5px;
    margin-bottom: 5px;
    background-image: linear-gradient(#211F20, #363537);
    padding: 40px 0;
    min-height: 160px;
}
#practical-traders .simple-banner__text div.line {
    float: none;
    width: 100%;
    text-align: center;
    padding: 0;
    min-height: 0;
}
#practical-traders .simple-banner__text p {
    line-height: 1;
    font-size: 12px;
}
#practical-traders .simple-banner__text p span{
    font-size: 22px;
    font-weight: bold;
}
#practical-traders .simple-banner__image {
    text-align: left;
    padding-top: 40px;
}

#does-amazon .container {
    width: 100%;
}
#does-amazon .simple-block__subtitle, #invest-platform .list-with-icons-table__title {
    font-size: 28px;
    color: #000;
    font-weight: 600;
}
#does-amazon .simple-block__text {
    font-size: 16px;
    text-align: left;
}
#invest-platform {
    padding-bottom: 50px;
}
#invest-platform .list-with-icons-table__list-icon-inner {
    background-position: 50% 0;
}
#invest-platform .list-with-icons-table__list-icon {
    background: none;
    box-shadow: none;
    height: 155px !important;
    margin-bottom: 0;
}
#invest-platform .list-with-icons-table__list-item {
    width: 33%;
}
#invest-platform .list-with-icons-table__list-title {
    font-size: 16px;
    color: #b03802;
}
#invest-platform .list-with-icons-table__bottom:before {
    content: none;
}
.header {
    /*display: none;*/
}
.single-page {
    padding-top: 0;
}

.title:after {
    content: none;
}
.register-form__row {
    /*display: block;*/
}
.block-bottom .btn.btn-orange {
    line-height: 1;
}
.why-block__title .many_assets {
    font-size: 46px;
    font-weight: normal;
    padding: 100px 0 20px 0;
    line-height: 1;
}
.assets_second {
    font-size: 16px;
}
.numbers__list-text {
    color: grey;
}
.numbers__list-title {
    color: #5f5d5d;
}
.numbers__list-content {
    max-width: 675px;    
}
.block_text {
    margin-top: 16px;    
}
.block_text.b1, .block_text.b4 {
    margin-top: 16px;    
}
.block_text.b2, .block_text.b5, .block_text.b7, .block_text.b8 {
    margin-top: 26px;    
}
.block_text.b3, .block_text.b6, .block_text.b9 {
    margin-top: 34px;    
}

@media (max-width: 768px) {
    .single-page .container {
        margin-top: 20px;
    }
    .simple-banner .container, .simple-block .container, .list-with-icons-table .container {
        max-width: 84%;
    }
    #practical-traders {
        background-size: 100%;
        background-position: top left;
    }
    .single-page.amzn #practical-traders {
        width: 100%;
        padding: 10px 10px;
        margin: 0;
        top: 0;
    }
    .single-page .simple-banner__content {
        width: 100%;
    }
    #practical-traders p img {
        width: 70%;
        margin: auto auto;
        display: block;
    }
    #practical-traders .simple-banner__image {
        text-align: center;
    }
    #practical-traders .simple-banner__title {
        font-size: 20px;
        text-align: center;
    }
    #practical-traders .simple-banner__text p {
        float: none;
        line-height: 1.2;
        width: 100%;

    }
    #practical-traders .mobile-hide {
        position: absolute;
        top: 1000px;
        color: #000;
        font-size: 16px;
    }
    #does-amazon {
        margin-top: 610px;
    }
    #does-amazon .simple-block__subtitle, #invest-platform .list-with-icons-table__title {
        text-align: center;
        font-size: 22px;
    }
    .block-bottom .btn.btn-orange {
        padding: 13px 50px !important;
        font-size: 21px !important;
    }
    .block-bottom {
        padding: 20px 0;
    }
    #does-amazon .block-bottom, #does-amazon .warning-text {
        display: none;
    }
    #invest-platform .list-with-icons-table__list-item {
        width: 50%;
    }
    .list-with-icons-table__title {
        font-weight: 600;
        font-size: 23px;
    }
    .list-with-icons-table__text {
        margin-top: 30px;
        font-size: 16px;
        line-height: 150%;
    }
    #invest-platform {
        padding-top: 10px;
    }
    #invest-platform .list-with-icons-table__list-title {
        font-size: 12px;
    }

    #amzn-sign-form .simple-banner__image {
        position: absolute;
        top: 540px;
        z-index: 1;
        width: 80%;
        left: 10%;
    }
    .register-form__top {
        padding: 0 15px;
    }
    .register-form {
        top: -230px;
    }
    .list-with-icons-table {
        padding-top: 0;
        padding-bottom: 0;
    }
    #finishing-line.numbers {
        padding-top: 250px;
    }
    
    .numbers__list-content {
        width: 100%;
    }
    .why-block__list-item {
        width: 100%;
        max-width: 340px;
        padding: 0;
    }
    .why-block__list-text {
        margin-left: 65px;
    }
    
    .security__content {
        width: 96%;
        margin: auto;
        margin-left: 0.7rem;
        text-align: center;
    }
    .block_text {
        margin-top: 30px;    
    }
    #practical-traders .simple-banner__text div {
        height: 100px;
        width: 48%;
        padding: 25px 3px 15px 3px;
        min-height: 0;
    }
    #practical-traders .simple-banner__text div.line {
        height: 0;
    }
    #practical-traders .toptext_second {
        font-size: 24px;
        line-height: 1.5;
    }
    #practical-traders .toptext_third {
        text-align: center;
        font-weight: normal;
        font-size: 14px;
        line-height: 1;
    }
    #practical-traders .simple-banner__image:not(:first-child) {
        display: none;
    }
    #finishing-line.numbers {
        background: #ececec;
    }
    .why-block__title {
        padding: 0 8px;
    }
    .why-block__title .many_assets {
        font-size: 26px;
        line-height: 1;
        font-weight: normal;
        padding: 60px 0 20px 0;
    }
    .assets_second {
        font-size: 10px;
        line-height: 1;
    }
}
@media (min-width: 639px) and (max-width: 737px) {
    #amzn-sign-form .simple-banner__image {
        position: absolute;
        top: 710px;
        z-index: 1;
        width: 80%;
        left: 10%;
    }
    .why-block__image {
        max-width: 100%;
    }
}

@media (max-width: 639px) {
    #practical-traders {
        background-size: 100%;
        background-position: top left;
    }
    #amzn-sign-form .simple-banner__image {
        top: 450px;
    }
    #practical-traders .simple-banner__text .mobile-hide {
        position: relative;
        top: 1100px;
        color: #000;
        font-size: 16px;
        margin-bottom: 20px;
        width: 17rem;
        margin: auto auto;
        left: 0;
        right: 0;
    }
    #does-amazon {
        margin-top: 700px;
    }
    .numbers__list {
        padding: 40px;
    }
    .register-form {
        top: 40px;
    }
    .why-block__image {
        max-width: 100%;
    }
    .numbers {
        
    }
}

@media (max-width: 450px) {
    #finishing-line.numbers {
        padding-top: 310px;
    }
}
@media (max-width: 439px) {
    #practical-traders {
        background-size: 100%;
        background-position: top left;
    }
    #finishing-line.numbers {
        padding-top: 420px;
        margin-top: -120px;
    }
}
@media (max-width: 390px) {
    #finishing-line.numbers {
        padding-top: 450px;
    }
}
@media (max-width: 370px) {
    #finishing-line.numbers {        
        margin-top: -145px;
        padding-top: 520px;
    }
}
@media (min-width: 639px) and (max-width: 737px) {
    #amzn-sign-form .simple-banner__image {
        position: absolute;
        top: 710px;
        z-index: 1;
        width: 80%;
        left: 10%;
    }
    #invest-platform {
        padding-top: 10px;
    }
    #practical-traders .simple-banner__text .mobile-hide {
        position: relative;
        top: 1190px;
        color: #000;
        font-size: 16px;
        width: 23rem;
        margin: auto auto;
        left: 0;
        right: 0;
    }
    #does-amazon {
        margin-top: 650px;
    }
    .why-block__image {
        max-width: 100%;
    }

}
@media (min-width: 738px) and (max-width: 768px) {
    #amzn-sign-form .simple-banner__image {
        position: absolute;
        top: 750px;
        z-index: 1;
        width: 80%;
        left: 10%;
    }
    #invest-platform {
        padding-top: 10px;
    }
    #practical-traders .simple-banner__text .mobile-hide {
        position: relative;
        top: 1220px;
        color: #000;
        font-size: 16px;
        text-align: left;
        width: 80%;
        margin: auto auto;
        left: 0;
        right: 0;
    }
    .why-block__image {
        max-width: 100%;
    }

}
@media (min-width: 769px) and (max-width: 1023px) {
    .simple-banner__content {
        text-align: center;
    }
    .simple-banner .container, .simple-block .container, .list-with-icons-table .container {
        max-width: 80%;
    }
    .single-page.amzn #practical-traders {
        background-size: 100%;
        background-position: top left;
        padding-top: 10px;
        min-height: 530px;
    }
    #practical-traders p img {
        width: 70%;
        margin: auto auto;
        display: block;
    }
    #practical-traders .simple-banner__image {
        text-align: center;
        margin: auto auto;
    }
    #practical-traders .simple-banner__title {
        font-size: 20px;
        text-align: center;
    }
    #practical-traders .simple-banner__text p {
        float: none;
        line-height: 1.2;
        width: 100%;

    }    
    #practical-traders .simple-banner__text .mobile-hide {
        position: absolute;
        top: 1230px;
        color: #000;
        font-size: 16px;
        text-align: left;
        width: 70%;
        margin: auto auto;
        left: 0;
        right: 0;
    }
    #does-amazon {
        margin-top: 620px;
    }
    #does-amazon .simple-block__subtitle, #invest-platform .list-with-icons-table__title {
        text-align: center;
        font-size: 22px;
    }
    #does-amazon .block-bottom, #does-amazon .warning-text {
        display: none;
    }
    .block-bottom .btn.btn-orange {
        padding: 13px 50px !important;
        font-size: 21px !important;
    }
    .block-bottom {
        padding: 20px 0;
    }
    #invest-platform .list-with-icons-table__list-item {
        width: 50%;
    }
    .list-with-icons-table__title {
        font-weight: 600;
        font-size: 23px;
    }
    .list-with-icons-table__text {
        margin-top: 30px;
        font-size: 20px;
        line-height: 150%;
    }
    #invest-platform .list-with-icons-table__list-title {
        font-size: 12px;
    }

    #amzn-sign-form .simple-banner__image {
        position: absolute;
        top: 800px;
        z-index: 1;
        width: 80%;

        left:0;
        right:0;
        margin-left:auto;
        margin-right:auto;
    }
    .register-form__top {
        padding: 0 15px;
    }
    .list-with-icons-table {
        padding-top: 0;
        padding-bottom: 0;
    }
    #invest-platform {
        padding-top: 10px;
    }
    
    .numbers__list {
        padding: 6rem;
    }
    
    .why-block__image {
        max-width: 100%;
    }
    .toptext_second {
        font-size: 30px;
        text-align: center;
        line-height: 1.3;
    }
    .toptext_third {
        font-size: 16px;
    }
    .single-page .simple-banner__content {
        width: 100%;
    }
    .simple-banner__desktop {
        margin-left: 3rem;
    }
    #amzn-sign-form .register-form {
        top: -180px;
    }
    .fancybox-stage #amzn-sign-form .register-form {
        top: auto;
    }
    #finishing-line.numbers {
        padding-top: 720px;
        margin: -90px;
        background: #ececec;
    }    
    .block_text.b6 {
        margin-top: 26px;
    }
    .block_text.b9 {
        margin-top: 38px;
    }
}
@media (min-width: 1024px) {
    .simple-banner .container, .simple-block .container, .list-with-icons-table .container {
        max-width: 860px;
        /*margin-right: 6rem;*/
    }
    #practical-traders p img {
        width: 100%;
    }
    #practical-traders {
        min-height: 720px;
        background-size: 130%;
    }

    .list-with-icons-table__text p {
        margin-left: 70px;
    }
    #finishing-line.numbers {
        background: #fff;
        padding-top: 0;
    }
    .register-form {
        padding: 15px 20px 15px;
    }
}
@media (min-width: 1024px) and (max-width: 1440px) {
    #practical-traders p img {
        margin-left: 0;
        width: 80%;
    }
    #amzn-sign-form .simple-banner__image {
        position: absolute;
        top: 120px;
        left: 62%;
        z-index: 1;
        width: 36%;
        max-width: 460px;
    }
}
@media (min-width: 1440px) {
    .simple-banner .container, .simple-block .container, .list-with-icons-table .container {
        max-width: 1380px;
    }
    #practical-traders {
        background-size: 100%;
        background-position: top left;
        min-height: 750px;
    }
    #practical-traders p img {
        width: 100%;
        margin-top: -80px;
        margin-left: -20px;
    }
    #practical-traders .simple-banner__text p {
        line-height: 1;
        font-size: 12px;
    }
    #practical-traders .simple-banner__text p span{
        font-size: 34px;
        font-weight: bold;
    }
    #amzn-sign-form .simple-banner__image {
        position: absolute;
        top: 160px;
        left: 65%;
        z-index: 1;
        width: 35%;
        max-width: 470px;
    }
    #practical-traders .mobile-hide {
        font-size: 20px;
    }
    .numbers__list-item {
        margin-left: 20%;
    }
    #finishing-line.numbers {
        padding-top: 0;
        margin-top: 0;
    }
}
@media (min-width: 1280px) and (max-width: 1440px) {
    #practical-traders .simple-banner__text p {
        float: none;
        line-height: 1.2;
    }
    #amzn-sign-form .simple-banner__image {
        position: absolute;
        top: 120px;
        left: 63%;
        z-index: 1;
        width: 50%;
        max-width: 490px;
    }
    #practical-traders p img {
        margin-left: 0;
        width: 100%;
    }
    .numbers__list-item {
        margin-left: 3rem;
    }
    .block_text.b5 {
        margin-top: 34px;
    }
    .simple-banner .container, .simple-block .container, .list-with-icons-table .container {
        max-width: 1140px;
        margin-right: 4rem;
    }
}
@media (min-width: 1338px) {    
    .block_text.b1 {
        margin-top: 26px;
    }
}
@media (min-width: 1464px) {    
    .block_text.b5 {
        margin-top: 34px;
    }
}
@media (min-width: 1440px) and (max-width: 1600px) {
    #practical-traders {
        min-height: 800px;
    }
}
@media (min-width: 1600px) and (max-width: 1920px) {
    #practical-traders {
        min-height: 760px;
    }
}
@media (min-width: 1440px) and (max-width: 1920px) {    
    #practical-traders .simple-banner__text p {
        float: none;
        line-height: 1.2;
    }
}
@media (min-width: 1746px) {
    .block_text.b7, .block_text.b8 {
        margin-top: 34px;
    }
}

.fancybox-slide { text-align: left; }

.post-image img.elon {
    max-width: 100%;
}
.simple-banner .container {
        min-height: 0;
}
span.credits-right {
    display: inline-block;
}
    @media (min-width: 1024px) {
        #does-amazon .simple-block__media, #does-amazon .simple-block__content {
            float: left;

        }
        .left-column {
            width: 30%;
            float: right;
            padding: 20px 0 20px 20px;
        }
        .right-column {
            width: 50%;
            float: left;
            padding: 0 30px 20px 0;
            margin-top: 5px;
        }
        .right-column.bigger {
            width: 60%;
            padding: 0 20px 15px 0;
        }

    }
        span.img-credits span {
            float: left;
            clear: left;
            width: 55%;
            line-height: 18px;
        }
        p.after-credits {
            clear: left;
            padding-top: 20px;
        }
        span.credits-right {
            width:40%;
        }
    }
    @media only screen and (max-width: 1440px) {
        .simple-banner .container {
            min-height: 0;
        }
    }
</style>        </main>

   @include('include.footer')