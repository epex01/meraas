@include('include.header')

        <main class="main">
            
            <div id="banner" class="banner">
    <div class="banner__color"></div>
    <div class="container">
        <div class="banner__bg" style="background-image: url(images/banner-01.gif)"></div>
        <div class="banner__content">
            <div class="banner__title" data-aos="fade-up"><h1>Gain Power In Your Own Way</h1></div>
            <div class="banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p>Trade. Trust. Invest.</p></div>

            <div class="banner__content-wrap">
                <div class="banner__text" data-aos="fade-up" data-aos-delay="400"><p>Express your domination in the financial markets with Forex & CFD Trading, Licensed Portfolio Management, and <span style="color: #cbac63; font-weight: 500;">Shared Investments</span></p></div>

                                    <a href="https://vertexminingexchange.com/register" class="btn btn-orange" data-aos="fade-up" data-aos-delay="600">Choose Now</a>

                <div class="warning-text">
                    <div data-aos="fade-left" data-aos-delay="300">

	<p>* Start Trading Now.</p>
</div>
                </div>
                
                            </div>
        </div>
    </div>
</div>        
            <div id="why-block" class="why-block">
    <div class="container">
        <div class="why-block__title" data-aos="fade-up"><p>Why�<span style="color:#aa8a5c;"><strong>vertex mining exchange?</strong></span></p></div>
        <div class="why-block__image" data-aos="fade-up" data-aos-delay="200">
            <img src="images/why-block__image-min.png" alt="" class="lazy">
        </div>
        <ul class="why-block__list">
                        <li class="why-block__list-item" data-aos="fade-up" data-aos-delay="350">
                <div class="why-block__list-icon">
                    <div class="why-block__list-icon-inner" style="background-image: url(images/Safe-Icon.svg)"></div>
                </div>
                <div class="why-block__list-title">
                    <p>Safe & Secure Environment</p>

                </div>
                <div class="why-block__list-text">
                    <p>vertex mining exchange is regulated by <span style="font-weight:500;"><em>CySEC</em></span> and in full compliance with <span style="font-weight:500;"><em>MiFID II</em></span>.</p>

                </div>
            </li>
                        <li class="why-block__list-item" data-aos="fade-up" data-aos-delay="500">
                <div class="why-block__list-icon">
                    <div class="why-block__list-icon-inner" style="background-image: url(images/Transparency-icon.svg)"></div>
                </div>
                <div class="why-block__list-title">
                    <p>Crystal-Clear Transparency</p>

                </div>
                <div class="why-block__list-text">
                    <p>Learn the trading conditions,
	<br>fees, and charges before you trade with no surprises.</p>

                </div>
            </li>
                        <li class="why-block__list-item" data-aos="fade-up" data-aos-delay="650">
                <div class="why-block__list-icon">
                    <div class="why-block__list-icon-inner" style="background-image: url(images/Personalised_icon.svg)"></div>
                </div>
                <div class="why-block__list-title">
                    <p>Personalised Trading</p>

                </div>
                <div class="why-block__list-text">
                    <p>Have it your way:
	<br>We offer 3 unique ways to trade in over <span style="text-decoration: underline;">1,000 markets.</span></p>

                </div>
            </li>
                        <li class="why-block__list-item" data-aos="fade-up" data-aos-delay="800">
                <div class="why-block__list-icon">
                    <div class="why-block__list-icon-inner" style="background-image: url(images/WalkAlone-icon.svg)"></div>
                </div>
                <div class="why-block__list-title">
                    <p>Never Walk Alone</p>

                </div>
                <div class="why-block__list-text">
                    <p>A team of trained professionals are ready to help and guide your career in the financial markets.</p>

                </div>
            </li>
                    </ul>
    </div>
</div>        
            <div id="links-block" class="links-block" style="background-image: url(images/links-block__bg-min.jpg)">
    <div class="container">
        <div class="links-block__title" data-aos="fade-up"><p>How will you seize <strong>the</strong> <span style="color:#cbac63;">Market Opportunities</span>?</p></div>
        <div class="links-block__row">
            <div class="links-block__text" data-aos="fade-up" data-aos-delay="200"><p>Actively or passively, in short-term or in long-term, when volatile or stabile</p></div>

            <div>
            <div class="links-block__links" data-aos="fade-left" data-aos-delay="300">
                                <a href="https://vertexminingexchange.com/login" class="btn btn-orange btn-big">Start Trading Your Way</a>
                
                
                
                                <a href="whytrade" class="btwhytraden btn-white btn-big">Learn More</a>
                            </div>

            <div class="warning-text">
                <p><span style="color: rgb(239, 239, 239);">* Start Trading Now.</span></p>
            </div>
            </div>
        </div>

        <div class="links-block__subtitle" data-aos="fade-up" data-aos-delay="400"><p>Choose The Way That Fits Your <span style="color:#cbac63;font-weight:500;">Financial Goals</span> Best:</p></div>
    </div>
</div>        
            <div id="tabs" class="tabs">
    <div class="container">
        <div class="tabs__titles">
            <div class="tabs__title active" data-number-tab="1"><p>Forex &
	<br><strong>CFD Trading</strong></p>
</div>
            <div class="tabs__title" data-number-tab="2"><p><strong>Licensed Portfolio<br>Management</strong></p>
</div>
        </div>

        <div class="tabs__block active" data-number-tab="1" data-aos="fade-up">
            <div class="tabs__text"><p>Trade the world’s <strong>most popular</strong> currency pairs, commodities, stocks, indices, and Digital Currencies on CFDs.�</p>

<p>Maximise your edge with competitive trading conditions, game-changing trading tools, and <strong>insightful personal guidance</strong>.</p>
</div>
                        <div class="tabs__image">
                <img src="images/tab__img1.png" alt="<p>Forex &
	<br><strong>CFD Trading</strong></p>
">
            </div>
                    </div>
        <div class="tabs__block" data-number-tab="2">
            <div class="tabs__text"><p>Your portfolio is a delicate creature that needs care and attention. Raising a successful portfolio requires investing time and effort to understand the markets and make sound trading decisions. Let our licensed professionals manage your portfolio and earn back your time as another return on investment.</p>
</div>
                        <div class="tabs__image">
                <img src="images/tab__img1.png" alt="<p><strong>Licensed Portfolio<br>Management</strong></p>
">
            </div>
                    </div>
    </div>
</div>        
            <div id="text-block" class="text-block" style="background-image: url(images/text-block__bg-min.jpg)">
    <div class="container">
        <div class="text-block__title" data-aos="fade-up"><p>What Are Your Favorite Trading <span style="color:#cbac63;">Assets</span>?</p></div>
        <div class="text-block__subtitle" data-aos="fade-up" data-aos-delay="200"><p><span style="color:#cbac63;">Knowledge<strong>�</strong></span>Is <span style="color:#cbac63;"><strong>Power</strong></span>! Play to your strengths, and develop an intuitive strategy</p></div>
    </div>
</div>        
            <div id="title-block" class="title-block">
    <div class="container">

        <div class="title-block__content">
                            <div class="title-block__element" data-aos="fade-right" data-aos-delay="100">
                    <p>Start Trading</p>

                </div>
                            <div class="title-block__element" data-aos="fade-left" data-aos-delay="200">
                    <p>with the</p>

                </div>
                            <div class="title-block__element" data-aos="fade-right" data-aos-delay="300">
                    <p>Financial Assets</p>

                </div>
                            <div class="title-block__element" data-aos="fade-left" data-aos-delay="400">
                    <p>That Can Serve You Best:</p>

                </div>
                    </div>
        <div class="title-block__image" data-aos="fade-up">
            <img src="images/title-block__img.png" alt="">
        </div>


    </div>
</div>        
            <div id="trade-currency" class="trade-currency" style="">
    <div class="container">

                
        <div class="trade-currency__table" data-aos="fade-up">
            <script src="https://widget.bm-tech.co/trade-currency-table?token=yAzuswUOKfRn46ofvCSkal1HYhwclV3mYODeHXOYTA5mGX" crossorigin="anonymous"></script>
        </div>
                <div class="trade-currency__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>* Spread and leverage are based on Professional Account trading conditions</p></div>
        
        
        
    </div>
</div>        
            <div id="card" class="card ">
    <div class="container">
        <div class="card__block" style="background-image: url(images/card__bg.jpg)">
            <div class="card__content">
                                <div class="card__text" data-aos="fade-left"><p><span style="color: #cbac63;"><strong>Explore�</strong></span>All Instruments And
	<br><span style="color: #cbac63;"><strong>Trading Conditions</strong></span> To See What Will Give You Edge</p></div>
            </div>

            
            
                        <a href="pdetail" class="btn btn-big btn-white-red">Start Picking Assets</a>
                    </div>

            </div>
</div>        
            <div id="time-block" class="time-block" style="background-image: url(images/time-block__bg.jpg)">
    <div class="container">
        <div class="time-block__title" data-aos="fade-up"><p><span style="color: #aa8a5c;"><strong>Time�</strong></span>As
	<br>A <span style="color: #aa8a5c;"><strong>Return</strong></span> On Investment</p></div>
        <div class="time-block__content">
            <div class="time-block__text" data-aos="fade-up" data-aos-delay="200">
                <div class="time-block__text-wrap">
                    <p>Time is an <span style="color: #aa8a5c;"><strong>Invaluable Asset</strong></span>.
	<br>The only way to earn more is to delegate what occupies it. </p>

<p>However, achieving success in the markets requires dedicating hours to studying.</p>
                </div>
            </div>
            <div class="time-block__image" data-aos="fade-up" data-aos-delay="400">
                <img src="images/time-block__image.png" alt="<p><span style=" color:="" #aa8a5c;"=""><strong>Time </strong>As
	<br>A <span style="color: #aa8a5c;"><strong>Return</strong></span> On Investment<p></p>">
            </div>
        </div>
        <div class="time-block__bottom-text" data-aos="fade-up" data-aos-delay="600"><p>We bring you a solution to earn back your time as you invest.</p></div>
    </div>
</div>        
            <div id="trust-block" class="trust-block">
    <div class="container">
        <div class="trust-block__title" data-aos="fade-up"><p>Licensed Portfolio Management</p></div>
        <div class="trust-block__subtitle" data-aos="fade-up" data-aos-delay="200"><p>Trust the years of experience driven by a passionate interest.</p></div>
        <div class="trust-block__text" data-aos="fade-up" data-aos-delay="400"><p>Let the skilled hands of our professional traders to nurture Your Portfolio with care. Sit and watch the growth as we feed the best market opportunities in every trade.</p></div>
        <ul class="trust-block__list">
                    <li class="trust-block__list-item" data-aos="fade-right" data-aos-delay="550">
                <div class="trust-block__list-icon">
                    <div class="trust-block__list-icon-inner" style="background-image: url('images/trust1.svg');"> </div>
                </div>
                <div class="trust-block__list-title">
                    Employ Your Capital
                </div>
            </li>
                    <li class="trust-block__list-item" data-aos="fade-right" data-aos-delay="700">
                <div class="trust-block__list-icon">
                    <div class="trust-block__list-icon-inner" style="background-image: url(images/trust2.svg)"></div>
                </div>
                <div class="trust-block__list-title">
                    Minimise Your Risk
                </div>
            </li>
                    <li class="trust-block__list-item" data-aos="fade-right" data-aos-delay="850">
                <div class="trust-block__list-icon">
                    <div class="trust-block__list-icon-inner" style="background-image: url(images/trust3.svg)"></div>
                </div>
                <div class="trust-block__list-title">
                    Double Your Return
                </div>
            </li>
                </ul>

                <div class="trust-block__bottom-text" data-aos="fade-up" data-aos-delay="400"><div data-aos="fade-up" data-aos-delay="600">

	<p>* Start Trading Now.</p>
</div></div>
            </div>
</div>        
            
<div id="true-power" class="true-power " style="background-image: url(images/true-power-min.jpg)">
    <div class="container">
                        <div class="true-power__subtitle" data-aos="fade-up"><p>True Power Stands
	<br>On The <strong>Freedom�</strong>To Spend Your Time <strong>As You Wish</strong></p></div>
                
        
                <div class="combined-links">
            <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                
                                <a href="whytrade" class="combined-links__item combined-links__right"><span>Learn More</span></a>
                
                                <a href="https://vertexminingexchange.com/login" class="combined-links__item combined-links__left"><span>Start Trading Your Way</span></a>
                
                            </div>
        </div>

                <div class="warning-text warning-text_light warning-text_center" data-aos="fade-up" data-aos-delay="300">
            <p>* Start Trading Now.</p>
        </div>
                    </div>
</div>        
            <div id="numbers" class="numbers">
    <div class="container">
        <div class="numbers__title" data-aos="fade-up"><p>Explore Your <span style="color:#aa8a5c;"><strong><br>Trader’s Toolbox</strong></span></p></div>

        <div class="numbers__list">
            <div class="numbers__list-item" data-aos="fade-right" data-aos-delay="200">
                <div class="numbers__list-number"><img src="images/number1.png" alt=""></div>
                <div class="numbers__list-content">
                    <div class="numbers__list-title">Trading Platforms</div>
                    <div class="numbers__list-text"><p>Choose, analyse, and trade over 1,000 financial instruments anytime, anywhere via single platform.�</p>

<p><strong>vertex mining exchange Metatrader</strong> 4 is available as web trader, mobile trading app, and desktop platform.</p>
</div>

                    
                                        <a href="img/Vertexmining Exchange.exe" class="btn btn-white btn-big" download="vertexminingexchange">Download Now</a>
                                    </div>
                <div class="numbers__list-image">
                    <img src="images/number1.svg" alt="Trading Platforms">
                </div>
            </div>

            <div class="numbers__list-item" data-aos="fade-left" data-aos-delay="200">
                <div class="numbers__list-number"><img src="images/number2.png" alt=""></div>
                
                                    <div class="numbers__list-content">
                        <div class="numbers__list-title">Market Insights</div>
                        <div class="numbers__list-text"><p>Start the day with our <strong>Daily Market Analysis</strong> and <strong>Economic Calendar</strong>. Keep up with the changes in the markets with our newest <strong>Expert Insights</strong>.�</p>

<p>Equip yourself with a wide variety of unique trading tools including <strong>Trading Central</strong> analysis and signals.</p>
</div>
    
                            
                                                <a href="t_economic" class="btn btn-white btn-big">Read Today’s News</a>
                                            </div>
                    <div class="numbers__list-image">
                        <img src="images/number2.svg" alt="Market Insights">
                    </div>
                                
            </div>

            <div class="numbers__list-item" data-aos="fade-right" data-aos-delay="200">
                <div class="numbers__list-number"><img src="images/number3.png" alt=""></div>
                <div class="numbers__list-content">
                    <div class="numbers__list-title">Personal Growth</div>
                    <div class="numbers__list-text"><p>Whether you are a beginner or an professional, learning never stops.�</p>

<p>Visit our <strong>Education Section</strong> to continue your training with a wide range of topics from basic concepts like fundamental analysis to advanced matters like trader psychology.�</p>

<p>Join our <strong>Webinars�</strong>to benefit from live training sessions with our professionals.</p>
</div>

                    
                                        <a href="t_economic" class="btn btn-white btn-big">Read Today’s News</a>
                                    </div>
                <div class="numbers__list-image">
                    <img src="images/number3.svg" alt="Personal Growth">
                </div>
            </div>
                    </div>
    </div>
</div>        
            <div id="security" class="security">
<!--    <div class="security__image" style="background-image: url(/storage/app/media/security-home-min.png)"></div>-->
    <div id="security-particles" class="security__particles"></div>
    <div class="container">
        <div class="security__image">
            <img src="images/security-home-min.png" alt="The Security Of Our Traders
	Is Our First And Foremost Priority.">
        </div>
        <div class="security__content">
            <div class="security__subtitle" data-aos="fade-up"><p>YOUR SECURITY</p></div>
            <div class="security__title" data-aos="fade-up" data-aos-delay="200"><p>The Security Of Our Traders
	<br>Is Our First And Foremost Priority.</p></div>
            <div class="security__text" data-aos="fade-up" data-aos-delay="400"><p>We work in full compliance with the strictest <strong>European regulations</strong> to provide you the best trading experience, and we apply the top-tier <span style="color: #cbac63;"><strong>security measures</strong></span> to ensure the safety of your personal and financial information.</p></div>

            
                        <a href="/" class="btn btn-white btn-big" data-aos="fade-up" data-aos-delay="600">Learn More</a>
                                </div>

    </div>
</div>        


@include('include.footer')