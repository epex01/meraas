@include('include.header')

<main class="main">
            
            

<div id="banner" class="simple-banner style2  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Trade Indices with Vertexmining Exchange</h1></div>
                                <div class="simple-banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p>Get exposure to the global stock market by trading the DOW30, NASDAQ100, FTSE100, DAX30 and other major indices with Vertexmining Exchange.</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p>with Vertexmining Exchange, you can trade the <strong>most
popular global indices </strong>as CFDs via a convenient online trading platform.</p>

<p><strong>Start trading precious metals with Vertexmining Exchange</strong></p></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

        
                     <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                <script src="https://widget.bm-tech.co/trade-currency-table?token=vjRJabgSUJHGIuEyonmYi61H83zLQaeGBs8cbverUceWqi" crossorigin="anonymous"></script>
            </div>
        
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p>with Vertexmining Exchange, you can trade the <strong>most
popular global indices </strong>as CFDs via a convenient online trading platform.</p>

<p><strong>Start trading precious metals with Vertexmining Exchange</strong></p></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            <div id="introduction" class="text-center-block-big style2" style="background-image: url(images/intro-indices-min.jpg)">
    <div class="container">
                <div class="text-center-block-big__title title title_center" data-aos="fade-up"><p>Why <span style="font-weight:800;color:#cbac63;">Trade Indices?</span></p></div>
                        <div class="text-center-block-big__subtitle" data-aos="fade-up" data-aos-delay="100"><p>A stock market index is both a benchmarking tool and a financial instrument that derives its value from a collection of underlying stocks.</p></div>
                <div class="text-center-block-big__text" data-aos="fade-up" data-aos-delay="200"><p>The companies which form an index are selected based on various criteria, such as market capitalisation, average daily trading volume and are categorised based on region, industry, and the exchange where shares are traded. How the value of an index is calculated varies depending on the rules set by the index creator. For example, the S&amp;P500 Index<span lang="en-US">,&nbsp;</span>was created by Standard and Poor’s measures the performance of 505 companies. The constituents<span lang="en-US">&nbsp;</span>are selected by a committee and are listed on exchanges in the U.S. The price of an index reflects the performance of an industry or an entire stock market. Indices are also tradable instruments offered by derivative brokers like Vertexmining Exchange.</p></div>

            </div>
</div>        
            <div id="" class="offer" style="background-image: url(images/stocks-benefits-min.jpg);">


    <div class="container">
        <div class="offer__block" data-aos="fade-up">
            <div class="offer__block-top">
                <div class="offer__title title title_center"><p>The Benefits Of <span style="font-weight:800;color:#aa8a5c;">Trading Indices CFDs</span></p></div>
                <div class="offer__subtitle text"></div>
                <div class="offer__text text"><p>Trading indices using Contracts for Difference (CFDs) offers many benefits compared to other methods of speculating on the stock market.</p></div>

                <div class="offer__list">
                                        <div class="offer__list-title"></div>
                    <div class="offer__list-subtitle"></div>
                    <div class="offer__enumeration">
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Less volatile than investing in a single stock</div>
                            <div class="offer__enumeration-text">Indices consist of dozens and even hundreds of stocks which means if one stock or even an entire sector falls in value, the rest of the stocks within the index will help limit the effect.</div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">A lower-cost way to speculate on the stock market</div>
                            <div class="offer__enumeration-text">When you purchase stocks, fees need to be paid to the exchange, clearinghouse, custodial, and broker. Trading CFDs doesn’t involve physical ownership and therefore reduces transaction costs.</div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Instant cash settlement when you close positions</div>
                            <div class="offer__enumeration-text">With CFDs, your margin plus and profit or loss is available in your trading account the moment you close a position, allowing you to trade other products immediately. </div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Easier to analyse</div>
                            <div class="offer__enumeration-text">Compared to other markets, such as forex, Indices are relatively easier to analyse and build a trading strategy around due them being localised to specific sectors and locations. </div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Go long or short and hedge your positions</div>
                            <div class="offer__enumeration-text">When using CFDs, you’re able to open short positions and potentially benefit when prices fall. With hedging, you’re able to go long and short concurrently to increase the chance of protecting your positions.</div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Indices can be traded at any time of the day</div>
                            <div class="offer__enumeration-text">Unlike stocks, which can only be traded during fixed hours each day, Indices are available to trade almost twenty-four hours per day, five days a week.</div>
                        </div>
                                            </div>
                                    </div>
                            </div>

            <div class="offer__block-bottom">
                                    <a href="register"  class="btn btn-orange">Sign up</a>

                    <div class="warning-text">
                        <p>* Start Trading Now.</p>
                    </div>
                
                            </div>
        </div>
    </div>
</div>        
            
<div id="what-we-offer" class="simple-block right  style1  empty_padding_top empty_padding_bottom wide_content round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/we-offer-indices-min.jpg" alt="What We Offer" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>What <span style="font-weight:800;color:#aa8a5c;">We Offer</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption"><p>The most convenient trading platforms</p>
</div>
                                                <div class="simple-block__list-text"><p><span lang="en-US">Trade CFDs of global indices from a convenient
mobile application, web trading application, or the advanced MT4
trading platform.</span></p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption"><p>A variety of stock indices</p>
</div>
                                                <div class="simple-block__list-text"><p><span lang="en-US">Access to international markets. You can trade
more than twenty different stock indices from major economies around
the world.</span></p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption"><p>Low spreads &amp; commission</p>
</div>
                                                <div class="simple-block__list-text"><p>Take advantage of low-cost access to global stock markets thanks to tight spreads and low commissions when you trade precious metals with Vertexmining Exchange.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="900">
                        <div class="simple-block__list-caption"><p>The best support and guidance</p>
</div>
                                                <div class="simple-block__list-text"><p>Every Vertexmining Exchange customer receives the same premium support from our specialists. Some accounts qualify for relationship managers and mentorship.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="trading-accounts" class="tariffs style3  "
     style="     background: #ffffff;">

    <div class="container">
                <div class="tariffs__title title title_center" data-aos="fade-up"><p>Trading <span style="font-weight:800;color:#aa8a5c;">Accounts</span></p></div>
                                <div class="tariffs__text" data-aos="fade-up" data-aos-delay="100"><p>Choose the right trading account to match your investment goals. Whether you’re a day-trader looking to profit from short term price movements or a position trader, looking to benefit from the long-term appreciation or depreciation of global indices, Vertexmining Exchange has a suitable account for you.</p>

<p><strong>Here are the four most popular trading
accounts for index CFD traders</strong></p></div>
        
        
        
                <div class="tariffs__list">
                                    <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#B14421;">BRONZE</strong></p>
</div>
                <div class="tariffs__item-content style1">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariff__silver.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €1,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pips</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£12 per lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#aaabad;">PREMIUM</strong></p>
</div>
                <div class="tariffs__item-content style2">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariffs-premium-2.png)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €50,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pips</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£7 per lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#D8B177;">GOLD</strong></p>
</div>
                <div class="tariffs__item-content style1">
                    <div class="tariffs__item-bg" style="background-image: url(images/gold.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €5,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pips</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£10 per lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong>SILVER</strong></p>
</div>
                <div class="tariffs__item-content style1">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariff__bronze.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €2,500</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pips</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£11 per lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
                        <div class="tariffs__list-separator"></div>
            
                    </div>
        
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>* Start Trading Now.</p>

<p>
	<br>
</p>

<p>If you can’t find the right trading account, don’t worry. We’ve got more options waiting for you.</p>

<p><span style="color:#aa8a5c;"><strong>View all Vertexmining Exchange trading accounts</strong></span></p></div>
    </div>
</div>        
            <div id="how-open-trading-account" class="numeral-links style2" style="background-image: url(images/open-account-indices-min.jpg)">
    <div class="container">
                <div class="numeral-links__title title title_center"  data-aos="fade-up"><p><span style="font-weight:800;color:#aa8a5c;">How To Open</span> A Trading Account?</p></div>
                        <div class="numeral-links__text"  data-aos="fade-up"><p>Open your Vertexmining Exchange trading account in <strong>four simple steps.</strong></p></div>
        
                <div class="numeral-links__link" data-aos="fade-up" data-aos-delay="200">
            <a href="register"  class="btn btn-orange btn-little">Sign up</a>

            <div class="warning-text warning-text_center" data-aos="fade-up" data-aos-delay="200">
                <p>* Start Trading Now.</p>
            </div>
        </div>
        
        
        <ul class="numeral-links__list">
                            <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">01</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Sign-up</div>
                        <div class="numeral-links__item-subtitle">Simply click the sign-up button and provide your personal information in the registration form.</div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">02</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Verify</div>
                        <div class="numeral-links__item-subtitle">Verify your account by uploading your proof of identity and proof of address documents.</div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">03</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Choose</div>
                        <div class="numeral-links__item-subtitle">Once your Vertexmining Exchange trading account is verified, it’s time to choose your trading platform and your preferred trading account. </div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">04</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Fund</div>
                        <div class="numeral-links__item-subtitle">Fund your trading account using one of our secure payment methods to start trading indices.</div>
                    </div>
                </a>
            </li>
                              </ul>
    </div>
</div>        
            <div id="want-practice-first" class="card style3" style="background: #ffffff;">
    <div class="container">
        <div class="card__block" style="background-image: url(images/practice-min.jpg)">
            <div class="card__content">
                                <div class="card__title" data-aos="fade-left"><p>Want To <span style="font-weight:800;color:#cbac63;">Practice First?</span></p></div>
                                <div class="card__text" data-aos="fade-left"><p><span style="font-weight:800;color:#cbac63;">Practice makes perfect.</span> That’s why we give all clients a free lifetime demo trading account to polish their skills for trading indices.</p></div>
            </div>

            
                        <a href="register"  class="btn btn-big btn-white-red">Get a demo account</a>
            
                    </div>

                <div class="warning-text">
            <p>* Start Trading Now.</p>
        </div>
            </div>
</div>        
            
<div id="trade-indices-online" class="tariffs style2  "
     style="background-image: url(images/trade-indices-min.jpg);     ">

    <div class="container">
                <div class="tariffs__title title title_center" data-aos="fade-up"><p>Trade <span style="font-weight:800;color:#cbac63;">Indices Online</span></p></div>
                        <div class="tariffs__subtitle" data-aos="fade-up" data-aos-delay="100"><p><span lang="en-US">Vertexmining Exchange offers two premium online trading platforms
to analyse and trade the world’s most active indices. Detailed
charts show years of historic price information for all available,
including S&amp;P500, FTSE100, NIKKEI, DAX30, and NASDAQ100.</span></p></div>
                        <div class="tariffs__text" data-aos="fade-up" data-aos-delay="100"><p><span lang="en-US">We offer MetaTrader 4, the world’s most popular
and advanced trading platform with endless capabilities. Our very own
Vertexmining Exchange trading platform, which is ideal for beginners looking for a
modern trading interface.</span></p></div>
        
        
        
        
                <div class="tariffs__equal-list">
                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>MetaTrader 4</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Available on desktop, web, iOS and Android devices</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Automated trading with Expert Advisors</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Advanced charting and technical analysis capabilities</div>
                                                    </li>
                                            </ul>

                    
                                        <div class="combined-links">
                        <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                                                        <a href="register" class="combined-links__item combined-links__right">Open account</a>
                            
                            
                            
                                                        <a href="../index" class="combined-links__item combined-links__left">Learn more</a>
                                                    </div>
                    </div>
                                    </div>

            </div>

                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>Vertexmining Exchange Trader</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Available on web, iOS and Android</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Easy to navigate 1000s of trading instruments</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Modern design and sleek interface</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Loaded with the most popular market analysis tools</div>
                                                    </li>
                                            </ul>

                    
                                        <div class="combined-links">
                        <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                                                        <a href="register" class="combined-links__item combined-links__right">Open account</a>
                            
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Learn more</a>
                                                    </div>
                    </div>
                                    </div>

            </div>

                                </div>
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>* Start Trading Now.</p></div>
    </div>
</div>        
            
<div id="" class="simple-block right  style4  " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/indices.jpg" alt="DAX30: Europe’s Most Active Stock Market Index" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p><span style="font-weight:800;color:#aa8a5c;">DAX30:</span> Europe’s Most Active Stock Market Index</p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>The DAX30, also known as the Germany 30 index, follows the top thirty companies traded on the Frankfurt Stock Exchange in Germany. The DAX launched on 1 July 1988, and since then, the index has become one of Europe's most actively traded indices.</p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="most-popular-indices" class="simple-block left  style2  wide_content " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                                    <div class="simple-block__image stick" data-sticky-class="sticking">
                <div data-aos="fade-right">
                                        <div class="simple-block__media-inside-title"><p>Most Popular <strong>Indices</strong></p></div>
                                        <img src="images/indices-most-popular-min.jpg" alt="">
                </div>
            </div>
            
                    </div>

        <div class="simple-block__content">
            <div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>Trade the most popular stock market indices with Vertexmining Exchange.</p></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">US30 (Wall Street 30)</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Measures the value of the 30 largest publicly listed companies in the U.S. Constituents include Apple, Boeing, Chevron and more.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">DAX30 (Germany 30)</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Measures the value of the 30 largest publicly listed companies on the Frankfurt Stock Exchange. Constituents include Adidas, Bayer, Lufthansa, and more.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">NASDAQ100 (US Tech 100)</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Measures the value of the 100 largest technology companies listed on the NASDAQ stock exchange. Constituents include Adobe, Amazon, Facebook, Microsoft, and more.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="900">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">FTSE100 (UK 100)</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Measures the value of 100 companies listed on the London Stock Exchange. Constituents include BP, Barclays, Tesco, and more.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="1050">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">S&amp;P500 (US 500)</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Measures the value of 500 large-cap companies listed on various stock exchanges in the U.S. Constituents include American Express, AT&amp;T, Coca-Cola, and more.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="1200">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">ASX200 (Australia 200)</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Measures the value of 200 companies listed on the Australian Stock Exchange. Constituents include Qantas Airways, Australia &amp; New Zealand Banking Group (ANZ), and more.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                                                
                                <div class="simple-block__link simple-block__link_center" data-aos="fade-left" data-aos-delay="300">
                                        <a href="register" class="btn btn-small btn-orange">Start Trading Indices</a>
                    <div class="warning-text">
                        <p>* Start Trading Now.</p>
                    </div>
                    
                                    </div>
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="we-offer-more-than-indices" class="simple-block right  style1 small_padding  empty_padding_top round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/indices2-min.jpg" alt="" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                                <div class="simple-block__subtitle" data-aos="fade-left"><p><span style="color: rgb(110, 35, 10);">We offer more than indices</span></p></div>
                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p><span lang="en-US">If you want to trade the NASDAQ100 or the FTSE100,
then you’ve come to the right place. However, suppose you’re
interested in diving deeper into the world of equities and investing.
In that case, you might be pleased to know that Vertexmining Exchange also offers
the ability to trade the shares of hundreds of publicly listed
companies from around the world. with Vertexmining Exchange you can trade stocks
listed on the NYSE, NASDAQ, LSE and more.</span></p>

<p><span class="simple-block__subtitle" style="color: rgb(110, 35, 10);">The home of investing</span></p>

<p>Our vision is to provide a one-stop destination for traders and investors to access a wide range of products in the financial markets. With one trading account, you can discover hundreds of financial instruments. If you don’t see any good trading opportunities in the indices market, you could easily view the charts of numerous forex pairs, stocks, precious metals and more. If you do find an opportunity, you can go right ahead and open a position. There is no need to open a new account or change any settings.</p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="speak-account-manager" class="true-power " style="background-image: url(images/true-power-min.jpg)">
    <div class="container">
                        <div class="true-power__subtitle" data-aos="fade-up"><div style="max-width: 450px;margin-left:auto;margin-right:auto;">

	<p><span style="font-weight:800;">Speak to an account manager</span> to find out more.</p>
</div></div>
                
        
                <div class="combined-links">
            <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                
                                <a href="products" class="combined-links__item combined-links__right"><span>View all products</span></a>
                
                
                                <a href="contactus" class="combined-links__item combined-links__left"><span>Get in touch</span></a>
                            </div>
        </div>

                    </div>
</div>        
            <div id="social-links" class="social-links" style="background: #ffffff;">
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

       @include('include.footer')