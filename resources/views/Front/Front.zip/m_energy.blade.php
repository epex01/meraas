@include('include.header')

      <main class="main">
            
            

<div id="banner" class="simple-banner style2  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Trade Energy Products
	<br>with Vertexmining Exchange</h1></div>
                                <div class="simple-banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p>Trade Brent, West Texas, Natural Gas and other popular energy products that fuel the global financial markets.</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p>With a Vertexmining Exchange CFD trading account, you can access the <strong>most
important energy products&nbsp;</strong>via a convenient online trading platform.</p>

<p><strong>Start Trading Oil and Gas CFD’s with Vertexmining Exchange</strong></p></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

        
                     <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                <script src="https://widget.Vertexmining Exchange.io/trade-currency-table?token=Ty4EUfYKbyJsxrWjbdpfKBnKP7L4gNgFm09FIa2IrCT3Re" crossorigin="anonymous"></script>
            </div>
        
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p>With a Vertexmining Exchange CFD trading account, you can access the <strong>most
important energy products&nbsp;</strong>via a convenient online trading platform.</p>

<p><strong>Start Trading Oil and Gas CFD’s with Vertexmining Exchange</strong></p></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            <div id="introduction" class="text-center-block-big style2" style="background-image: url(images/intro-energy-min.jpg)">
    <div class="container">
                <div class="text-center-block-big__title title title_center" data-aos="fade-up"><p>Introduction To <span style="font-weight:800;color:#cbac63;">Trading Energy Commodities</span></p></div>
                        <div class="text-center-block-big__subtitle" data-aos="fade-up" data-aos-delay="100"><p>Economists believe money makes the world go round. Most other business people would argue that oil and gas are what powers the global economy.</p></div>
                <div class="text-center-block-big__text" data-aos="fade-up" data-aos-delay="200"><p>Oil is the foundation of consumerism; whether it’s making plastics, powering manufacturing plants or fueling ships and planes, energy is what powers progress. The price of energy products is considered a global benchmark for economic prosperity. Because of how essential oil and gas are to the worldwide economy, they are among the most liquid trading assets in the world and traded in all major financial hubs and timezones. The price of oil can experience volatility not just because of fluctuations in demand, but also due to logistical or geopolitical factors affecting supply. Oil is produced in only a few regions of the world and is incredibly complex to extract and refine.</p></div>

            </div>
</div>        
            <div id="" class="offer" style="background-image: url(images/energy-benefits-min.jpg);">


    <div class="container">
        <div class="offer__block" data-aos="fade-up">
            <div class="offer__block-top">
                <div class="offer__title title title_center"><p>The Benefits Of&nbsp;<span style="font-weight:800;color:#aa8a5c;">Trading Energy Commodities As CFDs</span></p></div>
                <div class="offer__subtitle text"></div>
                <div class="offer__text text"><p>Energy comes in different formats, Brent &amp; West Texas crude oil, gasoline and natural gas, all of which you can trade as popular CFD instruments online with Vertexmining Exchange.</p></div>

                <div class="offer__list">
                                        <div class="offer__list-title"></div>
                    <div class="offer__list-subtitle"></div>
                    <div class="offer__enumeration">
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">No physical ownership necessary</div>
                            <div class="offer__enumeration-text">With CFDs, you can get exposure to 1,000s of barrels of oil and hundreds of cubic feet of natural gas with a click of a button. There is no need to take physical delivery or pay storage fees.</div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Go long or short</div>
                            <div class="offer__enumeration-text">When using CFDs, you’re able to open short positions, which allow you to hedge against a contracting global economy and speculate on energy prices falling. </div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Use leverage to decrease capital requirements</div>
                            <div class="offer__enumeration-text">You’re able to leverage your positions by as much as 1:0 on commodities. Using leverage reduces how much of your account balance is reserved to open a CFD position.</div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Trade energy products at any time of the day</div>
                            <div class="offer__enumeration-text">As an international broker, we have access to pricing from major commodities exchanges around the world. Even if markets are closed in Europe, you can benefit from after-hours trading with Vertexmining Exchange.</div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Easily open and close positions</div>
                            <div class="offer__enumeration-text">Energy products are the most liquid financial assets in the world. By trading CFDs online, you can open and close your trades in a moments notice. There is no need to negotiate a deal with buyers and sellers.</div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Hedge your trades</div>
                            <div class="offer__enumeration-text">With hedging, you’re able to have long and short positions at the same time. If you see a long-term buy opportunity and a short-term sell opportunity, nothing is stopping you from doing both.</div>
                        </div>
                                            </div>
                                    </div>
                            </div>

            <div class="offer__block-bottom">
                                    <a href="register"  class="btn btn-orange">Sign up</a>

                    <div class="warning-text">
                        <p>* Start Trading Now. &nbsp;</p>
                    </div>
                
                            </div>
        </div>
    </div>
</div>        
            
<div id="what-we-offer" class="simple-block right  style1  empty_padding_top empty_padding_bottom wide_content round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/energy-offer.jpg" alt="What We Offer" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>What <span style="font-weight:800;color:#aa8a5c;">We Offer</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">The most convenient trading platforms</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Use CFDs to trade the most liquid energy markets from a convenient mobile app, web trading interface, or the advanced MT4 trading platform.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">A variety of precious metals</span></p>
</div>
                                                <div class="simple-block__list-text"><p>You can trade CFDs four different energy products with Vertexmining Exchange; Brent Crude Oil, West Texas Intermediary (WTI), natural gas and gasoline, all quoted in US dollars.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">Low spreads &amp; fees</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Low spreads &amp; fees</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="900">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">Helpful insights and analysis</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Get helpful reports, market analysis and a suite of useful tools and information to help you navigate the energy commodities market.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="trading-accounts" class="tariffs style3  "
     style="     background: #ffffff;">

    <div class="container">
                <div class="tariffs__title title title_center" data-aos="fade-up"><p>Trading <span style="font-weight:800;color:#aa8a5c;">Accounts</span></p></div>
                                <div class="tariffs__text" data-aos="fade-up" data-aos-delay="100"><p>Choose the right trading account to match your investment goals. Whether you’re a day-trader looking to profit from short term price movements or a position trader, looking to benefit from the long-term appreciation or depreciation of precious metals, then Vertexmining Exchange probably has a suitable account for you.</p>

<p><strong>Here are the four most popular trading accounts for precious metals traders.</strong></p></div>
        
        
        
                <div class="tariffs__list">
                                    <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#B14421;">BRONZE</strong></p>
</div>
                <div class="tariffs__item-content style1">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariff__bronze.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €1,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£12 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#D8B177;">GOLD</strong></p>
</div>
                <div class="tariffs__item-content style1">
                    <div class="tariffs__item-bg" style="background-image: url(images/gold.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €5,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£10 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#aaabad;">PREMIUM</strong></p>
</div>
                <div class="tariffs__item-content style2">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariffs-premium-2.png)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €50,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£7 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong>SILVER</strong></p>
</div>
                <div class="tariffs__item-content style1">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariff__silver.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €2,500</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£11 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
                        <div class="tariffs__list-separator"></div>
            
                    </div>
        
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>* Start Trading Now.</p>

<p>
	<br>
</p>

<p>If you can’t find the right trading account, don’t worry. We’ve got more options waiting for you.</p>

<p><span style="color:#aa8a5c;"><strong>View all Vertexmining Exchange trading accounts</strong></span></p></div>
    </div>
</div>        
            <div id="how-open-trading-account" class="numeral-links style2" style="background-image: url(images/open-account-min.jpg)">
    <div class="container">
                <div class="numeral-links__title title title_center"  data-aos="fade-up"><p><span style="font-weight:800;color:#aa8a5c;">How To Open</span> A Trading Account?</p></div>
                        <div class="numeral-links__text"  data-aos="fade-up"><p>Open your Vertexmining Exchange trading account in <strong>four simple steps.</strong></p></div>
        
                <div class="numeral-links__link" data-aos="fade-up" data-aos-delay="200">
            <a href="register"  class="btn btn-orange btn-little">Open a Trading Account</a>

            <div class="warning-text warning-text_center" data-aos="fade-up" data-aos-delay="200">
                <p>* Start Trading Now.</p>
            </div>
        </div>
        
        
        <ul class="numeral-links__list">
                            <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">01</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Sign-up</div>
                        <div class="numeral-links__item-subtitle">Simply click the sign-up button and provide your personal information in the registration form.</div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">02</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Verify</div>
                        <div class="numeral-links__item-subtitle">Verify your account by uploading your proof of identity and proof of address documents.</div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">03</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Choose</div>
                        <div class="numeral-links__item-subtitle">Once your Vertexmining Exchange trading account is verified, it’s time to choose your trading platform and your preferred trading account. </div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">04</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Fund</div>
                        <div class="numeral-links__item-subtitle">Fund your trading account using one of our secure payment methods to start trading CFDs popular energy commodities.</div>
                    </div>
                </a>
            </li>
                              </ul>
    </div>
</div>        
            <div id="want-practice-first" class="card style3" style="background: #ffffff;">
    <div class="container">
        <div class="card__block" style="background-image: url(images/practice-min.jpg)">
            <div class="card__content">
                                <div class="card__title" data-aos="fade-left"><p>Want To <span style="font-weight:800;color:#cbac63;">Practice First?</span></p></div>
                                <div class="card__text" data-aos="fade-left"><p><span style="font-weight:800;color:#cbac63;">Give a whole new meaning to green energy.</span> Practice and test your trading tactics on a demo account. When you’re ready to begin trading with real funds, you can give a whole new meaning to green energy.</p></div>
            </div>

            
                        <a href="register"  class="btn btn-big btn-white-red">Get a Demo Account</a>
            
                    </div>

                <div class="warning-text">
            <p>* Start Trading Now.</p>
        </div>
            </div>
</div>        
            
<div id="trade-energy-products-online" class="tariffs style2  "
     style="background-image: url(images/trade-energy2-min.jpg);     ">

    <div class="container">
                <div class="tariffs__title title title_center" data-aos="fade-up"><p>Trade <span style="font-weight:800;color:#cbac63;">Energy Products Online</span></p></div>
                        <div class="tariffs__subtitle" data-aos="fade-up" data-aos-delay="100"><p>Vertexmining Exchange offers two premium online trading platforms to analyse and trade commodities online. Detailed charts can show years of historic price information for all available oil and gas trading pairs.</p></div>
                        <div class="tariffs__text" data-aos="fade-up" data-aos-delay="100"><p>We provide MetaTrader 4, the world’s most popular and advanced trading platform with endless capabilities, and our very own Vertexmining Exchange trading platform, which is ideal for beginners looking for a modern trading interface.</p></div>
        
        
        
        
                <div class="tariffs__equal-list">
                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>MetaTrader 4</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Available on desktop, web, iOS and Android devices</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Automated trading with Expert Advisors</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Advanced charting and technical analysis capabilities</div>
                                                    </li>
                                            </ul>

                    
                                        <div class="combined-links">
                        <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                                                        <a href="register" class="combined-links__item combined-links__right">Open account</a>
                            
                            
                            
                                                        <a href="../index.html" class="combined-links__item combined-links__left">Learn more</a>
                                                    </div>
                    </div>
                                    </div>

            </div>

                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>Vertexmining Exchange Trader</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Available on web, iOS and Android</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Easy to navigate 1000s of trading instruments</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Modern design and sleek interface</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Loaded with the most popular market analysis tools</div>
                                                    </li>
                                            </ul>

                    
                                        <div class="combined-links">
                        <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                                                        <a href="register" class="combined-links__item combined-links__right">Open account</a>
                            
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Learn more</a>
                                                    </div>
                    </div>
                                    </div>

            </div>

                                </div>
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>* Start Trading Now.</p></div>
    </div>
</div>        
            
<div id="brent-energy-product" class="simple-block left  style4  " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/brent-min.jpg" alt="Brent: the most traded energy product" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p><span style="font-weight:800;color:#aa8a5c;">Brent</span>: the most traded energy product</p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>The market for energy products is the largest of all commodities, and Brent Crude Oil is the leader of the pack. Brent is extracted from the North Sea and Northern Europe and is considered the European benchmark for crude oil. The two most active venues for trading Brent are Moscow Exchange (MOEX) and the Intercontinental Exchange (ICE). In 2018, 676 mln. contracts were futures traded. Sign up to start trading the most active energy products with Vertexmining Exchange.</p></div>

                
                
                
                                                                
                                <div class="simple-block__link " data-aos="fade-left" data-aos-delay="300">
                                        <a href="register" class="btn btn-small btn-orange">Start trading Brent</a>
                    <div class="warning-text">
                        <div data-aos="fade-up" data-aos-delay="600">

	<p>* Start Trading Now.</p>
</div>
                    </div>
                    
                                    </div>
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="we-offer-energy-products" class="simple-block right  style4 small_padding  round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/we-offer-energy-min.jpg" alt="" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                                <div class="simple-block__subtitle" data-aos="fade-left"><p><span style="color: rgb(110, 35, 10);">We Offer More Than Energy Products</span></p></div>
                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>If you want to trade CFDs and speculate on the price of popular oil and gas products, then you’ve found the right broker. However, if you’re interested in trading more than just energy products, we’ve still got you covered. When you sign in to your Vertexmining Exchange trading account, you’ll find dozens of other commodities, precious metals and the world’s most liquid currency pairs.</p>

<h3><span style="color: rgb(110, 35, 10);">The Home of Investing</span></h3>

<p>Our vision is to provide a one-stop destination for traders and investors to access a wide range of products in the financial markets. With one trading account, you can discover hundreds of financial instruments. If you don’t see any good trading opportunities in the oil and gas market, you could easily view the charts of numerous other commodities, forex pairs, precious metals and more. If you do find an opportunity, you can go right ahead and open a position. There is no need to open a new account or change any settings.</p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="speak-account-manager" class="true-power " style="background-image: url(images/true-power-min.jpg)">
    <div class="container">
                        <div class="true-power__subtitle" data-aos="fade-up"><div style="max-width: 450px;margin-left:auto;margin-right:auto;">

	<p><span style="font-weight:800;">Speak to an account manager</span> to find out more.</p>
</div></div>
                
        
                <div class="combined-links">
            <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                
                                <a href="products.html" class="combined-links__item combined-links__right"><span>View All Products</span></a>
                
                
                                <a href="contactus.html" class="combined-links__item combined-links__left"><span>Get in Touch</span></a>
                            </div>
        </div>

                    </div>
</div>        
            <div id="social-links" class="social-links" style="background: #ffffff;">
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

@include('include.footer')
