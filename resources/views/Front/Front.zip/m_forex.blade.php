@include('include.header')

       <main class="main">
            
            

<div id="banner" class="simple-banner style2  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Trade Forex with Vertexmining Exchange</h1></div>
                                <div class="simple-banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p>Trade with a broker that provides you with the right environment to help you prosper in the turbulent forex market.</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><div style="max-width: 515px;">With a Vertexmining Exchange CFD trading account, you can access <strong>more than fifty
forex pairs</strong> to speculate on the global currency exchange markets.</div>
<div style="max-width: 515px;">
	<br>
</div>
<div style="max-width: 515px;"><strong>Start trading forex with Vertexmining Exchange</strong></div></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Start Trading</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

        
                     <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                <script src="https://widget.bm-tech.co/trade-currency-table?token=GncetXjzQEiDG0LY6iPsFRIZXpyglNgF2JW5ynVDqdMc82" crossorigin="anonymous"></script>
            </div>
        
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><div style="max-width: 515px;">With a Vertexmining Exchange CFD trading account, you can access <strong>more than fifty
forex pairs</strong> to speculate on the global currency exchange markets.</div>
<div style="max-width: 515px;">
	<br>
</div>
<div style="max-width: 515px;"><strong>Start trading forex with Vertexmining Exchange</strong></div></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Start Trading</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            
<div id="why-trade-forex" class="simple-block left  style1 small_padding  empty_padding_bottom round_image " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/why-trade-min.jpg" alt="Why Trade Forex?" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>Why <span style="font-weight:800;color:#aa8a5c;">Trade Forex</span>?</p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>The forex market is the international marketplace where countries illustrate their economic power as their currencies strengthen or weaken against competing nations. <strong>Buy and Sell the world’s most popular currencies as they strive to prevail against each other.&nbsp;</strong></p>

<p>Increase your buying power by utilising leverage to increase the size of your forex positions on popular currency pairs such as EUR/USD, GBP/USD, USD/JPY, and many more. If you’re new to trading or investing, check out our <strong style="color:#aa8a5c;">beginners guide</strong> to the financial markets.</p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            <div id="what-we-offer" class="list-with-icons style1 "
     style="">
    <div class="container">
        <div class="list-with-icons__title title title_center" data-aos="fade-up"><p>What <span style="font-weight:800;color:#aa8a5c;">We Offer</span></p></div>

        
        
        <ul class="list-with-icons__list">
                    <li class="list-with-icons__list-item" data-aos="fade-right" data-aos-delay="550">
                <div class="list-with-icons__list-block">
                                        <div class="list-with-icons__list-icon">
                        <div class="list-with-icons__list-icon-inner" style="background-image: url(../storage/app/media/trust1.svg)"></div>
                    </div>
                    <div class="list-with-icons__list-title">
                        <p><span style="color: rgb(110, 35, 10);">Forex Trading Platforms</span></p>

                    </div>
                    <div class="list-with-icons__list-text">
                        <p>Trade your favourite currency pairs on either MetaTrader 4, MetaTrader 5 or our very own Vertexmining Exchange web trading platform.</p>

                    </div>
                                    </div>
            </li>
                    <li class="list-with-icons__list-item" data-aos="fade-right" data-aos-delay="700">
                <div class="list-with-icons__list-block">
                                        <div class="list-with-icons__list-icon">
                        <div class="list-with-icons__list-icon-inner" style="background-image: url(../storage/app/media/trust3.svg)"></div>
                    </div>
                    <div class="list-with-icons__list-title">
                        <p><span style="color: rgb(110, 35, 10);">Excellent Trading Conditions</span></p>

                    </div>
                    <div class="list-with-icons__list-text">
                        <p>All of our clients benefit from transparent pricing. We give the tightest spreads possible and charge a fair trading commission on your trades.</p>

                    </div>
                                    </div>
            </li>
                    <li class="list-with-icons__list-item" data-aos="fade-right" data-aos-delay="850">
                <div class="list-with-icons__list-block">
                                        <div class="list-with-icons__list-icon">
                        <div class="list-with-icons__list-icon-inner" style="background-image: url(../storage/app/media/icons/computer.svg)"></div>
                    </div>
                    <div class="list-with-icons__list-title">
                        <p><span style="color: rgb(110, 35, 10);">Tools And Insights</span></p>

                    </div>
                    <div class="list-with-icons__list-text">
                        <p>Stay informed of what’s happening in the markets with Trading Central daily newsletters and trading signals and regular webinars.</p>

                    </div>
                                    </div>
            </li>
                    <li class="list-with-icons__list-item" data-aos="fade-right" data-aos-delay="1000">
                <div class="list-with-icons__list-block">
                                        <div class="list-with-icons__list-icon">
                        <div class="list-with-icons__list-icon-inner" style="background-image: url(../storage/app/media/icons/headphones.svg)"></div>
                    </div>
                    <div class="list-with-icons__list-title">
                        <p><span style="color: rgb(110, 35, 10);">Support<br>And Guidance</span></p>

                    </div>
                    <div class="list-with-icons__list-text">
                        <p>Every Vertexmining Exchange customer receives the same premium support from our specialists. Some accounts qualify for relationship managers and mentorship.</p>

                    </div>
                                    </div>
            </li>
                </ul>
    </div>
</div>        
            
<div id="forex-trading-portfolio-plan" class="tariffs style3  "
     style="     background: #ffffff;">

    <div class="container">
                <div class="tariffs__title title title_center" data-aos="fade-up"><p>Trading <span style="font-weight:800;color:#aa8a5c;">Accounts</span></p></div>
                                <div class="tariffs__text" data-aos="fade-up" data-aos-delay="100"><p>Choose the right trading account to match your investment goals. Whether you’re a day-trader looking to profit from short term price movements or a position trader, looking to benefit from the long-term appreciation or depreciation of precious metals, then Vertexmining Exchange probably has a suitable account for you.</p>

<p><strong>Here are the four most popular trading accounts for precious metals traders.</strong></p></div>
        
        
        
                <div class="tariffs__list">
                                    <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#B14421;">BRONZE</strong></p>
</div>
                <div class="tariffs__item-content ">
                    <div class="tariffs__item-bg" style="background-image: url(../storage/app/media/portfolio-page/tariff__bronze.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €1,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£12 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#D8B177;">GOLD</strong></p>
</div>
                <div class="tariffs__item-content ">
                    <div class="tariffs__item-bg" style="background-image: url(../storage/app/media/agriculture/gold.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €5,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£10 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#aaabad;">PREMIUM</strong></p>
</div>
                <div class="tariffs__item-content style2">
                    <div class="tariffs__item-bg" style="background-image: url(../storage/app/media/agriculture/tariffs-premium-2.png)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €50,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£7 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong>SILVER</strong></p>
</div>
                <div class="tariffs__item-content ">
                    <div class="tariffs__item-bg" style="background-image: url(../storage/app/media/portfolio-page/tariff__silver.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €2,500</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£11 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
                        <div class="tariffs__list-separator"></div>
            
                    </div>
        
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>* Start Trading Now.</p>

<p>
	<br>
</p>

<p>If you can’t find the right trading account, don’t worry. We’ve got more options waiting for you.
	<br><strong style="color:#aa8a5c;">View all Vertexmining Exchange trading accounts</strong></p></div>
    </div>
</div>        
            <div id="How -open-account" class="numeral-links style2" style="background-image: url(../storage/app/media/indices/stocks-benefits-min.jpg)">
    <div class="container">
                <div class="numeral-links__title title title_center"  data-aos="fade-up"><p><span style="font-weight:800;color:#aa8a5c;">How To Open</span> A Trading Account?</p></div>
                        <div class="numeral-links__text"  data-aos="fade-up"><p>Open your Vertexmining Exchange trading account in <strong>four simple steps.</strong></p></div>
        
                <div class="numeral-links__link" data-aos="fade-up" data-aos-delay="200">
            <a href="register"  class="btn btn-orange btn-little">Open a Trading Account</a>

            <div class="warning-text warning-text_center" data-aos="fade-up" data-aos-delay="200">
                <p>* Start Trading Now.</p>
            </div>
        </div>
        
        
        <ul class="numeral-links__list">
                            <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">01</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Sign-up</div>
                        <div class="numeral-links__item-subtitle">Simply click the sign-up button and provide your personal information in the registration form.</div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">02</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Verify</div>
                        <div class="numeral-links__item-subtitle">Verify your account by uploading your proof of identity and proof of address documents.</div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">03</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Choose</div>
                        <div class="numeral-links__item-subtitle">Once your Vertexmining Exchange trading account is verified, it’s time to choose your trading platform and your preferred trading account. </div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">04</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Fund</div>
                        <div class="numeral-links__item-subtitle">Fund your trading account using one of our secure payment methods to start trading CFDs popular energy commodities.</div>
                    </div>
                </a>
            </li>
                              </ul>
    </div>
</div>        
            
<div id="want-practice-first" class="simple-block left  style1 small_padding  round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/practice-first-min.jpg" alt="Want To Practice First?" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>Want To <span style="font-weight:800;color:#aa8a5c;">Practice First</span>?</p></div>
                                                <div class="simple-block__subtitle" data-aos="fade-left"><p><span style="color: rgb(110, 35, 10);">Practice makes perfect. That’s why we give all clients a free lifetime demo trading account to sharpen their forex trading skills.</span></p></div>
                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>Practice makes perfect. That’s why we give all clients a free lifetime demo trading account to sharpen their forex trading skills.</p></div>

                
                
                
                                
                                <div class="simple-block__link " data-aos="fade-left" data-aos-delay="300">
                                        <a href="register" class="btn btn-small btn-white">Start Earning Time</a>
                    <div class="warning-text">
                        <div data-aos="fade-up" data-aos-delay="600">

	<p>* Start Trading Now.</p>
</div>
                    </div>
                    
                                    </div>
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="trading-platforms" class="tariffs style2  "
     style="background-image: url(images/trading-platform-bg-min.jpg);     ">

    <div class="container">
                <div class="tariffs__title title title_center" data-aos="fade-up"><p>Trade Forex On The <span style="font-weight:800;color:#cbac63;">Most Reliable Trading Platforms</span></p></div>
                        <div class="tariffs__subtitle" data-aos="fade-up" data-aos-delay="100"><p>Vertexmining Exchange offers two premium trading platforms to analyse and trade on the global foreign exchange market.</p>

<p>
	<br>
</p></div>
                        <div class="tariffs__text" data-aos="fade-up" data-aos-delay="100"><p>We offer MetaTrader 4, the world’s most popular and advanced trading platform with endless capabilities, and our very own Vertexmining Exchange trading platform, which is ideal for beginners looking for a modern trading interface.</p></div>
        
        
        
        
                <div class="tariffs__equal-list">
                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>MetaTrader 4</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Available on desktop, web, iOS and Android devices</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Automated trading with Expert Advisors</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Advanced charting and technical analysis capabilities</div>
                                                    </li>
                                            </ul>

                    
                                        <div class="combined-links">
                        <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                                                        <a href="register" class="combined-links__item combined-links__right">Open Account</a>
                            
                            
                            
                                                        <a href="../index" class="combined-links__item combined-links__left">Learn More</a>
                                                    </div>
                    </div>
                                    </div>

            </div>

                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>Vertexmining Exchange Trader</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Available on web, iOS and Android</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Easy to navigate 1000s of trading instruments</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Modern design and sleek interface</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Loaded with the most popular market analysis tools</div>
                                                    </li>
                                            </ul>

                    
                                        <div class="combined-links">
                        <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                                                        <a href="register" class="combined-links__item combined-links__right">Open Account</a>
                            
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Learn More</a>
                                                    </div>
                    </div>
                                    </div>

            </div>

                                </div>
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>* Start Trading Now.</p></div>
    </div>
</div>        
            
<div id="most-popular-forex-pairs" class="text-center-block-lite   "
     style="     background: #ffffff;">
    <div class="container">
        <div class="text-center-block-lite__title title title_center" data-aos="fade-up"><p>Most Popular <span style="font-weight:800;color:#aa8a5c;">Forex Pairs</span></p></div>
        
        <div class="text-center-block-lite__text text" data-aos="fade-up" data-aos-delay="200"><p>Yes, the US dollar is the most dominant currency in the world. The majority of all foreign exchange transactions include the US dollar. Here are the top three currencies the US dollar is commonly traded against.</p></div>

                <div class="text-center-block-lite__table">
            <div class="table__wrapper" data-aos="fade-up" data-aos-delay="300">
                <div class="table">
                                                                                
                    <div class="table__row ">
                                                <div class="table__item table__caption table__item_red">
                            #Popular
                        </div>
                        <div class="table__item table__caption table__item_red">
                            #Rivals
                        </div>
                        <div class="table__item table__caption table__item_red">
                            #High-demand
                        </div>
                    </div>
                                                                                
                    <div class="table__row ">
                                                <div class="table__item ">
                            EUR/USD
                        </div>
                        <div class="table__item ">
                            GBP/USD
                        </div>
                        <div class="table__item ">
                            USD/JPY
                        </div>
                    </div>
                                                                                
                    <div class="table__row ">
                                                <div class="table__item ">
                            Did you know 24% of all foreign exchange trades were for euro vs US dollars?
                        </div>
                        <div class="table__item ">
                            Did you know the British pound was the world’s reserve currency before the US dollar?
                        </div>
                        <div class="table__item ">
                            Did you know 40% of Japan’s GDP is generated from exports?
                        </div>
                    </div>
                                                                                
                    <div class="table__row table__row_with-pretty-links">
                                                <div class="table__item ">
                            <a href='register'>Start Trading EUR/USD</a>
                        </div>
                        <div class="table__item ">
                            <a href='register'>Start Trading GBP/USD</a>
                        </div>
                        <div class="table__item ">
                            <a href='register'>Start Trading USD/JPY</a>
                        </div>
                    </div>
                                    </div>
            </div>
        </div>
        
        
        
                <div class="text-center-block-lite__bottom-text"  data-aos="fade-up" data-aos-delay="500"><p>* Start Trading Now.</p></div>
            </div>
</div>        
            
<div id="forex-market-trading-hours" class="text-center-block-lite  empty_padding_top  "
     style="background-image: url(images/Forex%20market%20hours-min.jpg);     ">
    <div class="container">
        <div class="text-center-block-lite__title title title_center" data-aos="fade-up"><p><span style="font-weight:800;color:#aa8a5c;">Forex Market</span> Trading Hours</p></div>
                <div class="text-center-block-lite__subtitle" data-aos="fade-up"  data-aos-delay="100"><p>This Is When The Forex Market Sleeps.</p></div>
        
        <div class="text-center-block-lite__text text" data-aos="fade-up" data-aos-delay="200"><p>You may have heard the forex market is open 24 hours a day, five days a week. That’s not strictly true. All the big banks take a few minutes to break between the New York close and the Sydney open. During this time, the markets can become volatile, so like many brokers, we also take a break and stop trading briefly.</p>

<table style="width: 100%;">
	<thead>
		<tr>
			<th style="width: 16.6667%;">Sunday
				<br>
			</th>
			<th style="width: 16.6667%;">Monday
				<br>
			</th>
			<th style="width: 16.6667%;">Tuesday
				<br>
			</th>
			<th style="width: 16.6667%;">Wednesday
				<br>
			</th>
			<th style="width: 16.6667%;">Thursday
				<br>
			</th>
			<th style="width: 16.6667%;">Friday
				<br>
			</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td style="width: 16.6667%;">22:01
				<br>
			</td>
			<td style="width: 16.6667%;">00:01
				<br>
			</td>
			<td style="width: 16.6667%;">00:01
				<br>
			</td>
			<td style="width: 16.6667%;">00:01
				<br>
			</td>
			<td style="width: 16.6667%;">00:01
				<br>
			</td>
			<td style="width: 16.6667%;">00:01
				<br>
			</td>
		</tr>
		<tr>
			<td style="width: 16.6667%;">23:59
				<br>
			</td>
			<td style="width: 16.6667%;">23:59
				<br>
			</td>
			<td style="width: 16.6667%;">23:59
				<br>
			</td>
			<td style="width: 16.6667%;">23:59
				<br>
			</td>
			<td style="width: 16.6667%;">23:59
				<br>
			</td>
			<td style="width: 16.6667%;">23:59
				<br>
			</td>
		</tr>
	</tbody>
</table></div>

        
        
        
                <div class="text-center-block-lite__bottom-text"  data-aos="fade-up" data-aos-delay="500"><p>* The times are displayed in GMT</p></div>
            </div>
</div>        
            
<div id="offer-more" class="true-power " style="background-image: url(../storage/app/media/true-power-min.jpg)">
    <div class="container">
                <div class="true-power__title title title_center" data-aos="fade-up"><p>We Offer <span style="font-weight:800;color:#cbac63;">More Than Forex</span></p></div>
                                <div class="true-power__text" data-aos="fade-up"><p>If you want to trade forex, then you have come to the right place. But, if you’re interested in more, we’ve still got you covered. Our vision is to provide a one-stop destination for traders and investors to access a wide range of products in the financial markets.</p>

<p><span style="font-size:16px;">Even if you’re an active forex trader, you might be interested in our portfolio management products to diversify and get exposure to other asset classes. Or, if you’re new to forex and not sure where to start, we offer mentorship programs and personal trading services.</span></p></div>
        
                                
            <div data-aos="fade-up" data-aos-delay="600">
                            <a href="register" class="btn btn-white-bright-red">Open a Trading Account</a>

                <div class="warning-text warning-text_light warning-text_center">
                    <p>* Start Trading Now.</p>
                </div>
            
                        </div>
        
            </div>
</div>        
            <div id="social-links" class="social-links" style="background: #ffffff;">
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

@include('include.footer')

        