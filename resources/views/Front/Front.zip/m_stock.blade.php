@include('include.header')


      <main class="main">
            
            

<div id="banner" class="simple-banner style2  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Trade Stocks CFDs with Vertexmining Exchange</h1></div>
                                <div class="simple-banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p>The fastest and most convenient way to trade shares of the most important companies in the world.</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p>with Vertexmining Exchange, you can trade the most popular stocks in the world via a convenient online trading platform.</p>

<p>
	<br>
</p>

<p><strong>Start trading stocks CFDs with Vertexmining Exchange</strong></p></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

        
                     <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                <script src="https://widget.bm-tech.co/trade-currency-table?token=N78mzhVxWwnC4XKcMDY9UbCxHjyFBW3vYLJR9nOH3BJcUK" crossorigin="anonymous"></script>
            </div>
        
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p>with Vertexmining Exchange, you can trade the most popular stocks in the world via a convenient online trading platform.</p>

<p>
	<br>
</p>

<p><strong>Start trading stocks CFDs with Vertexmining Exchange</strong></p></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            <div id="introduction" class="text-center-block-big style2" style="background-image: url(images/BG-min.jpg)">
    <div class="container">
                <div class="text-center-block-big__title title title_center" data-aos="fade-up"><p>Introduction To <span style="font-weight:800;color:#cbac63;">Trading Stocks</span></p></div>
                        <div class="text-center-block-big__subtitle" data-aos="fade-up" data-aos-delay="100"><p>When a company reaches a certain size, and therefore, level of appeal to investors, one of the ways they can raise capital for expansion is to do what’s known as an Initial Public Offering.</p></div>
                <div class="text-center-block-big__text" data-aos="fade-up" data-aos-delay="200"><p>When a company does an IPO, it gets an independent valuation to determine the value of the company, and then it issues a number of shares. The initial value of each share is determined by dividing the value of the company by the number of outstanding shares. After shares are listed on an exchange, the market decides how much they are worth. For example, when Netflix did an IPO in 2002, the company's shares were initially sold for $15 each and raised $82.5 million in the process. As of December 2020, Netflix shares are worth almost $500 each and more than 3 million shares are traded on the NASDAQ stock exchange each day.</p></div>

            </div>
</div>        
            <div id="" class="offer" style="background-image: url(images/stocks-benefits-min.jpg);">


    <div class="container">
        <div class="offer__block" data-aos="fade-up">
            <div class="offer__block-top">
                <div class="offer__title title title_center"><p>The Benefits Of <span style="font-weight:800;color:#aa8a5c;">Trading Stocks As CFDs</span></p></div>
                <div class="offer__subtitle text"></div>
                <div class="offer__text text"><p>Trading stocks using Contracts for Difference (CFDs) offers many benefits compared to purchasing shares from the stock market.</p></div>

                <div class="offer__list">
                                        <div class="offer__list-title"></div>
                    <div class="offer__list-subtitle"></div>
                    <div class="offer__enumeration">
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Use leverage to decrease capital requirements</div>
                            <div class="offer__enumeration-text">When you trade stocks using CFDs, you’re able to apply leverage to your positions. Using leverage decreases how much of your account balance is used to open a position. When you purchase stocks, you need to cover the whole amount with your own funds.</div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">A lower-cost way to speculate on the stock market</div>
                            <div class="offer__enumeration-text">When you purchase stocks, some fees need to be paid to the exchange, clearinghouse, custodial and broker. Trading CFDs doesn’t involve physical ownership, and therefore, there are fewer parties that need to be paid, thus lowering transaction costs.</div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Instant cash settlement when you close positions</div>
                            <div class="offer__enumeration-text">If you’ve purchased some shares, and later decide to sell them, it can take as long as a few days for funds to clear and be available for making new trades or making a withdrawal. When you close a CFD, funds are available immediately.</div>
                        </div>
                                                <div class="offer__enumeration-item">
                            <div class="offer__enumeration-icon"></div>
                            <div class="offer__enumeration-title">Go long or short and hedge your positions</div>
                            <div class="offer__enumeration-text">CFDs allow you to open both long and short positions so you can speculate on prices rising or falling. Some traders who own stocks, sometimes use short positions to hedge against any potential downside volatility. You’re able to apply that same principle </div>
                        </div>
                                            </div>
                                    </div>
                            </div>

            <div class="offer__block-bottom">
                                    <a href="register"  class="btn btn-orange">Open Account</a>

                    <div class="warning-text">
                        <p>* Start Trading Now.</p>
                    </div>
                
                            </div>
        </div>
    </div>
</div>        
            
<div id="what-we-offer" class="simple-block right  style1  empty_padding_top empty_padding_bottom wide_content round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/What%20We%20Offer-min.jpg" alt="What We Offer" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>What <span style="font-weight:800;color:#aa8a5c;">We Offer</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">The Most Accessible Trading Platforms</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Trade the stocks of the most important companies on earth from anywhere in the world with trading platforms from all screens and devices</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">Hundreds of different stocks</span></p>
</div>
                                                <div class="simple-block__list-text"><p>From one trading account, you can access hundreds of different stocks listed on the NYSE, NASDAQ, LSE, and other prominent exchanges.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">Low spreads &amp; commission</span></p>
</div>
                                                <div class="simple-block__list-text"><p>Trade stocks without paying fixed fees per trade. At Vertexmining Exchange, we charge a variable fee depending on the size of your order. If your trade is small, the fee should be small.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="900">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">Get expert insights and analysis</span></p>
</div>
                                                <div class="simple-block__list-text"><p>The news cycle regularly features information concerning the most important public companies; our analysts filter out the noise and distribute helpful insights to all clients of Vertexmining Exchange.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="trading-accounts" class="tariffs style3  "
     style="     background: #ffffff;">

    <div class="container">
                <div class="tariffs__title title title_center" data-aos="fade-up"><p>Trading <span style="font-weight:800;color:#aa8a5c;">Accounts</span></p></div>
                                <div class="tariffs__text" data-aos="fade-up" data-aos-delay="100"><p>Choose the right trading account to match your investment goals. Whether you’re a day-trader looking to profit from short term price movements or a position trader, looking to benefit from the long-term appreciation or depreciation of precious metals, then Vertexmining Exchange probably has a suitable account for you.</p>

<p><strong>Here are the four most popular trading accounts for precious metals traders.</strong></p></div>
        
        
        
                <div class="tariffs__list">
                                    <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#B14421;">BRONZE</strong></p>
</div>
                <div class="tariffs__item-content style1">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariff__bronze.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €1,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£12 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#D8B177;">GOLD</strong></p>
</div>
                <div class="tariffs__item-content style1">
                    <div class="tariffs__item-bg" style="background-image: url(images/gold.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €5,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£10 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#aaabad;">PREMIUM</strong></p>
</div>
                <div class="tariffs__item-content style2">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariffs-premium-2.png)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €50,000</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£7 per lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong>SILVER</strong></p>
</div>
                <div class="tariffs__item-content style1">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariff__silver.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum deposit</div>
                            <div class="tariffs__item-content-subtitle">From €2,500</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Minimum floating spread</div>
                            <div class="tariffs__item-content-subtitle">From 0.1 pip</div>                        </li>
                                                <li>
                            <div class="tariffs__item-content-title">Trading commissions</div>
                            <div class="tariffs__item-content-subtitle">From $/€/£11 Per Lot</div>                        </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
                        <div class="tariffs__list-separator"></div>
            
                    </div>
        
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>* Start Trading Now.</p>

<p>
	<br>
</p>

<p>If you can’t find the right trading account, don’t worry. We’ve got more options waiting for you.</p>

<p><span style="color:#aa8a5c;"><strong>View all Vertexmining Exchange trading accounts</strong></span></p></div>
    </div>
</div>        
            <div id="how-open-trading-account" class="numeral-links style2" style="background-image: url(images/stocks-benefits-min.jpg)">
    <div class="container">
                <div class="numeral-links__title title title_center"  data-aos="fade-up"><p><span style="font-weight:800;color:#aa8a5c;">How To Open</span> A Trading Account?</p></div>
                        <div class="numeral-links__text"  data-aos="fade-up"><p>Open your Vertexmining Exchange trading account in <strong>four simple steps.</strong></p></div>
        
                <div class="numeral-links__link" data-aos="fade-up" data-aos-delay="200">
            <a href="register"  class="btn btn-orange btn-little">Sign up</a>

            <div class="warning-text warning-text_center" data-aos="fade-up" data-aos-delay="200">
                <p>* Start Trading Now.</p>
            </div>
        </div>
        
        
        <ul class="numeral-links__list">
                            <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">01</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Sign-up</div>
                        <div class="numeral-links__item-subtitle">Simply click the sign-up button and provide your personal information in the registration form.</div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">02</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Verify</div>
                        <div class="numeral-links__item-subtitle">Verify your account by uploading your proof of identity and proof of address documents.</div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">03</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Choose</div>
                        <div class="numeral-links__item-subtitle">Once your Vertexmining Exchange trading account is verified, it’s time to choose your trading platform and your preferred trading account. </div>
                    </div>
                </a>
            </li>
                                <li class="numeral-links__item">
                <a href="#" class="numeral-links__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="numeral-links__item-number">04</div>
                    <div class="numeral-links__item-content">
                        <div class="numeral-links__item-title">Fund</div>
                        <div class="numeral-links__item-subtitle">Fund your trading account using one of our secure payment methods to start trading CFDs popular energy commodities.</div>
                    </div>
                </a>
            </li>
                              </ul>
    </div>
</div>        
            <div id="want-practice-first" class="card style2" style="background: #ffffff;">
    <div class="container">
        <div class="card__block" style="background-image: url(images/practice-min.jpg)">
            <div class="card__content">
                                <div class="card__title" data-aos="fade-left"><p>Want To <span style="font-weight:800;color:#cbac63;">Practice First?</span></p></div>
                                <div class="card__text" data-aos="fade-left"><p>Practice makes perfect. That’s why we give all clients <span style="font-weight:800;color:#cbac63;">a free lifetime demo trading account</span> to polish their skills for trading precious metals.</p></div>
            </div>

            
                        <a href="register"  class="btn btn-big btn-white-red">Get a Demo Account</a>
            
                    </div>

                <div class="warning-text">
            <p>* Start Trading Now.</p>
        </div>
            </div>
</div>        
            
<div id="trade-stocks-online" class="tariffs style2  "
     style="background-image: url(images/cfd/cfd-trading-with-min.jpg);     ">

    <div class="container">
                <div class="tariffs__title title title_center" data-aos="fade-up"><p>Trade <span style="font-weight:800;color:#cbac63;">Stocks Online</span></p></div>
                        <div class="tariffs__subtitle" data-aos="fade-up" data-aos-delay="100"><p>Vertexmining Exchange offers two premium online trading platforms to analyse and trade the world’s most active indices. Detailed charts can show years of historic price information for all available, including Facebook, Amazon, Netflix, Microsoft, PayPal and many more.</p></div>
                        <div class="tariffs__text" data-aos="fade-up" data-aos-delay="100"><p>We offer MetaTrader 4, the world’s most popular and advanced trading platform with endless capabilities, and our very own Vertexmining Exchange trading platform, which is ideal for beginners looking for a modern trading interface.</p></div>
        
        
        
        
                <div class="tariffs__equal-list">
                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>MetaTrader 4</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Available on desktop, web, iOS and Android devices</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Automated trading with Expert Advisors</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Advanced charting and technical analysis capabilities</div>
                                                    </li>
                                            </ul>

                    
                                        <div class="combined-links">
                        <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                                                        <a href="register" class="combined-links__item combined-links__right">Open account</a>
                            
                            
                            
                                                        <a href="../index" class="combined-links__item combined-links__left">Learn more</a>
                                                    </div>
                    </div>
                                    </div>

            </div>

                                    <div class="tariffs__equal-list-item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__equal-list-title"><p>Vertexmining Exchange Trader</p>
</div>
                <div class="tariffs__equal-list-content style2">
                    <ul>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Available on web, iOS and Android</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Easy to navigate 1000s of trading instruments</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Modern design and sleek interface</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__equal-list-content-title">Loaded with the most popular market analysis tools</div>
                                                    </li>
                                            </ul>

                    
                                        <div class="combined-links">
                        <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                                                        <a href="register" class="combined-links__item combined-links__right">Open account</a>
                            
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Learn more</a>
                                                    </div>
                    </div>
                                    </div>

            </div>

                                </div>
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>* Start Trading Now.</p></div>
    </div>
</div>        
            
<div id="trade-top-stocks-in-the-world" class="simple-block left  style4 small_padding  round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/image%2018.png" alt="" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                                <div class="simple-block__subtitle" data-aos="fade-left"><p><span style="color: rgb(110, 35, 10);">Trade the top stocks in the world</span></p></div>
                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><div style="max-width: 557px;">

	<p>There are thousands of publicly listed companies in the world, making it hard to know what to trade. At Vertexmining Exchange, our team of investment analysts have cherry-picked the top few hundred stocks from around the world. In our trading platform, you can find stocks from Europe, North America, South America, Asia and Australasia. </p>

	<p>In our applications, you can expect to see top shares from the U.S., such as Tesla and Intel, or leading companies from Europe, such as BMW and GlaxoSmithKline, and many more.</p>
</div></div>

                
                
                
                                                                
                                <div class="simple-block__link " data-aos="fade-left" data-aos-delay="300">
                                        <a href="https://moneyroute-exchange.com/account/" class="btn btn-small btn-orange">Start trading stocks</a>
                    <div class="warning-text">
                        <p>* Start Trading Now.</p>
                    </div>
                    
                                    </div>
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="we-offer-more-than-stocks" class="simple-block right  style4 small_padding  round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/we-offer-stocks-min.jpg" alt="" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                                <div class="simple-block__subtitle" data-aos="fade-left"><p><span style="color: rgb(110, 35, 10);">We offer more than stocks</span></p></div>
                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>If you want to speculate on shares from around the world, then you’ve come to the right place. However, if you’re interested in trading more than the stock market, then we’ve still got you covered. Our vision is to provide a one-stop destination for traders and investors to access a wide range of products in the financial markets. With one trading account, you can discover hundreds of financial instruments. If you don’t see any good trading opportunities in the precious metals markets, you could easily view the charts of numerous forex pairs, stocks, indices and more. If you do find an opportunity, you can go right ahead and open a position. There is no need to open a new account or change any settings.</p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="speak-account-manager" class="true-power " style="background-image: url(images/true-power-min.jpg)">
    <div class="container">
                        <div class="true-power__subtitle" data-aos="fade-up"><div style="max-width: 450px;margin-left:auto;margin-right:auto;">

	<p><span style="font-weight:800;">Speak to an account manager</span> to find out more.</p>
</div></div>
                
        
                <div class="combined-links">
            <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                
                                <a href="products" class="combined-links__item combined-links__right"><span>View all products</span></a>
                
                
                                <a href="contactus" class="combined-links__item combined-links__left"><span>Get in touch</span></a>
                            </div>
        </div>

                    </div>
</div>        
            <div id="social-links" class="social-links" style="background: #ffffff;">
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="images/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="images/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="images/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="images/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

    @include('include.footer')