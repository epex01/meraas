@include('include.header')

<main class="main">
        <div class="single-page">
    <div class="container">
            
            

<div id="" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>Do you know about these companies founded by Elon Musk?</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><div class="meta_info"><span class="date">Published: 2021-05-28 16:00</span> <span class="author">By Vertexmining Exchange</span></div>
<div class="post-image"><img src="images/elon7.png" class="fr-fic fr-dib elon" data-result="success">
	<div class="img-credits">ELON MUSK. CREDIT: Piusillu/ SHUTTERSTOCK.COM</div></div>

<h3>4 companies founded by Elon Musk</h3>

<p class="text">Elon Musk is best known for his role in Tesla, the pioneering electric vehicle company regularly making headlines for its impressive innovations, sales and stock market performance. Contrary to what most people think, Musk was not the founder of Tesla. However, he was a major early-stage investor, leading series A, B &amp; C funding rounds.</p>

<p class="text">Musk clearly saw something in Tesla that others didn’t, and there is little doubt he was correct considering he’s one of the wealthiest people in the world, alongside Jeff Bezos and Bill Gates.</p>

<p class="text">According to the <a href="portfolio">Portfolio Managers</a> at investment firm <a href="/">Vertexmining Exchange</a>, these mega billionaires are fighting for the top spot on the Forbes rich list, their net worth is heavily dependent on the performance of their companies share price. The billions of dollars these gentlemen have aren’t liquid assets.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Contact a Portfolio Manager</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div>

<p class="text">Presently, Tesla is more valuable than Ferrari, BMW, Porsche, Mercedes &amp; Maseratti combined. Let’s explore the other startups that have thrived in the hands of Elon Musk.</p></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><div class="meta_info"><span class="date">Published: 2021-05-28 16:00</span> <span class="author">By Vertexmining Exchange</span></div>
<div class="post-image"><img src="images/elon7.png" class="fr-fic fr-dib elon" data-result="success">
	<div class="img-credits">ELON MUSK. CREDIT: Piusillu/ SHUTTERSTOCK.COM</div></div>

<h3>4 companies founded by Elon Musk</h3>

<p class="text">Elon Musk is best known for his role in Tesla, the pioneering electric vehicle company regularly making headlines for its impressive innovations, sales and stock market performance. Contrary to what most people think, Musk was not the founder of Tesla. However, he was a major early-stage investor, leading series A, B &amp; C funding rounds.</p>

<p class="text">Musk clearly saw something in Tesla that others didn’t, and there is little doubt he was correct considering he’s one of the wealthiest people in the world, alongside Jeff Bezos and Bill Gates.</p>

<p class="text">According to the <a href="portfolio">Portfolio Managers</a> at investment firm <a href="/">Vertexmining Exchange</a>, these mega billionaires are fighting for the top spot on the Forbes rich list, their net worth is heavily dependent on the performance of their companies share price. The billions of dollars these gentlemen have aren’t liquid assets.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Contact a Portfolio Manager</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div>

<p class="text">Presently, Tesla is more valuable than Ferrari, BMW, Porsche, Mercedes &amp; Maseratti combined. Let’s explore the other startups that have thrived in the hands of Elon Musk.</p></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="elon" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>PayPal ($PYPL)</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p class="text"><span class="img-credits"><img data-src="..//storage/app/media/elon-mask/paypal.png" class="fr-fic fr-dii right-column bigger lazy"><span>Paypal CREDIT: rarrarorro/ SHUTTERSTOCK.COM</span></span><span class="credits-right">Before Tesla, Elon Musk founded X.com in 1999 using money he earned from the sale of a previous company he launched with his brother. It was one of the first online banks to be federally insured. Within the first few months, the company had over 200,000 customers. In 2000, the company merged with competitor Confinity and adopted the name PayPal. The company listed on the NASDAQ stock exchange in February 2002, then was purchased by eBay in July 2002 for $1.3 billion. PayPal is currently valued at more than $300 billion.</span></p>

<p class="text after-credits"><strong>The&nbsp;</strong><a href="portfolio"><strong>Portfolio Managers</strong></a><strong>&nbsp;at&nbsp;</strong><a href=""><strong>Vertexmining Exchange</strong></a><strong>, elaborated that despite Musk no longer being involved in PayPal, the company is still a good buy. Fintech is a strong market in the COVID-19 era.</strong></p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Contact a Portfolio Manager</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p class="text"><span class="img-credits"><img data-src="..//storage/app/media/elon-mask/paypal.png" class="fr-fic fr-dii right-column bigger lazy"><span>Paypal CREDIT: rarrarorro/ SHUTTERSTOCK.COM</span></span><span class="credits-right">Before Tesla, Elon Musk founded X.com in 1999 using money he earned from the sale of a previous company he launched with his brother. It was one of the first online banks to be federally insured. Within the first few months, the company had over 200,000 customers. In 2000, the company merged with competitor Confinity and adopted the name PayPal. The company listed on the NASDAQ stock exchange in February 2002, then was purchased by eBay in July 2002 for $1.3 billion. PayPal is currently valued at more than $300 billion.</span></p>

<p class="text after-credits"><strong>The&nbsp;</strong><a href="portfolio"><strong>Portfolio Managers</strong></a><strong>&nbsp;at&nbsp;</strong><a href="../index"><strong>Vertexmining Exchange</strong></a><strong>, elaborated that despite Musk no longer being involved in PayPal, the company is still a good buy. Fintech is a strong market in the COVID-19 era.</strong></p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Contact a Portfolio Manager</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                            <!--                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                
                </div>
            -->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h3 dir="ltr">SpaceX</h3></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p class="text">Many think SpaceX is a project that evolved from Tesla. Musk didn’t start with cars; he went straight for spaceships and rockets. SpaceX was founded in May 2002 using $100m of his early fortune from the sale of PayPal. The first successful SpaceX mission occurred in 2008 and subsequently to a $1.6 billion deal to deliver supplies to the International Space Station. Although SpaceX is not publicly listed, Morgan Stanley gave the company a $100 billion valuation in October 2020.</p></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p class="text">Many think SpaceX is a project that evolved from Tesla. Musk didn’t start with cars; he went straight for spaceships and rockets. SpaceX was founded in May 2002 using $100m of his early fortune from the sale of PayPal. The first successful SpaceX mission occurred in 2008 and subsequently to a $1.6 billion deal to deliver supplies to the International Space Station. Although SpaceX is not publicly listed, Morgan Stanley gave the company a $100 billion valuation in October 2020.</p></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>SolarCity</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><div class="post-image"><img src="images/solar-city.png" class="fr-fic fr-dib elon" data-result="success"></div>

<p class="text">SolarCity was founded in 2006 by two of Elon Musk’s cousins. Musk suggested the concept, became the chairman of the company and helped it to launch. In 2013, SolarCity became the leading residential solar installer in the United States. Ultimately, in 2016 Tesla acquired the company for $2.6 billion. Today, solar panels are available to buy on the Tesla website. In 2020, Tesla earned almost $2 billion in revenue from solar-related products. In the first quarter of 2020, Tesla ranked third in new residential solar installations with a 6.3% share.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Sign Up for Free</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><div class="post-image"><img src="images/solar-city.png" class="fr-fic fr-dib elon" data-result="success"></div>

<p class="text">SolarCity was founded in 2006 by two of Elon Musk’s cousins. Musk suggested the concept, became the chairman of the company and helped it to launch. In 2013, SolarCity became the leading residential solar installer in the United States. Ultimately, in 2016 Tesla acquired the company for $2.6 billion. Today, solar panels are available to buy on the Tesla website. In 2020, Tesla earned almost $2 billion in revenue from solar-related products. In the first quarter of 2020, Tesla ranked third in new residential solar installations with a 6.3% share.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Sign Up for Free</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="elon" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>The Boring Company</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p class="text"><img data-src="..//storage/app/media/elon-mask/theboringcompany.png" class="fr-fic fr-dii right-column lazy">Musk founded The Boring Company in 2016. In this context, boring doesn’t mean not-interesting; it means it means making a hole. The Boring Company constructs tunnels, typically for cars and shuttle busses. In 2020, the company completed a 1.7-mile tunnel under the Las Vegas Convention Center that cuts a 45-minute walk to approximately two a minute journey. Based on the company’s plans, Wall Street analyst Alexander Haissl says the company could be worth $16 billion.</p></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p class="text"><img data-src="..//storage/app/media/elon-mask/theboringcompany.png" class="fr-fic fr-dii right-column lazy">Musk founded The Boring Company in 2016. In this context, boring doesn’t mean not-interesting; it means it means making a hole. The Boring Company constructs tunnels, typically for cars and shuttle busses. In 2020, the company completed a 1.7-mile tunnel under the Las Vegas Convention Center that cuts a 45-minute walk to approximately two a minute journey. Based on the company’s plans, Wall Street analyst Alexander Haissl says the company could be worth $16 billion.</p></div>

                            <!--                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                
                </div>
            -->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>Investing in Tesla is investing in Musk</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p class="text">Tesla, formerly Tesla Motors, shortened its name in 2016 to highlight the company is not just about cars and engines but developing environmentally sustainable solutions. Many people invest in Tesla as a proxy for investing in Musk in support of his visions. All of his ideas seem far fetched at first.</p>

<p class="text">Imagine thinking about using a mobile phone app to transfer money in 1999. Or, an electric car becoming one of the most coveted personal vehicles in 2003. Musk has been ridiculed by Silicon Valley, Wall Street, and Washington D.C., but he has proven his sceptics wrong time after time.</p>

<p class="text">You can invest in Musk’s next innovation by buying&nbsp;<a href="stocks">$TSLA shares.</a> To start, open a trading account with&nbsp;<a href="../index">Vertexmining Exchange</a>. It’s free to open an account and only takes a few minutes to get verified.&nbsp;<a href="whytrade">Learn more about stock trading with Vertexmining Exchange.</a></p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Sign Up for Free</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p class="text">Tesla, formerly Tesla Motors, shortened its name in 2016 to highlight the company is not just about cars and engines but developing environmentally sustainable solutions. Many people invest in Tesla as a proxy for investing in Musk in support of his visions. All of his ideas seem far fetched at first.</p>

<p class="text">Imagine thinking about using a mobile phone app to transfer money in 1999. Or, an electric car becoming one of the most coveted personal vehicles in 2003. Musk has been ridiculed by Silicon Valley, Wall Street, and Washington D.C., but he has proven his sceptics wrong time after time.</p>

<p class="text">You can invest in Musk’s next innovation by buying&nbsp;<a href="stocks">$TSLA shares.</a> To start, open a trading account with&nbsp;<a href="../index">Vertexmining Exchange</a>. It’s free to open an account and only takes a few minutes to get verified.&nbsp;<a href="whytrade">Learn more about stock trading with Vertexmining Exchange.</a></p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Sign Up for Free</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>            <script>
        $('.lazy').lazy({
            scrollDirection: 'vertical',
            effect: 'fadeIn',
            visibleOnly: true,
		  beforeLoad: function(element){
			  console.log('image is about to be loaded');
		  },
		  afterLoad: function(element) {
			  console.log('image was loaded successfully');
		  },
		  onError: function(element) {
			  console.log('image could not be loaded');
		  },
		  onFinishedAll: function() {
			  console.log('finished loading elements');
			  console.log('lazy instance is about to be destroyed')
		  }
	    });
    </script>
    </div>
</div>
<style>.post-image img.elon {
        max-width: 100%;
    }
    .simple-banner .container {
            min-height: 0;   
    }
    span.credits-right {
        display: inline-block;
    }
    @media (min-width: 1024px) {
        .left-column {
            width: 30%;
            float: right;
            padding: 20px 0 20px 20px;
        }
        .right-column {
            width: 50%;
            float: left;
            padding: 0 30px 20px 0;
            margin-top: 5px;
        }
        .right-column.bigger {
            width: 60%;
            padding: 0 20px 15px 0;
        }
        span.img-credits span {
            float: left;
            clear: left;
            width: 55%;
            line-height: 18px;
        }
        p.after-credits {
            clear: left;
            padding-top: 20px;
        }
        span.credits-right {
            width: 40%;
        }
    }
    @media only screen and (max-width: 1440px) {
        .simple-banner .container {
            min-height: 0;   
        }
    }
</style>        </main>

@include('include.footer')