@include('include.header')

<main class="main">
        <div class="single-page">
    <div class="container">
            
            
<style>@media (max-width: 768px) {
        .simple-banner__desktop {
            display: block;
        }
        .simple-banner__mobile {
            display: none;
        }
    }
</style>

<div id="elon" class="simple-banner style2  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>Elon Musk – The Success Story</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><div class="post-image"><img src="images/shutterstock_1307162791.png" class="fr-fic fr-dib elon" data-result="success"></div>

<p class="text">"The first step is to establish that something is possible, then probability will occur."</p>

<p class="text">– said Elon Musk, once a bullied boy from Pretoria, South Africa. It wasn't always smooth sailing for him; however, he managed to become the world's richest person. Fast forward from a troubled childhood to 1995 when Elon and his younger brother Kimbal started a web software company Zip2 for $28,000. Four years later, in 1999, this investment brought them a whopping $340 million, $336 million in cash, and $34 million in <a href="stocks">stocks</a>. Musk used Zip2 buyout money, $22 million for his 7% stake from the sale, to create X.com, which merged with another company to become later known as PayPal.</p>

<p class="text">After starting up X.com and merging it with PayPal.com, they sold it off for mind blowing $1.5 billion growing Elon's net worth to $123 million. At this point, most people would've retired; however, the key aspect to his success kicked in – willingness to take risks. Instead of riding into the sunset, he invested most of his fortune into two separate companies.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Learn more</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div>

<p class="text">One of them was Tesla Motors; a fledgling automaker focused on electric transportation. People considered electric cars to be slow and ugly at that time, but Tesla wanted to change it. When they were bankrupt, Elon Musk invested $80 million in Tesla Motors and became its CEO. "You can now buy a <a href="bitcoin">Tesla with Bitcoin</a>" – Tweeted Musk last month, just days after the company bought $1.5 billion worth of this <a href="digitalcurrency">cryptocurrency</a>.&nbsp;<img data-src="https://caponemarket.io/storage/app/media/uploaded-files/shutterstock1916785223-2.jpg" class="fr-fic fr-dii left-column lazy"> Elon's success only seems to grow as he endlessly pushes the borders of traditional business means. While the world faces a new crisis, Musk has observed how bitcoin's value made a massive jump over the last 12 months. While Tesla Inc., shares have risen from around $100 to over $600, <a href="bitcoin">Bitcoin</a> went over $55,000. We are only to witness how genius this latest move of his will turn out to be.</p>

<p class="text">The other company he invested in was SpaceX, a company hell-bent on commercial space exploration. Same in the case of SpaceX, in the beginning, it was a failure, they failed to launch their first rocket into space several times, and every failure cost them millions of dollars. If there was another failure, Elon Musk might have lost all the money he decided to invest. But on their fourth attempt, the project succeeded. At that time, they got a deal from NASA, and from that point, there is no turning back. They are the first private company to send a spacecraft to the International Space Station.</p>
<div class="clearfix">
	<br>
</div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

        
         
                <div class="simple-banner__image desk" data-aos="fade-left" data-aos-delay="200" style="margin:auto auto;">
        <script src="https://widget.caponemarket.io/trade-currency-table?token=K11CNAiW8IYdrN6RzpvsoennbclBbTinqKexPyJ0s68Usy" crossorigin="anonymous"></script>
        </div>
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><div class="post-image"><img src="images/shutterstock_1307162791.png" class="fr-fic fr-dib elon" data-result="success"></div>

<p class="text">"The first step is to establish that something is possible, then probability will occur."</p>

<p class="text">– said Elon Musk, once a bullied boy from Pretoria, South Africa. It wasn't always smooth sailing for him; however, he managed to become the world's richest person. Fast forward from a troubled childhood to 1995 when Elon and his younger brother Kimbal started a web software company Zip2 for $28,000. Four years later, in 1999, this investment brought them a whopping $340 million, $336 million in cash, and $34 million in <a href="stocks">stocks</a>. Musk used Zip2 buyout money, $22 million for his 7% stake from the sale, to create X.com, which merged with another company to become later known as PayPal.</p>

<p class="text">After starting up X.com and merging it with PayPal.com, they sold it off for mind blowing $1.5 billion growing Elon's net worth to $123 million. At this point, most people would've retired; however, the key aspect to his success kicked in – willingness to take risks. Instead of riding into the sunset, he invested most of his fortune into two separate companies.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Learn more</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div>

<p class="text">One of them was Tesla Motors; a fledgling automaker focused on electric transportation. People considered electric cars to be slow and ugly at that time, but Tesla wanted to change it. When they were bankrupt, Elon Musk invested $80 million in Tesla Motors and became its CEO. "You can now buy a <a href="bitcoin">Tesla with Bitcoin</a>" – Tweeted Musk last month, just days after the company bought $1.5 billion worth of this <a href="digitalcurrency">cryptocurrency</a>.&nbsp;<img data-src="images/shutterstock1916785223-2.jpg" class="fr-fic fr-dii left-column lazy"> Elon's success only seems to grow as he endlessly pushes the borders of traditional business means. While the world faces a new crisis, Musk has observed how bitcoin's value made a massive jump over the last 12 months. While Tesla Inc., shares have risen from around $100 to over $600, <a href="bitcoin">Bitcoin</a> went over $55,000. We are only to witness how genius this latest move of his will turn out to be.</p>

<p class="text">The other company he invested in was SpaceX, a company hell-bent on commercial space exploration. Same in the case of SpaceX, in the beginning, it was a failure, they failed to launch their first rocket into space several times, and every failure cost them millions of dollars. If there was another failure, Elon Musk might have lost all the money he decided to invest. But on their fourth attempt, the project succeeded. At that time, they got a deal from NASA, and from that point, there is no turning back. They are the first private company to send a spacecraft to the International Space Station.</p>
<div class="clearfix">
	<br>
</div></div>

                            <!--                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                <script src="https://widget.caponemarket.io/trade-currency-table?token=K11CNAiW8IYdrN6RzpvsoennbclBbTinqKexPyJ0s68Usy" crossorigin="anonymous"></script>
                </div>
            -->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p class="text">
	<br>
</p>

<p class="text">He invested his money into making both companies a success. His passion for entrepreneurship, design, engineering, and the future brought him to the pedestal of being the wealthiest person in the world. Tesla is now one of the most valuable companies globally, valued at half a trillion dollars, and SpaceX has made notable progress with a recent valuation at $46 billion. Where most people would call it quits, Elon leaned in. Musk built his whole career on taking risks, and it turned out that's how legends are built.</p>
<div class="post-image"><img data-src="images/shutterstock_1803971389.png" style="margin:auto auto;display:block;" class="fr-fic fr-dib lazy"></div>

<p class="text">Vertexmining Exchange, a licensed investment firm and <a href="portfolio">portfolio manager</a>, offers a <a href="conciergeservice">concierge trading service</a> that helps traders invest their capital wisely and offers ongoing <a href="portfolio">portfolio management</a> to adjust to constantly changing market conditions.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="register">Sign Up</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p class="text">
	<br>
</p>

<p class="text">He invested his money into making both companies a success. His passion for entrepreneurship, design, engineering, and the future brought him to the pedestal of being the wealthiest person in the world. Tesla is now one of the most valuable companies globally, valued at half a trillion dollars, and SpaceX has made notable progress with a recent valuation at $46 billion. Where most people would call it quits, Elon leaned in. Musk built his whole career on taking risks, and it turned out that's how legends are built.</p>
<div class="post-image"><img data-src="images/shutterstock_1803971389.png" style="margin:auto auto;display:block;" class="fr-fic fr-dib lazy"></div>

<p class="text">Vertexmining Exchange, a licensed investment firm and <a href="portfolio">portfolio manager</a>, offers a <a href="conciergeservice">concierge trading service</a> that helps traders invest their capital wisely and offers ongoing <a href="portfolio">portfolio management</a> to adjust to constantly changing market conditions.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Sign Up</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        </div>
    <script>
        $('.lazy').lazy({
            scrollDirection: 'vertical',
            effect: 'fadeIn',
            visibleOnly: true,
		  beforeLoad: function(element){
			  console.log('image is about to be loaded');
		  },
		  afterLoad: function(element) {
			  console.log('image was loaded successfully');
		  },
		  onError: function(element) {
			  console.log('image could not be loaded');
		  },
		  onFinishedAll: function() {
			  console.log('finished loading elements');
			  console.log('lazy instance is about to be destroyed')
		  }
	    });
    </script>
</div>
<style>@media (min-width: 1024px) {
        .left-column {
            width: 30%;
            float: right;
            padding: 20px 0 20px 20px;
        }
    }
</style>        </main>

@include('include.footer')