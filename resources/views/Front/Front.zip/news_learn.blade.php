@include('include.header')


<main class="main">
        <div class="single-page">
    <div class="container">
            
            

<div id="" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>Learn Elon Musk’s secrets to success</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><div class="meta_info"><span class="date">Published: 2021-05-28 12:00</span> <span class="author">By Vertexmining Exchange</span></div>
<div class="post-image"><img src="images/elon4.png" class="fr-fic fr-dib elon" data-result="success">
	<div class="img-credits">TESLA CEO ELON MUSK. CREDIT: PANTID123 / SHUTTERSTOCK.COM</div></div>

<p class="text">For decades, Elon Musk has been an outlier in Silicon Valley, Washington D.C., and Wall Street. Over the years, the controversial but greatly adored entrepreneur and CEO engaged in several infamous disputes with others he doesn’t see eye-to-eye with.</p>

<p class="text">For example, in August 2018, Musk sent Greenlight Capital founder and self-proclaimed $TSLA short-seller David Einhorn a box of short shorts to console him after blaming Tesla’s price increase for his fund’s poor performance in the first half of the year.</p>

<p class="text"><strong>According to the <a href="portfolio">Portfolio Managers</a> at investment firm <a href="/">Vertexmining Exchange</a>, Tesla short-sellers lost $40 billion by betting against the company.</strong></p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Contact a Portfolio Manager</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div>

<p class="text">Musk has gone on to offend journalists, politicians, several government agencies, and even Tesla shareholders with this kind of behaviour. Saying it like it is, is one of the characteristics that people either admire or loathe most.</p>

<p class="text">After all, you can’t be successful without ruffling a few feathers and following the status quo. In this article, let’s explore some of Musk’s secrets to success.</p>
<div class="clearfix">
	<br>
</div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index.html" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><div class="meta_info"><span class="date">Published: 2021-05-28 12:00</span> <span class="author">By Vertexmining Exchange</span></div>
<div class="post-image"><img src="images/elon4.png" class="fr-fic fr-dib elon" data-result="success">
	<div class="img-credits">TESLA CEO ELON MUSK. CREDIT: PANTID123 / SHUTTERSTOCK.COM</div></div>

<p class="text">For decades, Elon Musk has been an outlier in Silicon Valley, Washington D.C., and Wall Street. Over the years, the controversial but greatly adored entrepreneur and CEO engaged in several infamous disputes with others he doesn’t see eye-to-eye with.</p>

<p class="text">For example, in August 2018, Musk sent Greenlight Capital founder and self-proclaimed $TSLA short-seller David Einhorn a box of short shorts to console him after blaming Tesla’s price increase for his fund’s poor performance in the first half of the year.</p>

<p class="text"><strong>According to the <a href="portfoliomanagement.html">Portfolio Managers</a> at investment firm <a href="../index.html">Vertexmining Exchange</a>, Tesla short-sellers lost $40 billion by betting against the company.</strong></p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="Contact">Contact a Portfolio Manager</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div>

<p class="text">Musk has gone on to offend journalists, politicians, several government agencies, and even Tesla shareholders with this kind of behaviour. Saying it like it is, is one of the characteristics that people either admire or loathe most.</p>

<p class="text">After all, you can’t be successful without ruffling a few feathers and following the status quo. In this article, let’s explore some of Musk’s secrets to success.</p>
<div class="clearfix">
	<br>
</div></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h3 dir="ltr">Don’t be afraid to think big</h3></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p class="text">All of Musk’s ideas seem far-fetched at the time. In 1999, years before the very first iPhone, PayPal’s mission was to create <strong><em>“the new world currency”</em></strong>. Although PayPal hasn’t created a <a href="digitalcurrency.html">new currency</a>, it created a democratised global payment network open for anyone to participate.</p>
<div class="block-bottom"><a class="btn btn-orange" href="portfolio">Discover New Assets</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div>

<p class="text">Tesla’s 2003 mission statement was <strong><em>“to accelerate the advent of sustainable transport by bringing compelling mass-market electric cars to market as soon as possible”</em></strong>.</p>

<p class="text">At the time, both missions were bold; today, they seem relatively mundane as dozens of companies compete in those fields.</p>

<p class="text">Musk is driving several companies daring to think big, even impossible.</p>

<p class="text">SpaceX has the intention of building reusable, sustainable spacecraft for commercial space travel. So far, the company has only performed missions to the International Space Station. However, it’s taking small steps in the right direction.</p>

<p class="text">The Boring Company’s mission is <strong><em>“to solve the problem of soul-destroying traffic, roads must go 3D, which means either flying cars or tunnels. Unlike flying cars, tunnels are weatherproof, out of sight and won't fall on your head”</em></strong>. The company has only completed a Loop system for the Las Vegas Convention Center, but more projects are under consideration.</p>

<p class="text">Other initiatives and innovations like Hyperloop, Neuralink and Starlink Internet Satellites are insanely futuristic, but will we be looking back and seeing these inventions and think of them as part of our everyday life? Just like we see Tesla cars in the street and PayPal supported by our favourite online stores?</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Learn more</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div>
<div class="clearfix">
	<br>
</div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index.html" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p class="text">All of Musk’s ideas seem far-fetched at the time. In 1999, years before the very first iPhone, PayPal’s mission was to create <strong><em>“the new world currency”</em></strong>. Although PayPal hasn’t created a <a href="digitalcurrency.html">new currency</a>, it created a democratised global payment network open for anyone to participate.</p>
<div class="block-bottom"><a class="btn btn-orange" href="portfolio">Discover New Assets</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div>

<p class="text">Tesla’s 2003 mission statement was <strong><em>“to accelerate the advent of sustainable transport by bringing compelling mass-market electric cars to market as soon as possible”</em></strong>.</p>

<p class="text">At the time, both missions were bold; today, they seem relatively mundane as dozens of companies compete in those fields.</p>

<p class="text">Musk is driving several companies daring to think big, even impossible.</p>

<p class="text">SpaceX has the intention of building reusable, sustainable spacecraft for commercial space travel. So far, the company has only performed missions to the International Space Station. However, it’s taking small steps in the right direction.</p>

<p class="text">The Boring Company’s mission is <strong><em>“to solve the problem of soul-destroying traffic, roads must go 3D, which means either flying cars or tunnels. Unlike flying cars, tunnels are weatherproof, out of sight and won't fall on your head”</em></strong>. The company has only completed a Loop system for the Las Vegas Convention Center, but more projects are under consideration.</p>

<p class="text">Other initiatives and innovations like Hyperloop, Neuralink and Starlink Internet Satellites are insanely futuristic, but will we be looking back and seeing these inventions and think of them as part of our everyday life? Just like we see Tesla cars in the street and PayPal supported by our favourite online stores?</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="/">Learn more</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div>
<div class="clearfix">
	<br>
</div></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="elon" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>Ignore the critics</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p class="text"><img data-src="images/elon6.png" class="fr-fic fr-dii right-column bigger lazy">As we’ve established, Musk’s ideas are perplexing, and he receives a lot of criticism for his views. Musk has faced many critics on his journey to success, people regularly telling him his ideas won’t work and he’s destined to fail; but he hasn’t.</p>

<p class="text">According to the Interview with the BBC, he said what really shocked him in 2014 was the delight many pundits and commentators took in his toils. Musk said, <strong><em>"the liberal schadenfreude was really quite astonishing, there were multiple blog sites maintaining a Tesla death watch." (Musk.E, 7.1.2021, BBC Interview)</em></strong></p>

<p class="text">Whoever made those death clocks completely wasted their time because Tesla is worth more than General Motors, BMW, Porsche, Ferrari, Volkswagen, Ford, NIO, Mercedes, Tata Motors, Stellanis (Alfa Romeo, Maserati, Chrysler, etc.) and Honda combined.</p>

<p class="text"><strong>The <a href="portfoliomanagement.html">Portfolio Managers</a> at <a href="/">Vertexmining Exchange</a> is bullish on electric vehicles. they commented that most of the legacy auto manufacturers are seeking opportunities in sustainable transport. According to Vertexmining Exchange, we should watch General Motors and BMW.</strong></p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="/">Contact a Portfolio Manager</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index.html" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p class="text"><img data-src="images/elon6.png" class="fr-fic fr-dii right-column bigger lazy">As we’ve established, Musk’s ideas are perplexing, and he receives a lot of criticism for his views. Musk has faced many critics on his journey to success, people regularly telling him his ideas won’t work and he’s destined to fail; but he hasn’t.</p>

<p class="text">According to the Interview with the BBC, he said what really shocked him in 2014 was the delight many pundits and commentators took in his toils. Musk said, <strong><em>"the liberal schadenfreude was really quite astonishing, there were multiple blog sites maintaining a Tesla death watch." (Musk.E, 7.1.2021, BBC Interview)</em></strong></p>

<p class="text">Whoever made those death clocks completely wasted their time because Tesla is worth more than General Motors, BMW, Porsche, Ferrari, Volkswagen, Ford, NIO, Mercedes, Tata Motors, Stellanis (Alfa Romeo, Maserati, Chrysler, etc.) and Honda combined.</p>

<p class="text"><strong>The <a href="portfoliomanagement.html">Portfolio Managers</a> at <a href="../index.html">Vertexmining Exchange</a> is bullish on electric vehicles. they commented that most of the legacy auto manufacturers are seeking opportunities in sustainable transport. According to Vertexmining Exchange, we should watch General Motors and BMW.</strong></p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="/">Contact a Portfolio Manager</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                            <!--                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                
                </div>
            -->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>Plan for success, prepare for failure</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p class="text">As they say, good cannot exist without evil; success cannot exist without failure. The amount of research, development and testing that went into creating any product built by Musk had to have encountered hundreds, even thousands of setbacks.</p>

<p class="text">In an interview with 60 Minutes, Musk said, <strong><em>“well, I didn't really think Tesla would be successful. I thought we would most likely fail. But I thought that we at least could address the false perception that people have that an electric car had to be ugly and slow and boring like a golf cart.” (Elon Musk, March 30, 2014)</em></strong></p>

<p class="text">Don’t expect everything to work. If you do, failure will hurt more, and you won’t have a plan-b to help you get back on your feet.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="register">Choose now</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index.html" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p class="text">As they say, good cannot exist without evil; success cannot exist without failure. The amount of research, development and testing that went into creating any product built by Musk had to have encountered hundreds, even thousands of setbacks.</p>

<p class="text">In an interview with 60 Minutes, Musk said, <strong><em>“well, I didn't really think Tesla would be successful. I thought we would most likely fail. But I thought that we at least could address the false perception that people have that an electric car had to be ugly and slow and boring like a golf cart.” (Elon Musk, March 30, 2014)</em></strong></p>

<p class="text">Don’t expect everything to work. If you do, failure will hurt more, and you won’t have a plan-b to help you get back on your feet.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="register">Choose now</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>
</div></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>        
            

<div id="" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><p>The takeaway</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p class="text"><span class="img-credits"><img data-src="images/elon5.png" class="fr-fic fr-dii right-column lazy"><span>TESLA CEO ELON MUSK. CREDIT: PANTID123 / SHUTTERSTOCK.COM</span></span> Musk proved all of the sceptics wrong. Tesla delivered 184,800 vehicles in the first quarter of 2021, the company’s market cap reached $847.7b, and Musk briefly became the wealthiest person on earth.</p>

<p class="text">Not everyone can do what Elon Musk did. There is a way to follow in his footsteps and be part of the potential success in the future. All you have to do is start investing in Tesla shares. If Tesla continues to dominate the electric vehicle sector, you’ll have a share in that success.</p>
<div class="clearfix">
	<br>
</div>

<p class="text">To start your journey of investing in the future like Elon Musk, you can have a meeting with resident <a href="portfolio">Portfolio Managers</a>. They’ll help you understand if a share <a href="stocks">trading</a> account is an appropriate solution for you, or if you could benefit from one of our managed <a href="conciergeservice.html">investment services</a>.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="register">Start Trading</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>

	<p>
		<br>
	</p>
</div>

<p class="text"><span style="font-size: 12px;color:grey;">References:</span></p>

<ul style="color:grey;list-style:none;">
	<li><span style="font-size: 12px;">1. Elon Musk, (7.1.2021.), “Elon Musk's six secrets to business success”, Interview with the Elon Musk with BBC News journalist Justin Rowlatt, &nbsp;08:30 GMT on Friday, 8 January on <a href="https://www.bbc.co.uk/programmes/w3csz79h">Business Daily</a> on BBC World Service.</span></li>
	<li><span style="font-size: 12px;">2. Elon musk, (March 30, 2014.), “<a href="https://www.cbsnews.com/news/tesla-and-spacex-elon-musks-industrial-empire/">Tesla and SpaceX: Elon Musk's industrial empire</a>”, Elon musk interview with Scott Pelley for CBS News</span></li>
</ul>

<p>
	<br>
</p></div>

                    
                    
                    
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="../storage/app/media/index.html" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p class="text"><span class="img-credits"><img data-src="images/elon5.png" class="fr-fic fr-dii right-column lazy"><span>TESLA CEO ELON MUSK. CREDIT: PANTID123 / SHUTTERSTOCK.COM</span></span> Musk proved all of the sceptics wrong. Tesla delivered 184,800 vehicles in the first quarter of 2021, the company’s market cap reached $847.7b, and Musk briefly became the wealthiest person on earth.</p>

<p class="text">Not everyone can do what Elon Musk did. There is a way to follow in his footsteps and be part of the potential success in the future. All you have to do is start investing in Tesla shares. If Tesla continues to dominate the electric vehicle sector, you’ll have a share in that success.</p>
<div class="clearfix">
	<br>
</div>

<p class="text">To start your journey of investing in the future like Elon Musk, you can have a meeting with resident <a href="portfolio">Portfolio Managers</a>. They’ll help you understand if a share <a href="forextrading">trading</a> account is an appropriate solution for you, or if you could benefit from one of our managed <a href="conciergeservice.html">investment services</a>.</p>
<div class="block-bottom"><a class="btn btn-orange" data-fancybox="" data-src="#sign-up-modal" href="#">Start Trading</a></div>
<div class="warning-text aos-init aos-animate" data-aos="fade-up" data-aos-delay="600" style="
    text-align: center;
    margin-top: 0;">

	<p>* Start Trading Now.</p>

	<p>
		<br>
	</p>
</div>

<p class="text"><span style="font-size: 12px;color:grey;">References:</span></p>

<ul style="color:grey;list-style:none;">
	<li><span style="font-size: 12px;">1. Elon Musk, (7.1.2021.), “Elon Musk's six secrets to business success”, Interview with the Elon Musk with BBC News journalist Justin Rowlatt, &nbsp;08:30 GMT on Friday, 8 January on <a href="https://www.bbc.co.uk/programmes/w3csz79h">Business Daily</a> on BBC World Service.</span></li>
	<li><span style="font-size: 12px;">2. Elon musk, (March 30, 2014.), “<a href="https://www.cbsnews.com/news/tesla-and-spacex-elon-musks-industrial-empire/">Tesla and SpaceX: Elon Musk's industrial empire</a>”, Elon musk interview with Scott Pelley for CBS News</span></li>
</ul>

<p>
	<br>
</p></div>

                            <!---->
                
                            </div>
        </div>

    </div>

</div>            <script>
        $('.lazy').lazy({
            scrollDirection: 'vertical',
            effect: 'fadeIn',
            visibleOnly: true,
		  beforeLoad: function(element){
			  console.log('image is about to be loaded');
		  },
		  afterLoad: function(element) {
			  console.log('image was loaded successfully');
		  },
		  onError: function(element) {
			  console.log('image could not be loaded');
		  },
		  onFinishedAll: function() {
			  console.log('finished loading elements');
			  console.log('lazy instance is about to be destroyed')
		  }
	    });
    </script>
    </div>
</div>
<style>@media (min-width: 1024px) {
        .left-column {
            width: 30%;
            float: right;
            padding: 20px 0 20px 20px;
        }
        .right-column {
            width: 30%;
            float: left;
            padding: 0 40px 20px 0;
            margin-top: 5px;
        }
        .right-column.bigger {
            width: 50%;
            padding: 0 20px 15px 0;
        }
        span.img-credits span {
            float: left;
            clear: left;
            width: 30%;
            line-height: 18px;
        }
    }
</style>        </main>

@include('include.footer')