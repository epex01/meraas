@include('include.header')

<main class="main">
            
            

<div id="bitcoin-banner" class="simple-banner style6  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Trade Bitcoin</h1></div>
                                <div class="simple-banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p>Trade Bitcoin CFDs with Vertexmining Exchange</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p>When you open a CFD trading account with Vertexmining Exchange, you can trade the world’s most popular Digital assets, including the legendary Bitcoin.</p></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="images/TradeBitcoin2-min.png" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p>When you open a CFD trading account with Vertexmining Exchange, you can trade the world’s most popular Digital assets, including the legendary Bitcoin.</p></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            <div id="about-bitcoin" class="text-center-block style3" style="background-image: url(images/About%20Bitcoin-min.jpg)">
    <div class="container">
                <div class="text-center-block__title title" data-aos="fade-up"><p>About <strong>Bitcoin</strong></p></div>
                <div class="text-center-block__text text" data-aos="fade-up" data-aos-delay="100"><p>Bitcoin was designed as an alternative payments system that could function independently from any authority, such as a government, central bank or commercial bank. Since its inception in 2008, Bitcoin has been the centre of many controversies. Despite having a vague legal status within the financial ecosystem, Bitcoin has managed to beat the odds and reach adoption levels many never thought possible.</p></div>

        
        
        
            </div>
</div>        
            <div id="invest-in-bitcoin" class="invest-blocks style1"
    style="background-image: url(images/invest-min.png)">
    <div class="container">
                <div class="invest-blocks__title title title_center"  data-aos="fade-up"><p>Invest In <span style="font-weight:800;color:#aa8a5c;">Bitcoin</span></p></div>
                
        <ul class="invest-blocks__list">
                            <li class="invest-blocks__item">
                <div class="invest-blocks__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="invest-blocks__item-icon">
                        <div class="invest-blocks__item-icon-inner" style="background-image: url(images/invest-icon1.svg)"></div>
                    </div>
                    <div class="invest-blocks__item-title"><p>Millions of users</p>
</div>
                    <div class="invest-blocks__item-subtitle"><p>Over a million BTC addresses make transactions daily, and it’s predicted there are over 100 million Bitcoin users worldwide.</p>
</div>
                </div>
            </li>
                                <li class="invest-blocks__item">
                <div class="invest-blocks__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="invest-blocks__item-icon">
                        <div class="invest-blocks__item-icon-inner" style="background-image: url(images/invest-icon2.svg)"></div>
                    </div>
                    <div class="invest-blocks__item-title"><p>High market value</p>
</div>
                    <div class="invest-blocks__item-subtitle"><p>The price of Bitcoin has exceeded $60,000, and the market cap has surpassed $1.1 trillion.</p>
</div>
                </div>
            </li>
                                <li class="invest-blocks__item">
                <div class="invest-blocks__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="invest-blocks__item-icon">
                        <div class="invest-blocks__item-icon-inner" style="background-image: url(images/invest-icon3.svg)"></div>
                    </div>
                    <div class="invest-blocks__item-title"><p>Active trading</p>
</div>
                    <div class="invest-blocks__item-subtitle"><p>Across dozens of Digital Currency exchanges, tens of billions of dollars worth of BTC is exchanged daily.</p>
</div>
                </div>
            </li>
                                <li class="invest-blocks__item">
                <div class="invest-blocks__item-inner" data-aos="fade-up" data-aos-delay="100">
                    <div class="invest-blocks__item-icon">
                        <div class="invest-blocks__item-icon-inner" style="background-image: url(images/invest-icon4.svg)"></div>
                    </div>
                    <div class="invest-blocks__item-title"><p>Active spending</p>
</div>
                    <div class="invest-blocks__item-subtitle"><p>Of the approximately 18 million BTC in circulation, hundreds of thousands are spent daily.</p>
</div>
                </div>
            </li>
                              </ul>

                <div class="invest-blocks__link" data-aos="fade-up" data-aos-delay="200">
            <a href="register"  class="btn btn-orange btn-little">Sign Up</a>

            <div class="warning-text warning-text_center" data-aos="fade-up" data-aos-delay="200">
                <p>* Start Trading Now.</p>
            </div>
        </div>
        
            </div>
</div>        
            <div id="why-trade-bitcoin" class="text-center-block style2" style="background-image: url(images/Why%20trade%20Bitcoin-min.jpg)">
    <div class="container">
                <div class="text-center-block__title title title_center" data-aos="fade-up"><p>Why trade <span style="font-weight:800;color:#cbac63;">Bitcoin?</span></p></div>
                <div class="text-center-block__text text" data-aos="fade-up" data-aos-delay="100"><ul>
	<li>Due to the volatility of Bitcoin, it offers many long and short trading opportunities for active traders to capture.</li>
	<li>The price of Bitcoin is less correlated with other markets which means you can find trade possibilities when there are none in other asset classes.</li>
	<li>The recent stability of the price of BTC suggests it’s no longer the bubble many previously considered it to be.</li>
</ul></div>

        
        
        
                <div class="combined-links">
            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                <a href="register" class="combined-links__item combined-links__right"> Open CFD Account</a>
                
                
                                <a  href="register" class="combined-links__item combined-links__left">Discover Bitcoin trading opportunities with Vertexmining Exchange</a>
                
                            </div>
        </div>

                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                <p><span style="color: rgb(209, 213, 216);">* Start Trading Now.</span></p>
            </div>
                        </div>
</div>        
            <div id="BTCUSD-CFD-specifications" class="simple-text-block style2"
     style="">
    <div class="container">
        <div class="simple-text-block__content">
            <div class="simple-text-block__content-col">
                                <div class="simple-text-block__top-title title" data-aos="fade-up"><p>BTC/USD <span style="font-weight:800;color:#aa8a5c;">CFD Specifications</span></p></div>
                
                <div class="simple-text-block__text text" data-aos="fade-up" data-aos-delay="100">
                    <p>At Vertexmining Exchange, we offer two BTC/USD CFD instruments. One is a standard contract, and the other is a mini contract. When you trade BTC/USD, the base asset is Bitcoin, and the quote asset is US dollars. The standard contract size, often referred to as the Lot size is one BTC; therefore, the smallest order size you can enter is 0.01 BTC. For some traders, that’s too much exposure; therefore, we offer a BTC/USD mini contract. The contract size is 0.01 BTC; hence a micro-Lot is 0.0001 BTC.</p>

<p>BTC/USD is quoted with two decimal places. The second digit is known as the Pip. The value of a Pip depends on the size of the contract. If you open a position for 1 Lot of BTC/USD, the Pip value will be $10, whereas if you open a position for 1 Lot of BTC/USD mini, the Pip value would be $0.10.</p>

<p>One of the benefits of CFD trading is you can trade with leverage to reduce how much capital needed to open a trade. Vertexmining Exchange offers up to 1:2 leverage for trading BTC/USD, which means you only need to provide a 50% margin to open a position.</p>
                </div>
            </div>
            <div class="simple-text-block__content-col">
                                <div class="simple-text-block__table">
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                <span style="font-weight: bold;color: #B14421;">BTC/USD</span>
                            </div>
                            <div class="simple-text-block__item">
                                <span style="font-weight: bold;color: #B14421;">BTC/USD mini</span>
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Base asset
                            </div>
                            <div class="simple-text-block__item">
                                Bitcoin
                            </div>
                            <div class="simple-text-block__item">
                                Bitcoin
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Quote asset
                            </div>
                            <div class="simple-text-block__item">
                                US dollars
                            </div>
                            <div class="simple-text-block__item">
                                US dollars
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Contract size (Lot size)
                            </div>
                            <div class="simple-text-block__item">
                                100 BTC
                            </div>
                            <div class="simple-text-block__item">
                                1 BTC
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Min order size
                            </div>
                            <div class="simple-text-block__item">
                                1 BTC (0.01 Lots)
                            </div>
                            <div class="simple-text-block__item">
                                0.01 BTC (0.01 Lots)
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Max order size
                            </div>
                            <div class="simple-text-block__item">
                                10,000 BTC (100 Lots)
                            </div>
                            <div class="simple-text-block__item">
                                100 BTC (100 Lots)
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Pip position
                            </div>
                            <div class="simple-text-block__item">
                                0.01
                            </div>
                            <div class="simple-text-block__item">
                                0.01
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Pip value
                            </div>
                            <div class="simple-text-block__item">
                                $10
                            </div>
                            <div class="simple-text-block__item">
                                $0.10
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Maximum leverage (margin)
                            </div>
                            <div class="simple-text-block__item">
                                1:2 (50%)
                            </div>
                            <div class="simple-text-block__item">
                                1:2 (50%)
                            </div>
                        </div>
                    </div>
                                    </div>
                            </div>
        </div>
    </div>
</div>        
            
<div id="how-a-CFD-transaction-works" class="simple-text style7   "
     style="">

    
    <div class="container">
        <div class="simple-text__title title title_center" data-aos="fade-up"><p>How a <span style="font-weight:800;color:#aa8a5c;">CFD transaction works</span></p></div>        <div class="simple-text__text text" data-aos="fade-up"><p>When you go long on BTC/USD, you’re technically buying BTC with dollars. When you close the trade, your profit or loss will be calculated in dollars. If the price of Bitcoin increased against the dollar, you’d get more dollars when you close the transaction. If the price of Bitcoin falls, you’ll get back fewer dollars.</p>

<p>
	<br>
</p>

<p style="text-align: center;"><img src="images/info1.png" style="width: auto;" data-result="success" class="fr-fic fr-dii"></p>

<p>
	<br>
</p>

<p>With leverage, you’re able to open larger positions than your capital would otherwise permit. When you trade Digital Currency CFDs with Vertexmining Exchange, you’re able to access leverage as high as 1:2; it means you only need to provide the margin to cover 50% of the position’s value.</p>

<p>
	<br>
</p>

<p style="text-align: center;"><img src="images/info2.png" class="fr-fic fr-dib" data-result="success"></p>

<p>
	<br>
</p>

<p>When you trade Digital Currency CFDs, you don’t need to own either of the assets or currencies included in the pair. For example, if your trading account balance is funded with British pounds, you can still trade BTC/USD. The purpose of a CFD is to allow traders to speculate on an asset’s price without having to purchase it or own it. When a CFD is concluded, it will always be settled in cash by increasing or decreasing the amount of balance in your trading account.</p>

<p>
	<br>
</p>

<p style="text-align: center;"><img src="images/info3.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="costs-to-trade-BTCUSD" class="simple-block left theme1 style7 small_padding  empty_padding_top round_image " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/Costs%20to%20trade%20BTCUSD-min.jpg" alt="" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                                <div class="simple-block__subtitle" data-aos="fade-left"><p>Costs to trade BTC/USD</p></div>
                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>There are different costs involved when trading CFDs with Vertexmining Exchange. There are three primary factors which influence how much you pay for your transactions; they are:</p></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption"><p>The size of your trade, the bigger the trade, the higher the fees.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption"><p>The instrument you’re trading, as different products have different characteristics.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption"><p>The <a href="login">type of account</a> you have, as different accounts have different conditions.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="costs-related-to-trading-CFDs" class="simple-text style8   "
     style="">

    
    <div class="container">
        <div class="simple-text__title title title_center" data-aos="fade-up"><p>Costs Related To <span style="font-weight:800;color:#aa8a5c;">Trading CFDs</span></p></div>        <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;">The different costs to be aware of when trading CFDs are spreads, commissions, and swaps.</p>

<p>
	<br>
</p>

<p style="text-align: center; font-size: 24px; color: #B14421;"><strong><span style="color: rgb(110, 35, 10);">Spread</span></strong></p>

<p>
	<br>
</p>

<p style="text-align: center;">The spread is the difference between the bid and offer price. When you enter a long trade, your order is opened using the Ask-price, which is the higher of the two quotes. When the long trade is closed, the Bid-price, which is the lower of the two quotes. The spread for trading Digital Currencies can become very wide, depending on market conditions.</p>

<p>
	<br>
</p>

<p><img src="images/info4.png" class="fr-fic fr-dib" data-result="success"></p>

<p>
	<br>
</p>

<p style="text-align: center; font-size: 24px; color: #B14421;"><strong><span style="color: rgb(110, 35, 10);">Commission</span></strong></p>

<p>
	<br>
</p>

<p style="text-align: center;">Commissions are charged when you open and close a trade. In this example, the commission charged is €10 per Lot. Once adjusted according to the trade size of 0.1 Lots, the commission becomes €1.00. When converted to dollars using the spot rate, which in this example is 1.22, the commission becomes $1.22.</p>

<p>
	<br>
</p>

<p><img src="images/info5.png" class="fr-fic fr-dib" data-result="success"></p>

<p>
	<br>
</p>

<p style="text-align: center; font-size: 24px; color: #B14421;"><strong><span style="color: rgb(110, 35, 10);">Swap</span></strong></p>

<p>
	<br>
</p>

<p style="text-align: center;">A swap is a fee for holding positions overnight. The fee is derived from the interest rate differential between the base and quote asset. As Bitcoin is not a currency and is therefore not subject to interest rates, consequently the swap fee comes from the US dollar. In this example, the swap rate is $7,875.00 per Lot for both long and short positions.</p>

<p>
	<br>
</p>

<p><img src="images/info6.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            <div id="discover-the-world-of" class="card-image style2 ">
    <div class="container">
        <div class="card-image__content">
            <div class="card-image__block">
                <div class="card-image__subtitle" data-aos="fade-up" data-aos-delay="100"><p>Digital Assets with Vertexmining Exchange</p></div>
                <div class="card-image__title title " data-aos="fade-up" data-aos-delay="200"><p>Discover the world of</p></div>

                <!--                <div class="card-image__title" data-aos="fade-up" data-aos-delay="200"><p>Discover the world of</p></div>
                <div class="card-image__subtitle title" data-aos="fade-up" data-aos-delay="100"><p>Digital Assets with Vertexmining Exchange</p></div>
                -->
                <div class="card-image__text" data-aos="fade-up" data-aos-delay="300"><p>Trade dozens of Digital Currencies in a professional and regulated trading environment by opening a CFD trading account with Vertexmining Exchange.</p></div>

                
                                <div class="combined-links">
                    <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                        
                                                <a href="login" class="combined-links__item combined-links__right">View accounts</a>
                        
                                                <a  href="register" class="combined-links__item combined-links__left">Register now</a>
                        
                                            </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                            </div>
        </div>
        <div class="card-image__image card-image__image_desktop" data-aos="fade-left" data-aos-delay="600">
            <img src="images/bitcoin-card-min.png" alt="">
        </div>

        <div class="card-image__image card-image__image_mobile" data-aos="fade-left" data-aos-delay="600">
            <img src="images/bitcoin-card-min.png" alt="">
        </div>
    </div>
</div>        
            <div id="bitcoin-social-links" class="social-links" >
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

@include('include.footer')