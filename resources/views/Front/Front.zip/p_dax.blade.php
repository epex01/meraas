@include('include.header')

<main class="main">
            
            

<div id="trade-DAX" class="simple-banner style1  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Trade DAX</h1></div>
                                <div class="simple-banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p><span lang="en-US">When you open a CFD trading account with Vertexmining Exchange,
you can trade the world’s most popular financial markets, including
the renowned DAX index, a benchmark of the German stock market.</span></p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p><strong>Start trading DAX CFDs with Vertexmining Exchange</strong></p></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="images/dax-banner.png" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p><strong>Start trading DAX CFDs with Vertexmining Exchange</strong></p></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            <div id="about-DAX" class="text-center-block style7" style="background-image: url(images/dax-about-min.jpg)">
    <div class="container">
                <div class="text-center-block__title title title_center" data-aos="fade-up"><p>About <strong>DAX</strong></p></div>
                <div class="text-center-block__text text" data-aos="fade-up" data-aos-delay="100"><div style="max-width: 703px; margin: 0 auto;">

	<p style="text-align: center;">The DAX, known in german language as Deutscher Aktienindex is a popular stock market index that is a trading instrument and a reflection of the German economy. Also known as the Germany 30 or DE30, this index contains 30 major German companies on the Frankfurt Stock Exchange. In the third quarter of 2021, the DAX constituents will be increased to forty companies.</p>

	<p style="text-align: center;">Germany is Europe’s largest economy, and the DAX contains many international brands which play an essential role in the global economy. Notable constituents include BMW, Deutsche Bank, DHL and Siemens.</p>
</div></div>

        
        
        
            </div>
</div>        
            <div id="constituents-of-the-DAX-index" class="logos-list"
     style="     ">
    <div class="container">
        <div class="logos-list__title title title_center" data-aos="fade-up"><p>Constituents of the <span style="font-weight:800;color:#aa8a5c;">DAX index</span></p></div>

        <div class="logos-list__text text" data-aos="fade-up" data-aos-delay="200"><p style="text-align: center;">Since the DAX index was established on the 1st of July 1998, many companies have come and gone. This index contains some of the best-known brands in finance, fashion, pharmaceuticals, technology and the automotive industry.</p></div>

        <div class="logos-list__list" data-aos="fade-up" data-aos-delay="300">
            <div class="logos-list__list-inner">
                                <img src="images/adidas.png" alt="Adidas (ADS)">
                                                <img src="images/allianz.png" alt="Allianz (ALV)">
                                                <img src="images/basf.png" alt="BASF (BAS)">
                                                <img src="images/bayer.png" alt="Bayer (BAYN)">
                                                <img src="images/bmw.png" alt="Bayerische Motoren Werke (BMW)">
                                                <img src="images/bdf.png" alt="Beiersdorf (BEI)">
                                                <img src="images/commerzbank.png" alt="Commerzbank (CBK)">
                                                <img src="images/continental.png" alt="Continental AG (CON)">
                                                <img src="images/daimler.png" alt="Daimler (DAI)">
                                                <img src="images/deutsche_bank.png" alt="Deutsche Bank (DBK)">
                 <br>                                 <img src="images/lufthansa.png" alt="Deutsche Lufthansa (LHA)">
                                                <img src="images/deutsche_post.png" alt="Deutsche Post (DPW)">
                                                <img src="images/deutsche_telekom.png" alt="Deutsche Telekom (DTE)">
                                                <img src="images/eon.png" alt="E.ON (EON)">
                                                <img src="images/fresenius_medical_care.png" alt="Fresenius Medical Care (FME)">
                                                <img src="images/heidelbergcement.png" alt="HeidelbergCement (HEI)">
                                                <img src="images/henkel.png" alt="Henkel (HNK1)">
                                                <img src="images/infineon.png" alt="Infineon Technologies (IFX)">
                                                <img src="images/merck.png" alt="Merck (MRC)">
                                                <img src="images/munichRE.png" alt="Muenchener Rueckversicherungs (MUV)">
                                                <img src="images/prosiebensat.png" alt="ProSiebenSat.1 Media (PSM)">
                                                <img src="images/rwe.png" alt="RWE (RWE)">
                                                <img src="images/sap.png" alt="SAP (DE) (SAP)">
                                                <img src="images/siemens.png" alt="Siemens (SIE)">
                                                <img src="images/thyssenkrup.png" alt="ThyssenKrupp (TKA)">
                                                <img src="images/wols.png" alt="Volkswagen (VOW)">
                                                <img src="images/vonovia.png" alt="Vonovia (VNA)">
                                            </div>
            <div class="logos-list__list-more">
                <i class="m-icon icon-down-open"></i>
                <i class="m-icon icon-up-open"></i>
            </div>
        </div>

        <div class="logos-list__slider" data-aos="fade-up" data-aos-delay="300">
                        <div class="logos-list__slider-item">
                <img src="images/adidas.png" alt="Adidas (ADS)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/allianz.png" alt="Allianz (ALV)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/basf.png" alt="BASF (BAS)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/bayer.png" alt="Bayer (BAYN)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/bmw.png" alt="Bayerische Motoren Werke (BMW)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/bdf.png" alt="Beiersdorf (BEI)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/commerzbank.png" alt="Commerzbank (CBK)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/continental.png" alt="Continental AG (CON)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/daimler.png" alt="Daimler (DAI)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/deutsche_bank.png" alt="Deutsche Bank (DBK)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/lufthansa.png" alt="Deutsche Lufthansa (LHA)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/deutsche_post.png" alt="Deutsche Post (DPW)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/deutsche_telekom.png" alt="Deutsche Telekom (DTE)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/eon.png" alt="E.ON (EON)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/fresenius_medical_care.png" alt="Fresenius Medical Care (FME)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/heidelbergcement.png" alt="HeidelbergCement (HEI)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/henkel.png" alt="Henkel (HNK1)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/infineon.png" alt="Infineon Technologies (IFX)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/merck.png" alt="Merck (MRC)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/munichRE.png" alt="Muenchener Rueckversicherungs (MUV)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/prosiebensat.png" alt="ProSiebenSat.1 Media (PSM)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/rwe.png" alt="RWE (RWE)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/sap.png" alt="SAP (DE) (SAP)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/siemens.png" alt="Siemens (SIE)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/thyssenkrup.png" alt="ThyssenKrupp (TKA)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/wols.png" alt="Volkswagen (VOW)">
            </div>
                        <div class="logos-list__slider-item">
                <img src="images/vonovia.png" alt="Vonovia (VNA)">
            </div>
                    </div>
    </div>
</div>        
            
<div id="DAX-trading-insights" class="simple-block right theme1 style1  empty_padding_top empty_padding_bottom round_image " style="background: #f3f3f3;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/dax-img-min.jpg" alt="DAX Trading Insights" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>DAX <span style="font-weight:800;color:#aa8a5c;">Trading Insights</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>The DAX is highly correlated with other currency pairs which reference the euro, for example, EUR/USD and GBP/EUR have a strong correlation with this index.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>Due to the low number of constituents and lack of diversity, the DAX can be very volatile, which offers both opportunities and risks.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style4" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption">
</div>
                                                <div class="simple-block__list-text"><p>Low-interest rates cause investors to put their money into riskier assets such as stocks, if interest rates are increased, investors may pull their money from the stock market, and purchase bonds. This causes stocks and therefore, indices to fall in value.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                                <div class="simple-block__bottom-text" data-aos="fade-up" data-aos-delay="400"><p><strong>Discover DAX CFD trading opportunities with Vertexmining Exchange</strong></p></div>
                
                                                                
                                <div class="simple-block__link simple-block__link_center" data-aos="fade-left" data-aos-delay="300">
                                        <a href="register" class="btn btn-big btn-orange">Open Account</a>
                    <div class="warning-text">
                        <p>* Start Trading Now.</p>
                    </div>
                    
                                    </div>
                
                
            </div>
        </div>
    </div>
</div>        
            <div id="DAX-CFD-specifications" class="simple-text-block style3"
     style="background: #ffffff;">
    <div class="container">
        <div class="simple-text-block__content">
            <div class="simple-text-block__content-col">
                                <div class="simple-text-block__top-title title" data-aos="fade-up"><p>DAX CFD <span style="font-weight:800;color:#aa8a5c;">Specifications</span></p></div>
                
                <div class="simple-text-block__text text" data-aos="fade-up" data-aos-delay="100">
                    <p>The symbol for the DAX index varies between brokers and investment firms. At Vertexmining Exchange, we refer to the German stock market index as DAX. Other firms may call it DE30 or GER30. The DAX is quoted against the euro. When you trade DAX CFDs, the base asset is the underlying index, and the quote asset is euros. The standard contract size, often referred to as the Lot size is one index. An important characteristic of trading with Vertexmining Exchange is the smallest order size you can enter is 0.01 Lots, which allows you to trade this volatile instrument with lower exposure.</p>

<p>The Pip value of DAX is one euro. This means, if your order is for 2 Lots, if the price moves up or down by one Pip, the impact to your profit or loss would be €2. Similarly, if your order was for 0.5 Lots, and the price moves up or down by one Pip, the impact on your profit or loss would be €0.50.</p>

<p>One of the benefits of CFD trading is you can use leverage to reduce how much capital required to open positions. Vertexmining Exchange offers up to 1:20 leverage for trading major stock market indices, such as the DAX; therefore, you only need to provide a 5% margin to open a position.</p>
                </div>
            </div>
            <div class="simple-text-block__content-col">
                                <div class="simple-text-block__table">
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Base asset: DAX
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Quote asset: euros
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Contract size (Lot size):   1 index (1 Lot)
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Min trade size: 0.1 index (0.01 Lots)
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Max trade size: 1000 indices (100 Lots)
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Pip position: 1.00
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Pip value: €1
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Maximum leverage (margin): 1:20 (5%)
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                <b>Trading hours: 09:05-23:00 (Mon-Fri)</b>
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                    </div>
                            </div>
        </div>
    </div>
</div>        
            
<div id="how-a-CFD-transaction-works-1" class="simple-text style8   "
     style="background: #ffffff;">

    
    <div class="container">
        <div class="simple-text__title title title_center" data-aos="fade-up"><p>How a CFD <span style="font-weight:800;color:#aa8a5c;">Transaction Works</span></p></div>        <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;">When you go long on the DAX, which means you expect the price to rise, you’re theoretically buying DAX with euros. To close the position, another trade in the opposite direction is used to offset it. Your profit or loss will be determined by the difference in value between the opening and closing orders. If the value of DAX increases, you’d end up with more euros when the position is closed. However, if the value of DAX falls, you’d end up with fewer euros.</p>

<p style="text-align: center;"><img src="images/dax-info1.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="how-a-CFD-transaction-works-2" class="simple-text style8   "
     style="background: #f3f3f3;">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;">With leverage, you can open larger positions than your capital would otherwise permit. When you trade CFDs with Vertexmining Exchange, you can use leverage as high as 1:20; meaning you only need to provide margin to cover 5% of the position’s value.</p>

<p style="text-align: center;"><img src="images/dax-info2.png" style="width: auto;" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="how-a-CFD-transaction-works-3" class="simple-text style7   "
     style="background: #ffffff;">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;">When you trade CFDs, you don’t need to own either of the assets or currencies involved in the trade. For example, if your trading account balance is funded with pounds, you can still trade DAX. The purpose of a CFD is to allow traders to speculate on an asset’s price without having to purchase it or own it. When a CFD is closed, it will always be settled in cash either by increasing or decreasing your trading balance.</p>

<p style="text-align: center;"><img src="images/dax-info3.png" style="width: auto;" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="costs-to-trade-DAX" class="simple-block left theme1 style7 small_padding  empty_padding_bottom round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/dax-costs-min.jpg" alt="" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                                <div class="simple-block__subtitle" data-aos="fade-left"><p>Costs To Trade DAX</p></div>
                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>There are different costs associated with trading CFDs with Vertexmining Exchange. There are three primary factors which influence how much it costs to trade CFDs; they are:</p></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption"><p>The size of your trade, the bigger the trade, the higher the fees.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption"><p>The instrument you’re trading, as different products have different characteristics.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption"><p>The <a href="tradingaccounts">type of account</a> you have, as different accounts have different conditions.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="costs-related-to-trading-CFDs-1" class="simple-text style8 pretty_bg   "
     style="background: #ffffff;">

        <div class="simple-text__bg simple-text__bg_left"><img src="../themes/brokerkit/assets/images/line-bg-left.svg" alt=""></div>
    <div class="simple-text__bg simple-text__bg_right"><img src="../themes/brokerkit/assets/images/line-bg-right.svg" alt=""></div>
    
    <div class="container">
        <div class="simple-text__title title title_center" data-aos="fade-up"><p>Costs Related To <span style="font-weight:800;color:#aa8a5c;">Trading CFDs</span></p></div>        <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;">The different costs to be aware of when trading CFDs are spreads, commissions, and swaps.</p>

<p style="text-align: center;">
	<br>
</p>

<h3 style="text-align: center;"><strong>Spread</strong></h3>

<p style="text-align: center;">The spread is the difference between the bid and Ask-price. When you enter a long trade, your order is opened using the Ask-price, which is the higher of the two quotes. When the long trade is closed, the Bid-price, which is the lower of the two quotes. If the Ask-price is 13,658 and the Bid-price is 13,650, it means the spread is 8-Pips.</p>

<p style="text-align: center;"><img src="images/dax-info4.png" style="width: auto;" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="costs-related-to-trading-CFDs-2" class="simple-text style8   "
     style="background: #f3f3f3;">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><h3 style="text-align: center;"><strong>Commission</strong></h3>

<p style="text-align: center;">Commissions are charged when you open and close a trade and therefore impacts your profitability. In this example, the commission charged is €10 per Lot. Once adjusted according to the trade size of 0.5 Lots, the commission becomes €5 on each side of the trade.</p>

<p style="text-align: center;"><img src="images/uploaded-files/dax-info5.png" style="width: auto;" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="costs-related-to-trading-CFDs" class="simple-text style8   "
     style="background: #ffffff;">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><h3 style="text-align: center;"><strong>Swap</strong></h3>

<p style="text-align: center;">A swap is a fee for holding positions overnight. The fee is derived from the interest rate differential between the base and quote asset. As Bitcoin is not a currency and is therefore not subject to interest rates, consequently the swap fee comes from the US dollar. In this example, the swap rate is $7,875.00 per Lot for both long and short positions.</p>

<p style="text-align: center;"><img src="images/dax-info6.png" style="width: auto;" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            <div id="want-practice-first" class="card style3" style="background: #ffffff;">
    <div class="container">
        <div class="card__block" style="background-image: url(images/4044078-min.png)">
            <div class="card__content">
                                <div class="card__text" data-aos="fade-left"><p>Discover a wide range of opportunities across a variety of asset classes. See what else you can trade with Vertexmining Exchange.</p>

<p>
	<br>
</p>

<p style="color:#cbac63;">#Forex #Stocks &nbsp;#DigitalCurrency #Indices #Bonds</p></div>
            </div>

            
                        <a href="register"  class="btn btn-big btn-white-red">Open Account</a>
            
                    </div>

                <div class="warning-text">
            <p>* Start Trading Now.</p>
        </div>
            </div>
</div>        
            <div id="social-links" class="social-links" style="background: #ffffff;">
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

@include('include.footer')