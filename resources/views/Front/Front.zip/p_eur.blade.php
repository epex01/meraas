@include('include.header')

<main class="main">
            
            

<div id="eurusd-banner" class="simple-banner style6  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Trade EUR/USD</h1></div>
                                <div class="simple-banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p>Trade Forex CFDs with Vertexmining Exchange</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p>When you open a CFD trading account with Vertexmining Exchange, you can trade the world’s most popular currency pairs, including the legendary euro versus US dollar.</p>

<p><strong>Start trading EUR/USD with Vertexmining Exchange</strong></p></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="images/image%2021-min.png" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p>When you open a CFD trading account with Vertexmining Exchange, you can trade the world’s most popular currency pairs, including the legendary euro versus US dollar.</p>

<p><strong>Start trading EUR/USD with Vertexmining Exchange</strong></p></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            
<div id="about-EUR-uSD" class="simple-block left theme1 style1 small_padding  round_image " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/About%20EURUSD.jpg" alt="About EUR/USD" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>About <span style="font-weight:800;color:#aa8a5c;">EUR/USD</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p><span class="fr-tmp fr-sm">F</span>The US dollar is the most traded currency in the world, and the euro is the second. Not surprisingly, EUR/USD is the most traded currency pair in the world. The two currencies that form this trading pair represent two of the world’s largest economies and markets.</p>

<p style="font-weight:800;color:#B14421;font-size:24px;"><span style="color: rgb(110, 35, 10);">Euro</span></p>

<p>After decades of discussion and years of planning, the euro became a reality on the 1st of January 1999. The euro is a currency used by nineteen countries in the European Union.</p>

<p style="font-weight:800;color:#B14421;font-size:24px;"><span style="color: rgb(110, 35, 10);">US dollar</span></p>

<p>The US dollar came to existence in 1792, shortly after the American Revolutionary War ended. Following a series of significant geopolitical shifts, such as WWII, the USD became the world’s leading currency.<span class="fr-tmp fr-em">F</span></p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            <div id="EURUSD-CFD-specifications" class="simple-text-block style4"
     style="">
    <div class="container">
        <div class="simple-text-block__content">
            <div class="simple-text-block__content-col">
                                <div class="simple-text-block__top-title title" data-aos="fade-up"><p>EUR/USD <span style="font-weight:800;color:#aa8a5c;">CFD Specifications</span></p></div>
                
                <div class="simple-text-block__text text" data-aos="fade-up" data-aos-delay="100">
                    <p>Wenn Sie mit EUR/USD handeln, beträgt das Basisvermögen Euro und das Quotierungsvermögen Dollar. Die Vertragsgröße, oft als Losgröße bezeichnet, beträgt 100.000 Euro. Die kleinste Bestellgröße, die aufgegeben werden kann, beträgt 1.000 Euro, auch als Micro-Lot oder 0,01 Lot bezeichnet. Order können nur in Schritten von 1.000 platziert werden, was bedeutet, dass die zweitkleinste Bestellgröße, die aufgegeben werden kann, 2.000 beträgt.</p>

<p>EUR/USD wird mit fünf Stellen (nach dem Komma) angegeben. Die vierte Stelle ist als Pip bekannt, und die fünfte Stelle ist als Point bekannt. Der Wert eines Pip hängt von der Größe des Vertrags ab. Wenn der Vertrag 1 Lot umfasst, beträgt der Pip-Wert 10 USD. Wenn die Vertragsgröße 0,01 Lot wäre, wäre der Pip-Wert 0,10 USD.</p>

<p>Einer der Vorteile des CFD-Handels besteht darin, dass Sie mit Hebeleffekten handeln können, wodurch weniger Geld für die Eröffnung eines Handels benötigt wird. Vertexmining Exchange bietet einen Hebel von bis zu 1:30 für den Handel mit EUR/USD, was bedeutet, dass Sie nur eine Marge von 3,33% bereitstellen müssen, um eine Position zu eröffnen.</p>

<p>Hebelwirkung ist ein wichtiges Instrument für den Handel mit Forex-CFDs, da kleine Preisbewegungen einen größeren Einfluss auf größere Positionen haben. Vergessen Sie jedoch nicht, wenn sich der Preis gegen Ihre Position bewegt, sind die Verluste umso größer, je größer die Position ist.</p>
                </div>
            </div>
            <div class="simple-text-block__content-col">
                                <div class="simple-text-block__table">
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Base asset: Euros
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Quote asset: US dollars
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Contract size (Lot size): 100,000 EUR (1 Lot)
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Min. trade size: 1,000 EUR (0.01 Lots)
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Max. trade size: 10,000,000 EUR (100 Lots)
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Pip position: 0.00010
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                <b>Maximum leverage (margin): 1:30 (3.33%)</b>
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                    </div>
                            </div>
        </div>
    </div>
</div>        
            <div id="why-trade-EURUSD" class="text-center-block style2" style="background-image: url(images/Why%20trade%20EURUSD.jpg)">
    <div class="container">
                <div class="text-center-block__title title title_center" data-aos="fade-up"><p>Why trade <span style="font-weight:800;color:#cbac63;">EUR/USD?</span></p></div>
                <div class="text-center-block__text text" data-aos="fade-up" data-aos-delay="100"><ul>
	<li>Euros and dollars are always in demand which causes the rate to move often. Both economies are home to the largest banks, financial institutions, securities markets and multinational corporations in the world.</li>
	<li>Because inflation is low and economic growth is fairly stable in the EU and the USA, these circumstances make the EUR/USD pair a compelling instrument for traders.</li>
	<li>Because of the huge demand for euros and dollars, you can usually find the EUR/USD trading pair offers the tightest spreads out of all major currency pairs.</li>
</ul></div>

        
        
        
                <div class="combined-links">
            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                <a href="register" class="combined-links__item combined-links__right">Open Account</a>
                
                
                                <a  href="register" class="combined-links__item combined-links__left">Discover EUR/USD trading opportunities with Vertexmining Exchange</a>
                
                            </div>
        </div>

                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                <p><span style="color: rgb(209, 213, 216);">* Start Trading Now.</span></p>
            </div>
                        </div>
</div>        
            
<div id="how-a-CFD-transaction-works" class="simple-text style7   "
     style="">

    
    <div class="container">
        <div class="simple-text__title title title_center" data-aos="fade-up"><p>How a <span style="font-weight:800;color:#aa8a5c;">CFD transaction works</span></p></div>        <div class="simple-text__text text" data-aos="fade-up"><p>When you go long on EUR/USD, you’re theoretically buying euros with dollars. When you close the trade, your profit or loss will be calculated in dollars. If the euro strengthened against the dollar, you’d get more dollars when you close the transaction. If the euro weakened, you’ll get back fewer dollars.</p>

<p>
	<br>
</p>

<p style="text-align: center;"><img src="images/eurusd-info-1-min.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="how-a-CFD-transaction-works-2" class="simple-text style7   "
     style="background: #e7e7e7;">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><p>With leverage, you’re able to open larger positions than your capital would otherwise permit. When you trade forex CFDs with Vertexmining Exchange, you can use leverage as high as 1:30; meaning you only need to provide margin to cover 3.33% of the position’s value.</p>

<p>
	<br>
</p>

<p style="text-align: center;"><img src="images/eurusd-info-2.png" class="fr-fic fr-dib" data-result="success"></p>

<p>
	<br>
</p>

<p>When you trade forex CFDs, you don’t need to own either of the currencies included in the pair. For example, if your trading account balance is denominated in British pounds, you can still trade EUR/USD. The purpose of a CFD is to enable traders to speculate on the price of one currency against another. When a CFD is concluded, it will always be settled in cash, i.e. by increasing or decreasing the amount of balance in your trading account.</p>

<p>
	<br>
</p>

<p style="text-align: center;"><img src="images/eurusd-info-3.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="costs-to-trade-EURUSD" class="simple-block left theme1 style7 small_padding  round_image " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/Costs%20to%20trade%20EURUSD-min.jpg" alt="" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                                <div class="simple-block__subtitle" data-aos="fade-left"><p><span style="color: rgb(110, 35, 10);">Costs to trade EUR/USD</span></p></div>
                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>There are different costs involved when trading CFDs with Vertexmining Exchange. There are three primary factors which influence how much you pay for your transactions; they are:</p></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption"><p>The size of your trade, the bigger the trade, the higher the fees.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption"><p>The instrument you’re trading, as different products have different characteristics.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption"><p>The <a href="tradingaccounts">type of account</a> you have, as different accounts have different conditions.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="costs-related-to-trading-CFDs" class="simple-text style8 pretty_bg   "
     style="">

        <div class="simple-text__bg simple-text__bg_left"><img src="../themes/brokerkit/assets/images/line-bg-left.svg" alt=""></div>
    <div class="simple-text__bg simple-text__bg_right"><img src="../themes/brokerkit/assets/images/line-bg-right.svg" alt=""></div>
    
    <div class="container">
        <div class="simple-text__title title title_center" data-aos="fade-up"><p>Costs related to <span style="font-weight:800;color:#aa8a5c;">trading CFDs</span></p></div>        <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;">The different costs to be aware of when trading forex CFDs are spreads, commissions and swaps.</p>

<p style="text-align: center;">
	<br>
</p>

<h3 style="text-align: center;"><strong>Spread</strong></h3>

<p style="text-align: center;">The spread is the difference between the bid and offer price. When you enter a long trade, your order is opened using the Ask-price, which is the higher of the two quotes. When the long trade is closed, the Bid-price, which is the lower of the two quotes.</p>

<p style="text-align: center;"><img src="images/eurusd-info-4-min.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="commission" class="simple-text style8   "
     style="background: #f3f3f3;">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><h3 style="text-align: center;"><strong>Commission</strong></h3>

<p style="text-align: center;">Commissions are charged when you open and close a trade. In this example, the commission charged is €10 per Lot. Once adjusted according to the trade size of 0.01 Lots the commission becomes €0.10. When converted to dollars, it becomes $0.12.</p>

<p style="text-align: center;"><img src="images/eurusd-info-5-min.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="swap" class="simple-text style8   "
     style="">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><h3 style="text-align: center;"><strong>Swap</strong></h3>

<p style="text-align: center;">A swap is a fee for holding positions overnight. The price is derived from the base and quote currency’s interest rate differential and varies depending on whether your position is long or short. In this example, the swap rate for a long EUR/USD position is 5 Pips, and the rate for a short position is 1 Pip.</p>

<p style="text-align: center;"><img src="images/eurusd-info-6-min.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            <div id="discover-other" class="card-image style2 ">
    <div class="container">
        <div class="card-image__content">
            <div class="card-image__block">
                <div class="card-image__subtitle" data-aos="fade-up" data-aos-delay="100"><p style="color:#17181D;font-weight:500;">Discover Other</p>

<p style="font-weight:800;color:#aa8a5c;">Popular Currency Pairs</p></div>
                <div class="card-image__title title " data-aos="fade-up" data-aos-delay="200"></div>

                <!--                <div class="card-image__title" data-aos="fade-up" data-aos-delay="200"></div>
                <div class="card-image__subtitle title" data-aos="fade-up" data-aos-delay="100"><p style="color:#17181D;font-weight:500;">Discover Other</p>

<p style="font-weight:800;color:#aa8a5c;">Popular Currency Pairs</p></div>
                -->
                <div class="card-image__text" data-aos="fade-up" data-aos-delay="300"><p>Vertexmining Exchange offers the world’s most liquid currency pairs on two incredible trading platforms.</p></div>

                
                                <div class="combined-links">
                    <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                        
                                                <a href="register" class="combined-links__item combined-links__right">GBP/USD</a>
                        
                        
                                                <a href="register" class="combined-links__item combined-links__left">USD/JPY</a>
                                            </div>
                </div>

                                            </div>
        </div>
        <div class="card-image__image card-image__image_desktop" data-aos="fade-left" data-aos-delay="600">
            <img src="images/product-text-block__img-min.png" alt="">
        </div>

        <div class="card-image__image card-image__image_mobile" data-aos="fade-left" data-aos-delay="600">
            <img src="images/product-text-block__img-min.png" alt="">
        </div>
    </div>
</div>        
            <div id="EURUSD-social-links" class="social-links" >
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

@include('include.footer')