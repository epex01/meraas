@include('include.header')

<main class="main">
            
            

<div id="" class="simple-banner style6  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Trade USD/JPY</h1></div>
                                <div class="simple-banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p>Trade Forex CFDs with Vertexmining Exchange</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p><strong>When you open a CFD trading account with Vertexmining Exchange, you can trade the world’s most popular currency pairs, including the epic Japanese yen versus the US dollar.</strong></p></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="images/image%2024-min.png" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p><strong>When you open a CFD trading account with Vertexmining Exchange, you can trade the world’s most popular currency pairs, including the epic Japanese yen versus the US dollar.</strong></p></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            
<div id="" class="simple-block left theme1 style1 small_padding  round_image " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/usd-jpy-about-min.jpg" alt="About USD/JPY" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>About <span style="font-weight:800;color:#aa8a5c;">USD/JPY</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>The USD/JPY currency pair is one of the most actively traded in the forex market. What makes this combination so interesting is neither the US nor Asian trading sessions overlap. Before China emerged as a global player, the United States, Japan and the Soviet Union were rivalling each other for the spot as the world’s leading economic powerhouse.</p>

<p>Before Japan emerged as a world leader, like many other currencies at the time, the Japanese yen was pegged to the US dollar. The fixed rate was 360 yen to 1 USD. Once the United States gold standard was abandoned, the yen floated freely and ultimately appreciated significantly against the US dollar.</p>

<p>Japan is one of the world’s largest exporters, and the demand for Japanese manufactured products sparks demand for the currency. However, the yen is also considered a safe-haven currency, which means it performs well during slumps. Since JPY is in demand when the economy is both performing and underperforming, it results in frequent short term trading opportunities.
	<br>
	<br>
	<br>
</p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            <div id="" class="simple-text-block style4"
     style="">
    <div class="container">
        <div class="simple-text-block__content">
            <div class="simple-text-block__content-col">
                                <div class="simple-text-block__top-title title" data-aos="fade-up"><p>USD/JPY <span style="font-weight:800;">CFD Specifications</span></p></div>
                
                <div class="simple-text-block__text text" data-aos="fade-up" data-aos-delay="100">
                    <p>The symbol for the Japanese yen in the forex market is JPY, and the symbol for US dollars is USD. Collectively, the pair is USD/JPY. Unlike most other trading instruments and dollar crosses, USD is not the quote asset in this currency pair. Since JPY has a much lower value than USD, it would be awkward to use dollars as the quote currency.</p>

<p>An unusual characteristic of USD/JPY is it’s quoted with just three numbers after the decimal point, whereas most other currency pairs are quoted with five digits. Therefore the Pip position is the second digit after the decimal, unlike most other forex pairs where it is the fourth digit after the decimal point. The value of a Pip depends on the size of the trade. If the order is for 1 Lot, the Pip value will be ¥1,000. If the contract size were 0.01 Lots, the Pip value would be ¥10.</p>

<p>One of the benefits of CFD trading is you can apply leverage to your positions. This reduces how much money is required to open a trade. Vertexmining Exchange offers up to 1:30 leverage for trading USD/JPY, which means you only need to provide 3.33% margin to open a position.</p>

<p><span lang="en-US">Keep in mind that leverage is not free money that
you should feel compelled to use and should only ever be used
strategically since larger positions may lead to larger losses or
profits.</span></p>
                </div>
            </div>
            <div class="simple-text-block__content-col">
                                <div class="simple-text-block__table">
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Base asset: US dollars
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Quote asset: Japanese yen
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Contract size (Lot size): 100,000 United States dollars
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Min. trade size: 1,000 USD (0.01 Lots)
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Max. trade size: 10,000,000 USD (100 Lots)
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Pip position: 0.010
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Pip value: ¥1,000
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                <b>Maximum leverage (margin): 1:30 (3.33%)</b>
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                        <div class="simple-text-block__row">
                        <div class="simple-text-block__row-inner">
                            <div class="simple-text-block__item">
                                Trading hours: 00:00 to 23:59
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                            <div class="simple-text-block__item">
                                
                            </div>
                        </div>
                    </div>
                                    </div>
                            </div>
        </div>
    </div>
</div>        
            <div id="" class="text-center-block style2" style="background-image: url(images/Why%20trade%20GBPUSD.jpg)">
    <div class="container">
                <div class="text-center-block__title title title_center" data-aos="fade-up"><p>Why trade <span style="font-weight:800;color:#B14421;">USD/JPY CFDs?</span></p></div>
                <div class="text-center-block__text text" data-aos="fade-up" data-aos-delay="100"><ul>
	<li>The Bank of Japan is well known for its regular interventions to keep the yen’s value with certain levels. The Japanese central bank wants to keep the yen competitive against other currencies.</li>
	<li>The price of USD/JPY is strongly correlated to the Japanese commodities market, making this currency pair more susceptible to fundamental news and economic reports.</li>
	<li>Many traders find USD/JPY an appealing forex pair to trade as it presents frequent, distinguished and relatively smooth trends. Experts recommend USD/JPY for newer traders.</li>
</ul></div>

        
        
        
                <div class="combined-links">
            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                <a href="register" class="combined-links__item combined-links__right">Start trading CFDs</a>
                
                
                
                                <a href="forex" class="combined-links__item combined-links__left">Discover opportunities in the forex market</a>
                            </div>
        </div>

                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                <p><span style="color: rgb(209, 213, 216);">* Start Trading Now.</span></p>
            </div>
                        </div>
</div>        
            
<div id="" class="simple-text style8   "
     style="">

    
    <div class="container">
        <div class="simple-text__title title title_center" data-aos="fade-up"><p>How A CFD <span style="font-weight:800;color:#aa8a5c;">Transaction Works</span></p></div>        <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;">When you go long on USD/JPY, you’re theoretically buying dollars with yen. When you close the trade, it’s offset with another order in the opposite direction. The difference between the opening order and closing order determine the amount of profit or loss. Your profit or loss will be calculated in JPY. If the dollar strengthened against the yen, you’d get more yen when you close the transaction. If the dollar weakened, you’d get back fewer yen.</p>

<p style="text-align: center;"><img src="images/USDJPY-info1.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="" class="simple-text style8   "
     style="background: #f3f3f3;">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;">With leverage, you’re able to open larger positions than your capital would otherwise permit. When you trade forex CFDs with Vertexmining Exchange, you can use leverage as high as 1:30; meaning you only need to provide margin to cover 3.33% of the position’s value.</p>

<p style="text-align: center;"><img src="images/USDJPY-info2.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="" class="simple-text style7   "
     style="">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;">When you trade forex CFDs, you don’t need to own either of the currencies included in the pair. For example, if your trading account balance is denominated in British pounds, you can still trade USD/JPY. The purpose of a CFD is to let traders speculate on the price of one currency against another. When a CFD is closed, it will always be settled in cash, i.e. by increasing or decreasing the amount of balance in your trading account.</p>

<p style="text-align: center;"><img src="images/USDJPY-info3.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="" class="simple-block left theme1 style1 small_padding  empty_padding_bottom round_image " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/usd-jpg-costs-min.jpg" alt="" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                                <div class="simple-block__subtitle" data-aos="fade-left"><p>Costs To Trade USD/JPY</p></div>
                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>There are different costs involved when trading CFDs with Vertexmining Exchange. There are three primary factors which influence how much you pay for your transactions; they are:</p></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption"><p style="font-weight: 400;">The size of your trade, the bigger the trade, the higher the fees.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption"><p style="font-weight: 400;">The instrument you’re trading, as different products have different characteristics.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style2" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption"><p style="font-weight: 400;">The <a href="tradingaccounts">type of account</a> you have, as different accounts have different conditions.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="" class="simple-text style8 pretty_bg   "
     style="">

        <div class="simple-text__bg simple-text__bg_left"><img src="../themes/brokerkit/assets/images/line-bg-left.svg" alt=""></div>
    <div class="simple-text__bg simple-text__bg_right"><img src="../themes/brokerkit/assets/images/line-bg-right.svg" alt=""></div>
    
    <div class="container">
        <div class="simple-text__title title title_center" data-aos="fade-up"><p>Costs Related To <span style="font-weight:800;color:#aa8a5c;">Trading CFDs</span></p></div>        <div class="simple-text__text text" data-aos="fade-up"><p style="text-align: center;">The different costs to be aware of when trading forex CFDs are spreads, commissions and swaps.</p>

<p style="text-align: center;">
	<br>
</p>

<h3 style="text-align: center;"><strong>Spread</strong></h3>

<p style="text-align: center;">The spread is the difference between the bid and offer price. When you enter a long trade, your order is opened using the Ask-price, which is the higher of the two quotes. When the long trade is closed, the Bid-price, which is the lower of the two quotes. The opposite process takes place when opening and closing a short trade.</p>

<p style="text-align: center;"><img src="images/USDJPY-info4.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="" class="simple-text style8   "
     style="background: #f3f3f3;">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><h3 style="text-align: center;"><strong>Commission</strong></h3>

<p style="text-align: center;">Commissions are charged when you open and close a trade. In this example, the commission charged is $10 per Lot. Once adjusted according to the trade size of 0.05 Lots the commission becomes $0.50.</p>

<p style="text-align: center;"><img src="images/USDJPY-info5.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            
<div id="" class="simple-text style8   "
     style="">

    
    <div class="container">
                <div class="simple-text__text text" data-aos="fade-up"><h3 style="text-align: center;"><strong>Swap</strong></h3>

<p style="text-align: center;">A swap is a fee for holding positions overnight. The price is derived from the base and quote currency’s interest rate differential and varies depending on whether your position is long or short. In this example, the swap rate for a long USD/JPY position is $1.80, and the rate for a short position is $3.75. Swap rates fluctuate over time as banks adjust their interest rates.</p>

<p style="text-align: center;"><img src="images/USDJPY-info6.png" class="fr-fic fr-dib" data-result="success"></p></div>

        
            </div>
</div>        
            <div id="discover-other" class="card-image style1 ">
    <div class="container">
        <div class="card-image__content">
            <div class="card-image__block">
                <div class="card-image__subtitle" data-aos="fade-up" data-aos-delay="100"><p style="color:#17181D;font-weight:500;">Discover Other</p>

<p style="font-weight:800;color:#aa8a5c;">Popular Currency Pairs</p></div>
                <div class="card-image__title title " data-aos="fade-up" data-aos-delay="200"></div>

                <!--                <div class="card-image__subtitle" data-aos="fade-up" data-aos-delay="100"><p style="color:#17181D;font-weight:500;">Discover Other</p>

<p style="font-weight:800;color:#aa8a5c;">Popular Currency Pairs</p></div>
                <div class="card-image__title title" data-aos="fade-up" data-aos-delay="200"></div>
                -->
                <div class="card-image__text" data-aos="fade-up" data-aos-delay="300"><p>Vertexmining Exchange offers the world’s most liquid currency pairs on two incredible trading platforms.</p></div>

                
                                <div class="combined-links">
                    <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                        
                                                <a href="register" class="combined-links__item combined-links__right">EUR/USD</a>
                        
                        
                                                <a href="register" class="combined-links__item combined-links__left">GBP/USD</a>
                                            </div>
                </div>

                                            </div>
        </div>
        <div class="card-image__image card-image__image_desktop" data-aos="fade-left" data-aos-delay="600">
            <img src="images/product-text-block__img-min.png" alt="">
        </div>

        <div class="card-image__image card-image__image_mobile" data-aos="fade-left" data-aos-delay="600">
            <img src="images/product-text-block__img-min.png" alt="">
        </div>
    </div>
</div>        
            <div id="social-links" class="social-links" >
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="../storage/app/media/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
        
                    <img class="social-links__link-img social-links__link-img_main" src="images/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="images/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

      @include('include.footer')