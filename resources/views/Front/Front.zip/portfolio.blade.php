@include('include.header')

       <main class="main">
            
            

<div id="portfolio-banner" class="simple-banner  same_width_content  "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Portfolio Management</h1></div>
                                <div class="simple-banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p>Invest your capital, not your time.</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><div style="max-width: 505px;">

	<p><strong>Do you want to invest in the financial markets, but don’t know where, or how to start? We have a solution for you.</strong></p>

	<p>Vertexmining Exchange provides a licensed portfolio management service for anyone who has the capital but lacks the time and expertise to trade for themselves.</p>

	<p>Join today and meet your dedicated portfolio manager who will build a personalised investment strategy according to your expectations and risk tolerance.&nbsp;</p>
</div></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Start Trading</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

                <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
            <img src="images/banner-portfolio.png" alt="">
        </div>
        
         
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><div style="max-width: 505px;">

	<p><strong>Do you want to invest in the financial markets, but don’t know where, or how to start? We have a solution for you.</strong></p>

	<p>Vertexmining Exchange provides a licensed portfolio management service for anyone who has the capital but lacks the time and expertise to trade for themselves.</p>

	<p>Join today and meet your dedicated portfolio manager who will build a personalised investment strategy according to your expectations and risk tolerance.&nbsp;</p>
</div></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Start Trading</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            
<div id="what-portfolio-management" class="simple-block   style1 small_padding  round_image " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/what-portfolio-min.jpg" alt="What is Portfolio Management?" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>What is <span style="font-weight:800;color:#aa8a5c;">Portfolio Management</span>?</p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>A portfolio manager oversees a portfolio of investments in various financial markets on behalf of someone else. Portfolio managers are responsible for identifying investment opportunities, tracking the portfolio’s performance, exiting investments at the right moment, and seeking new investments. The objective of a portfolio manager is to optimise the portfolio to seek opportunities in the market while limiting risk. A portfolio manager must follow all developments across all markets.</p>

<p><strong>Do you want to know more about what a portfolio manager does?&nbsp;</strong></p>

<p style="color: #aa8a5c;"><strong>Talk to one of our portfolio managers today.</strong></p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            <div id="portfolio-time-is-money" class="text-with-numbers" style="background-image: url(images/portfolio-time-is-money-min.jpg)">
    <div class="container">
        <div class="text-with-numbers__title title" data-aos="fade-up"><p>Time is money. <span style="color:#cbac63;font-weight:800;">Invest it wisely.</span></p></div>
        <div class="text-with-numbers__subtitle" data-aos="fade-up" data-aos-delay="100"><p>Here’s how Vertexmining Exchange portfolio management helps you invest time wisely.</p></div>
        <div class="text-with-numbers__text" data-aos="fade-up" data-aos-delay="200"><p>Your time is an invaluable asset. Successful trading requires investing as much time as it does capital to:</p></div>

        <ul class="text-with-numbers__list">
                <li class="text-with-numbers__list-item" data-aos="fade-left" data-aos-delay="450">
            <div class="text-with-numbers__list-number">01</div>
            <div class="text-with-numbers__list-title">Analyse the markets using technical and fundamental analysis</div>
        </li>
                <li class="text-with-numbers__list-item" data-aos="fade-left" data-aos-delay="600">
            <div class="text-with-numbers__list-number">02</div>
            <div class="text-with-numbers__list-title">Develop consistently profitable trading strategies</div>
        </li>
                <li class="text-with-numbers__list-item" data-aos="fade-left" data-aos-delay="750">
            <div class="text-with-numbers__list-number">03</div>
            <div class="text-with-numbers__list-title">Learn how to manage exposure and constantly worry about potential losses</div>
        </li>
                </ul>

        <div class="text-with-numbers__bottom-text" data-aos="fade-up" data-aos-delay="500"><p>Save yourself time and effort but still keep the opportunity of making money open by letting a personal market professional trade on your behalf and start earning time (and money).</p></div>

                <div data-aos="fade-up" data-aos-delay="600">
            <a href="register"  class="btn btn-big btn-white-red">Start Earning Time</a>
        </div>

        <div class="warning-text warning-text_light" data-aos="fade-up" data-aos-delay="600">
            <p>* Start Trading Now.</p>
        </div>
        
            </div>
</div>        
            
<div id="portfolio-overview" class="overview ">
    <div class="container">
        <div class="overview__content">
            <div class="overview__title title" data-aos="fade-up"><p>Vertexmining Exchange Licensed Portfolio Management Overview</p></div>
            <div class="overview__text" data-aos="fade-up" data-aos-delay="200"><p>We add incredible value to our clients by offering a licensed portfolio management service that allows you to delegate your everyday trading activities to professional market analysts and investment professionals.</p></div>
        </div>
        <div class="overview__list-wrap">
            <ul class="overview__list">
                                <li class="overview__list-item">
                    <div class="overview__list-block" data-aos="fade-left" data-aos-delay="450">
                        <div class="overview__list-title">Popular Service</div>
                        <div class="overview__list-text"><p>One-in-three traders that
	<br>join Vertexmining Exchange sign up for the perks of a portfolio management service.</p>
</div>
                    </div>
                </li>
                                <li class="overview__list-item">
                    <div class="overview__list-block" data-aos="fade-left" data-aos-delay="600">
                        <div class="overview__list-title">Regulated Provider</div>
                        <div class="overview__list-text"><p>Licensed by CySEC
	<br>and authorised to provide portfolio
	<br>management services.</p>
</div>
                    </div>
                </li>
                                <li class="overview__list-item">
                    <div class="overview__list-block" data-aos="fade-left" data-aos-delay="750">
                        <div class="overview__list-title">Risk Limitation</div>
                        <div class="overview__list-text"><p>You set the level of drawdown that your assigned portfolio manager should follow when managing your investments.</p>
</div>
                    </div>
                </li>
                                <li class="overview__list-item">
                    <div class="overview__list-block" data-aos="fade-left" data-aos-delay="900">
                        <div class="overview__list-title">Professional Managers</div>
                        <div class="overview__list-text"><p>Portfolio management is performed by professional traders who meet rigorous criteria.</p>
</div>
                    </div>
                </li>
                                <li class="overview__list-item">
                    <div class="overview__list-block" data-aos="fade-left" data-aos-delay="1050">
                        <div class="overview__list-title">Detailed Reporting</div>
                        <div class="overview__list-text"><p>Get regular performance meetings and statements
	<br>to assess the
	<br>performance and goals of
	<br>your portfolio.</p>
</div>
                    </div>
                </li>
                                <li class="overview__list-item">
                    <div class="overview__list-block" data-aos="fade-left" data-aos-delay="1200">
                        <div class="overview__list-title">No Lock-Ins</div>
                        <div class="overview__list-text"><p>There is no lock-in period
	<br>or penalties for
	<br>withdrawing some or all
	<br>of your invested capital.</p>
</div>
                    </div>
                </li>
                            </ul>
        </div>
    </div>
</div>        
            
<div id="why-portfolio-management" class="simple-block   style1 small_padding  empty_padding_bottom round_image " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="images/portfolio-why-min.jpg" alt="Why Sign Up For Portfolio Management?" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>Why <span style="font-weight:800;color: #aa8a5c;">Sign Up</span> For Portfolio Management?</p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>A successful trader is achieved through persistent learning, constantly analysing the markets, vigorously monitoring trades and risks and testing numerous techniques and strategies. All of which is tiresome and endless work. No matter how wealthy you become, one thing you can never buy back is your time.</p>

<p>Knowing the personal dedication required, Vertexmining Exchange has designed <strong>the most efficient investment solution</strong> that will add ‘time’ to the list of your returns on investments. Our team of licensed portfolio managers will skillfully handle all your trading activities. The objective is not merely to reduce the time you allocate to investing, but to enhance the yield of your investments.&nbsp;</p>

<p>Portfolio management services allow you to delegate the management of your financial assets to a seasoned professional and thus freeing up your valuable time while still ensuring that your capital continues to work for you.</p></div>

                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            <div id="portfolio-card" class="card-image  card-image_center">
    <div class="container">
        <div class="card-image__content">
            <div class="card-image__block">
                <div class="card-image__subtitle" data-aos="fade-up" data-aos-delay="100"><p>Time is a Priceless Asset.</p></div>
                <div class="card-image__title title title_center" data-aos="fade-up" data-aos-delay="200"><p>Don’t invest it where it’s not needed.</p></div>

                <!--                <div class="card-image__subtitle" data-aos="fade-up" data-aos-delay="100"><p>Time is a Priceless Asset.</p></div>
                <div class="card-image__title title" data-aos="fade-up" data-aos-delay="200"><p>Don’t invest it where it’s not needed.</p></div>
                -->
                <div class="card-image__text" data-aos="fade-up" data-aos-delay="300"><p>With a <strong>managed investment portfolio</strong>, your money works for you, instead of you working for money. Your capital works autonomously, allowing you to potentially enjoy <strong>returns in money as well as time</strong>.</p></div>

                                <div data-aos="fade-up" data-aos-delay="600">
                                        <a href="register" class="btn btn-orange">Start Trading</a>

                    <div class="warning-text">
                        <p>* Start Trading Now.</p>
                    </div>
                    
                                    </div>
                
                            </div>
        </div>
        <div class="card-image__image card-image__image_desktop" data-aos="fade-left" data-aos-delay="600">
            <img src="images/portfolio-card-min.png" alt="">
        </div>

        <div class="card-image__image card-image__image_mobile" data-aos="fade-left" data-aos-delay="600">
            <img src="images/card-portfolio-mobile.png" alt="">
        </div>
    </div>
</div>        
            <div id="what-dualix" class="text-center-block " style="background-image: url(images/portfolio-time-is-money-min.jpg)">
    <div class="container">
                <div class="text-center-block__title title title_center" data-aos="fade-up"><p>What <span style="font-weight:800;color:#cbac63;">Vertexmining Exchange can offer you</span></p></div>
                <div class="text-center-block__text text" data-aos="fade-up" data-aos-delay="100"><p>Our secret sauce is the professional we employ to manage our client’s investment portfolios. Each member of the Vertexmining Exchange portfolio management team is passionate about financial markets and brings something slightly different to ensure we have a diverse range of knowledge, skills and experience at our disposal.</p></div>

                <div class="text-center-block__subtitle" data-aos="fade-up" data-aos-delay="200">
            <div class="typed-strings">
                <p>18 seasoned trading veterans managing your investment</p>
            </div>
            <span class="typed"></span>
        </div>
        
                <div class="text-center-block__bottom-text" data-aos="fade-up" data-aos-delay="300"><p>Save yourself time and potential losses by letting a personal market professional trade on your behalf and start earning time (and money).</p></div>
        
                <div data-aos="fade-up" data-aos-delay="400">
                        <a href="register" class="btn btn-white-bright-red">Talk to an Professional Today</a>

            <div class="warning-text warning-text_light">
                <div data-aos="fade-up" data-aos-delay="600">

	<p>* Start Trading Now.</p>
</div>
            </div>
            
                    </div>
        
            </div>
</div>        
            
<div id="portfolio-tariffs" class="tariffs style8  "
     style="     ">

    <div class="container">
                <div class="tariffs__title title title_center" data-aos="fade-up"><p>Select Your <span style="font-weight:800;color:#aa8a5c;">Trading Accounts</span></p></div>
                                <div class="tariffs__text" data-aos="fade-up" data-aos-delay="100"><div style="max-width: 832px;margin-left:auto;margin-right:auto;">

	<p>
		<br>
	</p>

	<p><strong>Four ways to trade with Vertexmining Exchange.</strong>
		<br>As a leading investment broker, Vertexmining Exchange has developed competitive solutions to help clients trade and invest in the financial markets. You can choose how much you’re willing to allocate to
		<br><span style="font-weight:800;color:#aa8a5c;">your investment strategy.</span></p>
</div></div>
        
        
        
                <div class="tariffs__list">
                                    <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#C06C33;">BRONZE</strong></p>
</div>
                <div class="tariffs__item-content ">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariff__bronze.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Account opening balance from €1,000</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Self-trading account</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Access to world-famous trading platforms</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Micro lot trading</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">1.4 Pip average floating spread</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">STP & DMA order execution</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">50% Stop Out</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Multiple asset class coverage</div>
                                                    </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#D8B177;">GOLD</strong></p>
</div>
                <div class="tariffs__item-content ">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariff__gold.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Account opening balance from €10,000</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Dedicated Personal Trader</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">1.2 Pip average floating spread</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">STP & DMA order execution</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">50% Stop Out</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Multiple asset class coverage</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Phone, email & instant message your personal trader</div>
                                                    </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong style="color:#979797;">PREMIUM</strong></p>
</div>
                <div class="tariffs__item-content style1">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariffs-premium.png)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Account opening balance from €50,000</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Dedicated Personal Trader</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">1.2 Pip average floating spread</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">STP & DMA order execution</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">50% Stop Out</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Multiple asset class coverage</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Phone, email & instant message your personal trader</div>
                                                    </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
            
            
                        <div class="tariffs__item" data-aos="fade-up" data-aos-delay="100">
                <div class="tariffs__item-title"><p>Vertexmining Exchange <strong>SILVER</strong></p>
</div>
                <div class="tariffs__item-content ">
                    <div class="tariffs__item-bg" style="background-image: url(images/tariff__silver.jpg)"></div>
                                        <ul>
                                                <li>
                            <div class="tariffs__item-content-title">Account opening balance from €2,500</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Portfolio management service</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">14-days concierge trading trial</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">1.4 Pip average floating spread</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">STP & DMA order execution</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">50% Stop Out</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Multiple asset class coverage</div>
                                                    </li>
                                                <li>
                            <div class="tariffs__item-content-title">Phone, email & instant message your portfolio manager</div>
                                                    </li>
                                            </ul>
                </div>

                                <a href="register" class="tariffs__item-link">Get Started</a>
                
                            </div>

            
              
            
                    </div>
        
        
        
        <div class="tariffs__bottom-text" data-aos="fade-up" data-aos-delay="200"><p>* Start Trading Now.</p></div>
    </div>
</div>        
            <div id="portfolio-how-started" class="arrows   " style="background-image: url(images/portfolio-arrows-bg-min.jpg)">
    <div class="container">
        <div class="arrows__title title title_center" data-aos="fade-up"><p><span style="font-weight:800;color:#aa8a5c;">How to get started</span> with a managed investment portfolio?</p></div>

        <ul class="arrows__list">
                    <li class="arrows__item" data-aos="fade-left" data-aos-delay="450" style="z-index: 3">
                <div class="arrows__item-block">
                                        <div class="arrows__item-title"><p>Tell us
	<br>about your objectives.</p>
</div>
                                        <div class="arrows__item-text"><p>We know you want to make money, who doesn’t? We want to know how much risk you’re willing to tolerate, and we’ll design a strategy to make as much profit as possible with the capital you deposit and within your risk parameters.</p>
</div>
                                    </div>
            </li>
                    <li class="arrows__item" data-aos="fade-left" data-aos-delay="600" style="z-index: 2">
                <div class="arrows__item-block">
                                        <div class="arrows__item-title"><p>Get a proposal and share your ideas.</p>
</div>
                                        <div class="arrows__item-text"><p>Your personal portfolio manager will pitch recommendations and hear your thoughts. If there are some specific instruments you want to be included in your portfolio, we’ll do our best to incorporate them and balance risk accordingly.</p>
</div>
                                    </div>
            </li>
                    <li class="arrows__item" data-aos="fade-left" data-aos-delay="750" style="z-index: 1">
                <div class="arrows__item-block">
                                        <div class="arrows__item-title"><p>Get started with just €2,500.</p>
</div>
                                        <div class="arrows__item-text"><p>Once your portfolio has been designed, the final step is to fund your account with just €2,500 and our investment experts will take care of the rest. Now you can get on with your life and wait for regular statements and meetings from your portfolio manager.</p>
</div>
                                    </div>
            </li>
                </ul>

        
            </div>
</div>        
            
<div id="portfolio-how-can-define-the-risk" class="simple-block   style2  wide_content " >
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                                    <div class="simple-block__image stick" data-sticky-class="sticking">
                <div data-aos="fade-right">
                                        <img src="images/portfolio-businessman-talking-phone-min.jpg" alt="How you can define the risk&amp;nbsp;of your investments.">
                </div>
            </div>
            
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>How you can <span style="font-weight:800;color:#aa8a5c;">define the risk&nbsp;</span>of your investments.</p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>Risk is an unavoidable feature of investing. Without risk, there is no reward. When you sign up with Vertexmining Exchange, your financial profile and knowledge will be assessed by experienced professionals to define your risk appetite. Later, you’ll be able to discuss your investment objectives with a licensed portfolio manager so they can tailor an investment strategy around you. When an investment is rated as low risk in the world of finance, it generally means a lower reward will be produced. In contrast, an investment classified as high risk is typically associated with being able to achieve higher reward. However, if the risk is too high, it can mean no reward at all and can ultimately result in loss of some or all of the initial capital. It is essential to define investment objectives when onboarding with your portfolio manager accurately.</p>

<p>Risk can be defined as either low, medium, high and very high. Here are some textbook examples of different types of investment portfolios.</p></div>

                                <ul class="simple-block__list">
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="450">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">Low-risk portfolios are very conservative in nature and tuned for fighting inflation.</span></p>
</div>
                                                <div class="simple-block__list-text"><p>A low-risk strategy will allocate the majority of capital to less risky assets like fixed-income products and real estate. Only a few per cent will be allocated to large-cap US stocks. Low-risk portfolios are therefore expected to experience little less volatility (fluctuation of value).</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="600">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">Medium-risk portfolios are optimised for risk-averse growth.</span></p>
</div>
                                                <div class="simple-block__list-text"><p>A medium-risk strategy will allocate half of the capital towards low-risk investments, like fixed income products and the rest towards US large-cap and small-cap stocks and a small per cent towards stocks from emerging markets. Medium-risk portfolios are expected to experience lower volatility (fluctuation of value) than stock markets as they are balanced with less risky products.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="750">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">High-risk portfolios are expected to achieve attractive long-term growth and tolerate short-term volatility.</span></p>
</div>
                                                <div class="simple-block__list-text"><p>A high-risk strategy will allocate more capital towards assets that potentially have very lucrative upsides, such as forex, emerging market stocks and small-cap stocks from developed markets. The risk of a high-risk investment portfolio is generally aligned with that of the stock market since most of the portfolio’s capital is allocated in various stock markets.</p>
</div>
                        
                                            </li>
                                        <li class="simple-block__list-item style3" data-aos="fade-left" data-aos-delay="900">
                        <div class="simple-block__list-caption"><p><span style="color: rgb(110, 35, 10);">Very high-risk portfolios are very aggressive and often are riskier than the stock market.</span></p>
</div>
                                                <div class="simple-block__list-text"><p>A very high-risk strategy will allocate nearly all capital towards forex, alternative investment products and stocks from almost any market. Very little will be allocated to low-risk investments, therefore making the portfolio very unbalanced and susceptible to market volatility. The risk level of a very high-risk investment portfolio is considered to be greater than that of the stock market<s>,</s> because of various alternative and volatile investments.</p>
</div>
                        
                                            </li>
                                    </ul>
                
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="portfolio-start-building" class="text-center-block-lite   "
     style="     ">
    <div class="container">
        <div class="text-center-block-lite__title title title_center" data-aos="fade-up"><p><span style="font-weight:800;color:#aa8a5c;">Start Building a Portfolio</span> that Works for You.</p></div>
        
        <div class="text-center-block-lite__text text" data-aos="fade-up" data-aos-delay="200"><p>All you need to get started with your very own managed investment portfolio is complete a short registration form, and one of our investment professionals will be in touch to discuss your application.</p></div>

        
                <div data-aos="fade-up" data-aos-delay="400">
            <a href="register"  class="btn btn-middle btn-orange">Start Trading</a>
        </div>

        <div class="warning-text" data-aos="fade-up" data-aos-delay="400">
            <p>* Start Trading Now.</p>
        </div>
        
        
            </div>
</div>        
            <div id="porfolio-social-links" class="social-links" >
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="images/social/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="images/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="images/social/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="images/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

      @include('include.footer')