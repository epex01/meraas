@include('include.header')

<main class="main">
            
            

<div id="economic-calendar" class="simple-banner style2  center_content "
style=""
>

    <div class="container">
                <div class="simple-banner__content">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__title" data-aos="fade-up"><h1>Economic Calendar</h1></div>
                                <div class="simple-banner__subtitle" data-aos="fade-up" data-aos-delay="200"><p>Stay up to date with the events that
	<br>shake the markets.</p></div>
                
                <div class="simple-banner__desktop">
                    <div class="simple-banner__text text" data-aos="fade-up" data-aos-delay="400"><p>The economic calendar can play a crucial role in helping you to decide when to trade and when not to trade, depending on the type of trading strategy you use. Some events like the Nonfarm Payroll are renowned for triggering a jump in volatility and often spark a breakout or a trend reversal. Besides the routine economic events that are routinely scheduled, you can’t afford to miss any spontaneous announcements. Follow this economic calendar to make sure you’re among the first to know about any major political announcements, new central bank policies or interest rate changes. This information can help you know when to<span lang="en-US"> </span>reduce your exposure, increase margin, adjust pending orders, and prepare for the next opportunity.</p></div>

                    
                    
                                        <div class="simple-banner__link ">
                        <div class="combined-links">
                            <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                                <a href="register" class="combined-links__item combined-links__right">Try On Demo</a>
                                
                                
                                                                <a href="register" class="combined-links__item combined-links__left">Start trading</a>
                                
                                                            </div>
                        </div>
                    </div>

                                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                        <p>* Start Trading Now.</p>
                    </div>
                                        
                                    </div>
            </div>
        </div>

        
                     <div class="simple-banner__image" data-aos="fade-left" data-aos-delay="200">
                <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/markets/currencies/economic-calendar/" rel="noopener" target="_blank"><span class="blue-text">Economic Calendar</span></a> by TradingView</div>
  <script type="text/javascript" src="../s3.tradingview.com/external-embedding/embed-widget-events.js" async>
  {
  "colorTheme": "light",
  "isTransparent": false,
  "width": "100%",
  "height": "500",
  "locale": "en",
  "importanceFilter": "-1,0,1"
}
  </script>
</div>
<!-- TradingView Widget END -->
            </div>
        
        
        
                
        <div class="simple-banner__content simple-banner__mobile">
            <div class="simple-banner__content-wrap">
                <div class="simple-banner__text" data-aos="fade-up" data-aos-delay="400"><p>The economic calendar can play a crucial role in helping you to decide when to trade and when not to trade, depending on the type of trading strategy you use. Some events like the Nonfarm Payroll are renowned for triggering a jump in volatility and often spark a breakout or a trend reversal. Besides the routine economic events that are routinely scheduled, you can’t afford to miss any spontaneous announcements. Follow this economic calendar to make sure you’re among the first to know about any major political announcements, new central bank policies or interest rate changes. This information can help you know when to<span lang="en-US"> </span>reduce your exposure, increase margin, adjust pending orders, and prepare for the next opportunity.</p></div>

                            <!---->
                                <div class="simple-banner__combined-links">
                    <div class="combined-links">
                        <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                        <a href="register" class="combined-links__item combined-links__right">Try On Demo</a>
                            
                            
                                                        <a href="register" class="combined-links__item combined-links__left">Start trading</a>
                            
                                                    </div>
                    </div>
                </div>

                                <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                    <p>* Start Trading Now.</p>
                </div>
                                
                            </div>
        </div>

    </div>

</div>        
            <div id="key-economic-events-to-look-out-for" class="events" style="background: #ffffff;">
    <div class="container">
        <div class="events__title title title_center" data-aos="fade-up"><p>Key Economic Events <span style="font-weight:800;color:#aa8a5c;">To Look Out For</span></p></div>
        <div class="events__text" data-aos="fade-up" data-aos-delay="100"><p>Economic calendars flag the events which are likely to have the biggest impact for certain currency pairs and financial markets. Here are the economic events
	<br><strong>you want to keep your eyes peeled for</strong>.</p></div>
        <div class="events__list">
                        <div class="events__item" data-aos="fade-up" data-aos-delay="100">
                <div class="events__item-image"><img src="images/calendar1.svg" /></div>
                <div class="events__item-title"><p>Labour market statistics</p>
</div>
                <div class="events__item-content"><p>Any changes to employment and unemployment rates within a country or key industry can signal changes in an economy’s strength. The job market statistic which is notorious for shaking major currency pairs is the Nonfarm Payroll, published on the first Friday of every month by the United States Bureau of Labor Statistics.</p>
</div>
            </div>

                                    <div class="events__item" data-aos="fade-up" data-aos-delay="100">
                <div class="events__item-image"><img src="images/calendar2.svg" /></div>
                <div class="events__item-title"><p>Retail sales data</p>
</div>
                <div class="events__item-content"><p>Retail sales figures analyse how consumers spend money and then compare it to previous periods. Consumer spending contributes to the overall GDP of a country. If retail sales increase, it indicates stronger economic growth, whereas it shows the opposite if it falls.</p>
</div>
            </div>

                                    <div class="events__item" data-aos="fade-up" data-aos-delay="100">
                <div class="events__item-image"><img src="images/calendar3.svg" /></div>
                <div class="events__item-title"><p>Gross Domestic Product (GDP)</p>
</div>
                <div class="events__item-content"><p>GDP is an economic indicator that has been used for close to a century to gauge the overall health of a country’s economy. GDP looks at how much a country is spending domestically by calculating the sum of consumption, investment, government spending and net exports. When surprising GDP figures are announced, they can quickly influence the demand for a currency for better or for worse.</p>
</div>
            </div>

                            <!--
                </div>
                <div class="events__list">
                -->
                                    <div class="events__item" data-aos="fade-up" data-aos-delay="100">
                <div class="events__item-image"><img src="images/calendar4.svg" /></div>
                <div class="events__item-title"><p>Price Indices</p>
</div>
                <div class="events__item-content"><p>Analysts track the inflation of a currency through the consumer price index (CPI) and producer price index (PPI). The CPI tracks the cost of several predefined consumer goods such as food, medical care and energy. As prices for consumer goods increase, it indicates inflation. The PPI looks at raw materials used by manufacturers to produce finished goods for consumers. If raw materials increase in cost, it’s expected, consumer prices will follow.</p>
</div>
            </div>

                                    <div class="events__item" data-aos="fade-up" data-aos-delay="100">
                <div class="events__item-image"><img src="images/calendar5.svg" /></div>
                <div class="events__item-title"><p>Central Bank Policy</p>
</div>
                <div class="events__item-content"><p>Interest rates and central bank monetary policy can profoundly affect the value of a currency. Interest rates going up or down can be positive or negative depending on the context. Low-interest rates are typically used to stimulate an economy with better conditions to borrow money and fewer incentives to save money. Reducing interest rates are a not so secret weapon used by central banks to stimulate the economy and are therefore associated with a weak economy.</p>
</div>
            </div>

                                    <div class="events__item" data-aos="fade-up" data-aos-delay="100">
                <div class="events__item-image"><img src="images/calendar6.svg" /></div>
                <div class="events__item-title"><p>Trade balance</p>
</div>
                <div class="events__item-content"><p>The trade balance is the difference between imports and exports of a country. When imports are high, it signifies a strong demand for domestic goods. High exports show an interest in goods produced overseas. When the imports and exports are netted off, and exports exceed imports, it shows the country is exporting many products and is therefore competitive on the market. If a country is importing more than it exports, it can be seen as a sign of prosperity but also of a lack of competitiveness on the market.</p>
</div>
            </div>

                                </div>
            </div>
</div>            </main>

     @include('include.footer')