@include('include.header')

<main class="main">
            
            <div id="banner" class="simple-block-top" >
    <div class="container">
        <div class="simple-block-top__content">
                        <div class="simple-block-top__title title" data-aos="fade-left"><h1>Margin Requirements <span style="font-weight:800;color:#aa8a5c;">with Vertexmining Exchange</span></h1></div>
            
                        <div class="simple-block-top__subtitle" data-aos="fade-left"><p>Understand Leverage &amp; Margin Requirements when trading with Vertexmining Exchange</p></div>
            
            <div class="simple-block-top__text text" data-aos="fade-left" data-aos-delay="100"><p>One of the most distinctive characteristics of trading forex and CFDs is applying leverage to get exposure to financial products across numerous asset classes. However, the greater exposure you have to the market, the greater your risks are. Therefore, leverage should be used responsibly and only by those who understand the principles of leveraging positions and the associated risks involved.</p>

<p>
	<br>
</p></div>

            
                        <div class="simple-block-top__combined-links">
                <div class="combined-links">
                    <div class="combined-links__wrap" data-aos="fade-up" data-aos-delay="600">
                                                <a href="register" class="combined-links__item combined-links__right">Try on Demo</a>
                        
                        
                                                <a href="register" class="combined-links__item combined-links__left">Open a Trading Account</a>
                        
                                            </div>
                </div>
            </div>

                        <div class="warning-text" data-aos="fade-up" data-aos-delay="600">
                <div data-aos="fade-up" data-aos-delay="300">

	<p>* Start Trading Now.</p>
</div>
            </div>
                        
            
        </div>

        <div class="simple-block-top__media">
            <div class="simple-block-top__image">
                <div data-aos="fade-right">
                    <img src="images/intro-banner-min.png" alt="Margin Requirements with Vertexmining Exchange">
                </div>
            </div>
        </div>
    </div>
</div>        
            <div id="how-does-leverage-work" class="leverage" >
    <div class="leverage__top" style="background-image: url(images/analyse-intoduction-min.jpg)">
        <div class="container">
            <div class="leverage__title title title_center" data-aos="fade-up"><p>How Does <span style="font-weight:800;color:#cbac63;">Leverage Work?</span></p></div>
            <div class="leverage__subtitle" data-aos="fade-up" data-aos-delay="100"><p>The funds you deposit to your trading account is considered your margin. Leverage is a mechanism which allows you to open positions far greater than your initial margin.</p></div>
            <div class="leverage__text" data-aos="fade-up" data-aos-delay="200"><p>For example, if you deposit 10,000 euros to a trading account, and have a maximum leverage of 1:30, your buying power can be potentially as much as €300,000. However, you absolutely should not allocate the entire value of your account to one trade. The higher your exposure is to the market; a small price movement will significantly impact profits or losses.</p>

<p>
	<br>
</p>

<p>If for example, you open a long position for 10,000 EUR/USD, €333.33 of your margin will be used, leaving you with €9,666.67 free margin which may be used for other trades or maintained as part of a healthy risk management strategy.&nbsp;</p></div>
        </div>
    </div>

    <div class="leverage__bottom">
        <div class="container">
            <div class="leverage__list">
                                <div class="leverage__list-item">
                    <div class="leverage__list-block" data-aos="fade-up" data-aos-delay="450">
                        <div class="leverage__list-top">
                                                        <a href="register" class="btn btn-orange">BUY 10,000 EUR/USD</a>
                            
                            
                                                    </div>

                                                    <ul class="leverage__interactive">
                                <li class="leverage__interactive-item">
                                    <span>Account Balance</span>
                                    <span class="leverage__interactive-value">10,000 EUR</span>
                                </li>
                                <li class="leverage__interactive-item">
                                    <span></span>
                                    <span class="leverage__interactive-value">Leverage = 1:30</span>
                                </li>
                                <li class="leverage__interactive-item">
                                    <span>User Margin</span>
                                    <span class="leverage__interactive-value">500 EUR</span>
                                </li>
                                <li class="leverage__interactive-item">
                                    <span>Free Margin</span>
                                    <span class="leverage__interactive-value">9,500 EUR</span>
                                </li>
                                <li class="leverage__interactive-item">
                                    <span>Equity</span>
                                    <span class="leverage__interactive-value">10,000 EUR</span>
                                </li>
                                <li class="leverage__interactive-item">
                                    <span>Margin Level</span>
                                    <span class="leverage__interactive-value">2000 %</span>
                                </li>
                            </ul>
                        
                                            </div>
                    <div class="leverage__list-bottom-text text" data-aos="fade-up" data-aos-delay="450">
                        <p>Used Margin is the amount of margin used to maintain the open CFD position; it’s a static number. However, Free Margin is a dynamic number which adjusts according to unrealised profit and loss. Should the price fall by 300 Pips, the position experience drawdown of $300 (€245.6), which is an unrealised loss, then Free Margin will fall to €9,254.4, supposing the EUR/USD exchange rate 1.22150.</p>

                    </div>
                </div>
                                <div class="leverage__list-item">
                    <div class="leverage__list-block" data-aos="fade-up" data-aos-delay="600">
                        <div class="leverage__list-top">
                                                        <a href="register" class="btn btn-orange">BUY 10,000 EUR/USD</a>
                            
                            
                                                        <div class="leverage__interactive-once">EUR/USD = 1.22150</div>
                                                    </div>

                        
                                                <ul class="leverage__interactive">
                            <li class="leverage__interactive-item">
                                <span>Account Balance</span>
                                <span class="leverage__interactive-value">10,000 EUR</span>
                            </li>
                            <li class="leverage__interactive-item">
                                <span></span>
                                <span class="leverage__interactive-value">Leverage = 1:30</span>
                            </li>
                            <li class="leverage__interactive-item">
                                <span>User Margin</span>
                                <span class="leverage__interactive-value">9,500 EUR</span>
                            </li>
                            <li class="leverage__interactive-item">
                                <span>Free Margin</span>
                                <span class="leverage__interactive-value">9,254.4 EUR</span>
                            </li>
                            <li class="leverage__interactive-item">
                                <span>Equity</span>
                                <span class="leverage__interactive-value">9,754.4 EUR</span>
                            </li>
                            <li class="leverage__interactive-item">
                                <span>Margin Level</span>
                                <span class="leverage__interactive-value">102.68 %</span>
                            </li>
                        </ul>
                                            </div>
                    <div class="leverage__list-bottom-text text" data-aos="fade-up" data-aos-delay="600">
                        

                    </div>
                </div>
                            </div>
        </div>
    </div>
</div>        
            
<div id="ESMA-product-intervention-measures" class="simple-block left theme1 style1 small_padding  empty_padding_top round_image " style="background: #ffffff;">
        <div class="container">
        <div class="simple-block__media" data-sticky-container>
                            
                <div class="simple-block__image">
                    <img src="../storage/app/media/margin/esma-margin-min.jpg" alt="ESMA Product
	Intervention Measures" data-aos="fade-right">
                </div>
                        
                    </div>

        <div class="simple-block__content">
            <div>
                                <div class="simple-block__title title " data-aos="fade-left"><p>ESMA Product
	<br><span style="font-weight:800;color:#aa8a5c;">Intervention Measures</span></p></div>
                                
                <div class="simple-block__text text" data-aos="fade-left" data-aos-delay="100"><p>As a European investment firm regulated by the Cyprus Securities and Exchange Commission (CySEC), Vertexmining Exchange follows MiFID II and the rules established by the European Securities and Markets Authority (ESMA), as well as CySEC. Since 1st of August 2018, ESMA has required all EU licensed CFD providers to follow strict conditions concerning how much leverage may be offered to non-professional clients.</p></div>

                
                                <table class="simple-block__table">
                                        <tr>
                                                <th>
                            FINANCIAL INSTRUMENTS
                        </th>
                        <th>
                            MAX LEVERAGE
                        </th>
                                            </tr>
                                        <tr>
                                                <td>
                            Major forex pairs, such as USD/JPY, EUR/USD, GBP/USD
                        </td>
                        <td>
                             1:30
                        </td>
                                            </tr>
                                        <tr>
                                                <td>
                            Minor forex pairs, such as USD/MXN, EUR/CZK, GBP/SGD
                        </td>
                        <td>
                             1:20
                        </td>
                                            </tr>
                                        <tr>
                                                <td>
                            Spot gold
                        </td>
                        <td>
                             1:20
                        </td>
                                            </tr>
                                        <tr>
                                                <td>
                            Major indices, such as the US30, DAX30, FTSE100
                        </td>
                        <td>
                             1:20
                        </td>
                                            </tr>
                                        <tr>
                                                <td>
                            Spot silver
                        </td>
                        <td>
                             1:10
                        </td>
                                            </tr>
                                        <tr>
                                                <td>
                            Futures (hard & soft commodities), such as Copper vs USD or Wheat vs USD
                        </td>
                        <td>
                             1:10
                        </td>
                                            </tr>
                                        <tr>
                                                <td>
                            Energy products, such as Brent vs USD
                        </td>
                        <td>
                             1:10
                        </td>
                                            </tr>
                                        <tr>
                                                <td>
                            Minor indices, such as ASX, HSI
                        </td>
                        <td>
                             1:10
                        </td>
                                            </tr>
                                        <tr>
                                                <td>
                            Shares of US, UK, French & German listed companies
                        </td>
                        <td>
                             1:5
                        </td>
                                            </tr>
                                        <tr>
                                                <td>
                            Digital assets, such as BTC/USD, ETH/USD
                        </td>
                        <td>
                             1:2
                        </td>
                                            </tr>
                                    </table>
                
                
                                
                
                
            </div>
        </div>
    </div>
</div>        
            
<div id="open-account" class="true-power medium_padding" style="background-image: url(images/true-power-min.jpg)">
    <div class="container">
                        <div class="true-power__subtitle" data-aos="fade-up"><p><span style="font-weight:800;">Open a CFD trading</span>
	<br>account today</p></div>
                
        
                <div class="combined-links">
            <div class="true-power__links combined-links__wrap" data-aos="fade-up" data-aos-delay="300">
                                <a href="register" class="combined-links__item combined-links__right"><span>Open Demo Account</span></a>
                
                
                                <a href="register" class="combined-links__item combined-links__left"><span>Open Live Account</span></a>
                
                            </div>
        </div>

                <div class="warning-text warning-text_light warning-text_center" data-aos="fade-up" data-aos-delay="300">
            <p>* Start Trading Now.</p>
        </div>
                    </div>
</div>        
            <div id="social-links" class="social-links" style="background: #ffffff;">
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="images/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="images/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="../storage/app/media/social/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>            </main>

@include('include.footer')