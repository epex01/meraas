<div id="social-links" class="social-links">
    <div class="container">
        <div class="social-links__list">
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="350">
                <a href="https://www.facebook.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="images/facebook.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="images/facebook_hover.svg" alt="">
                </a>
            </div>
                        <div class="social-links__item" data-aos="fade-up" data-aos-delay="500">
                <a href="https://www.instagram.com/frasermaverick00@gmail.com" class="social-links__link">
                    <img class="social-links__link-img social-links__link-img_main" src="images/instagram.svg" alt="">
                    <img class="social-links__link-img social-links__link-img_hover" src="images/instagram_hover.svg" alt="">
                </a>
            </div>
                    </div>
    </div>
</div>    
<script>
  $('.lazy').lazy({
        scrollDirection: 'vertical',
        effect: 'fadeIn',
        visibleOnly: true,
	  beforeLoad: function(element){
		  console.log('image is about to be loaded');
	  },
	  afterLoad: function(element) {
		  console.log('image was loaded successfully');
	  },
	  onError: function(element) {
		  console.log('image could not be loaded');
	  },
	  onFinishedAll: function() {
		  console.log('finished loading elements');
		  console.log('lazy instance is about to be destroyed')
	  }
  });
</script>        </main>

        <footer class="footer">
    <div class="footer__top">
        <div class="container">
            <div class="footer__content">
                                <div class="footer__logo">
                    <img src="images/logo_blue.svg" alt="vertex mining exchange">
                </div>
                                <div class="footer__text">
                    <p><span style="font-size: 18px;">Gain Power In Your Own Way</span></p>

<p><strong>Trade. Trust. Invest.</strong></p>
                </div>
            </div>
            <div class="footer__menu-section">
                <ul class="footer-menu">
                                        <li class="footer-menu__item dropdown ">
                                        <div class="footer-menu__title dropdown-toggle" data-toggle="dropdown">
                        Products <span class="caret"></span>
                    </div>
                                                            <ul class="footer-menu__list">
                                                                        <li class="footer-menu__list-item ">
                                                                <a href="stocks" target="_self" class="footer-menu__list-link">
                                    Stocks Trading
                                </a>
                                                                                            </li>
                                                                                                <li class="footer-menu__list-item ">
                                                                <a href="portfolio" target="_self" class="footer-menu__list-link">
                                    Portfolio Management
                                </a>
                                                                                            </li>
                                                                                              
                                                            </ul>
                            </li>
                                                <li class="footer-menu__item dropdown ">
                                        <div class="footer-menu__title dropdown-toggle" data-toggle="dropdown">
                        Range of Markets <span class="caret"></span>
                    </div>
                                                            <ul class="footer-menu__list">
                                                                        <li class="footer-menu__list-item ">
                                                                <a href="m_metals" target="_self" class="footer-menu__list-link">
                                    Precious Metals
                                </a>
                                                                                            </li>
                                                                                                <li class="footer-menu__list-item ">
                                                                <a href="m_indices" target="_self" class="footer-menu__list-link">
                                    Indices
                                </a>
                                                                                            </li>
                                                                                                <li class="footer-menu__list-item ">
                                                                <a href="m_digital" target="_self" class="footer-menu__list-link">
                                    Digital Currencies
                                </a>
                                                                                            </li>
                                                            </ul>
                            </li>
                                                <li class="footer-menu__item dropdown ">
                                        <div class="footer-menu__title dropdown-toggle" data-toggle="dropdown">
                        Popular Markets <span class="caret"></span>
                    </div>
                                                            <ul class="footer-menu__list">
                                                                        <li class="footer-menu__list-item ">
                                                                <a href="p_eur" target="_self" class="footer-menu__list-link">
                                    EUR/USD
                                </a>
                                                                                            </li>
                                                                                                <li class="footer-menu__list-item ">
                                                                <a href="p_usd" target="_self" class="footer-menu__list-link">
                                    GBP/USD
                                </a>
                                                                                            </li>
                                                                                                <li class="footer-menu__list-item ">
                                                                <a href="p_gold" target="_self" class="footer-menu__list-link">
                                    Gold
                                </a>
                                                                                            </li>
                                                            </ul>
                            </li>
                                                <li class="footer-menu__item dropdown ">
                                        <div class="footer-menu__title dropdown-toggle" data-toggle="dropdown">
                        Trading <span class="caret"></span>
                    </div>
                                                            <ul class="footer-menu__list">
                                                                        <li class="footer-menu__list-item ">
                                                                <a href="e_introduce" target="_self" class="footer-menu__list-link">
                                    How to Start Trading
                                </a>
                                                                                            </li>
                                                                                                <li class="footer-menu__list-item ">
                                                                <a href="t_leverage" target="_self" class="footer-menu__list-link">
                                    Leverage & Margin
                                </a>
                                                                                            </li>
                                                                                                <li class="footer-menu__list-item ">
                                                                <a href="e_glossary" target="_self" class="footer-menu__list-link">
                                    Glossary
                                </a>
                                                                                            </li>
                                                                                                <li class="footer-menu__list-item ">
                                                                <a href="tradesec" target="_self" class="footer-menu__list-link">
                                    Practical Traders
                                </a>
                                                                                            </li>
                                                            </ul>
                            </li>
                                                <li class="footer-menu__item dropdown ">
                                        <div class="footer-menu__title dropdown-toggle" data-toggle="dropdown">
                        vertex mining exchange <span class="caret"></span>
                    </div>
                                                            <ul class="footer-menu__list">
                                                                        <!--<li class="footer-menu__list-item ">
                                                                <a href="/en/legal" target="_self" class="footer-menu__list-link">
                                    Legal
                                </a>
                                                                                            </li>-->
                                                                                                                                            <li class="footer-menu__list-item ">
                                                                <a href="contact" target="_self" class="footer-menu__list-link">
                                    Contact Us
                                </a>
                                                                                            </li>
                                                                                                <li class="footer-menu__list-item ">
                                                                <a href="faq" target="_self" class="footer-menu__list-link">
                                    FAQ
                                </a>
                                                                                            </li>
                                                                                                <li class="footer-menu__list-item ">
                                                                <a href="tradesec" target="_self" class="footer-menu__list-link">
                                    Imprint
                                </a>
                                                                                            </li>
                                                            </ul>
                            </li>
            </ul>
            </div>
        </div>
    </div>

    <div class="disclaimer">
        <div class="container">
            <div><!--<p>Risk Warning: Trading is Very Speculative and Risky.</p>

<p>We highly recommend that you do not invest more money than you can afford to lose to avoid significant financial problems in the case of losses. Past performance is not an indication or guarantee of future results. Please read our Risk Disclosure Statement.</p>-->



<p>vertex mining exchange is owned and operated by vertex mining exchange. vertex mining exchange Limited is a Cyprus Investment Firm, authorized and regulated by Cyprus Securities and Exchange Commission (CySEC).</p>

<p>Registered Address: 254 Archiepiskopou Leontiou A, MAXIMOS COURT A, Floor 5, Office, 3020 Limassol, Cyprus.</p>

<p>Mail: <a href="mailto:"></a></p>

<p>© <script>document.write(new Date().getFullYear())</script> vertex mining exchange</p></div>

                        <div class="disclaimer__fixed">
                <div><!--<p><strong>Risk Disclaimer:</strong> CFDs are complex instruments and come with a high risk of losing money rapidly due to leverage. 77% of retail investor accounts lose money when trading CFDs with this provider. You should consider whether you understand how CFDs work and whether you can afford to take the high risk of losing your money.</p>--></div>
            </div>
                    </div>

    </div></footer>        
<script>/*console.log();*/</script>

        
        <!-- Scripts -->
        <script src="{{ asset('assets/css/d677ce81642cc858753e712a8bec83a6-1626790769.txt') }} "></script>
        <script src="{{ asset('assets/js/framework.combined-min.js') }} "></script>
<link rel="stylesheet" property="stylesheet" href="{{ asset('assets/css/framework.extras-min.css')}}">
        <script src="{{ asset('assets/js/snowfall.js')}} "></script>
                                    
                                                                                                
        
    <script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.eu01.nr-data.net","licenseKey":"NRJS-f25a8f51b8a0a10e239","applicationID":"226556643","transactionName":"MhBSZQoZDxUHWhUIVgtacVIMEQ4ISXoMEmUmGVFCCx0SOiVUEiJWCwFCXhQUBBQmSxQP","queueTime":0,"applicationTime":942,"atts":"HldRE0IDHBs=","errorBeacon":"bam.eu01.nr-data.net","agent":""}</script>
    
    <!--Start of Tawk.to Script-
<script type="text/javascript">//
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();//
(function(){//
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];//
s1.async=true;//
s1.src='https://embed.tawk.to/674730f64304e3196ae9623c/1idn1ehcv';//
s1.charset='UTF-8';//
s1.setAttribute('crossorigin','*');//
s0.parentNode.insertBefore(s1,s0);//
})();//
</script>//
<!--End of Tawk.to Script-->

<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '6ecd36b89e82fe5af04630302925ea1ebc97d9be';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>
<noscript> Powered by <a href=“https://www.smartsupp.com” target=“_blank”>Smartsupp</a></noscript>


       </body>
    </html>