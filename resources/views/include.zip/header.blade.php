<html>
    <head>
        <script type="text/javascript">
    (function () {
        var options = {
          //  whatsapp: "‪+1 (213) 492‑6429‬", // WhatsApp number
          //	instagram: "frasermaverick00@gmail.com",
            call_to_action: "Message us", // Call to action
            button_color: "#129BF4", // Color of button
            position: "left", // Position may be 'right' or 'left'
            pre_filled_message: "Hello vertex mining exchange", // WhatsApp pre-filled message
        };
        var proto = 'https:', host = "getbutton.io", url = proto + '//static.' + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
        
        

 

        <meta charset="utf-8">
        
<title>Trading and investing at vertex mining exchange | The investment center | vertex mining exchange - A Regulated Broker</title><meta name="description" content="vertex mining exchange is a place that leads forex traders and investors to success. We offer forex and multi-asset CFD trading, licensed portfolio management, concierge forex traders and mentoring"><meta name="keywords" content="vertex mining exchange, Maxigird, CySEC, MiFID"><link rel="canonical" href="index"><meta name="robots" content="index,follow">

<meta property="og:title" content="Trading and investing at vertex mining exchange | The investment center"><meta property="og:url" content="./"><meta property="og:site_name" content="vertex mining exchange"><meta property="og:description" content="vertex mining exchange is a place that leads forex traders and investors to success. We offer forex and multi-asset CFD trading, licensed portfolio management, concierge forex traders and mentoring"><meta property="fb:app_id" content="2894901207224376">

<link rel="icon" type="image/png" href="images/favicon.svg">
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.svg">


<meta property="og:image" itemprop="image" content="./storage/app/media/Logos/ogImage.jpg">
<meta property="og:image:type" content="image/jpeg">

        <meta name="title" content="Trading and investing at vertex mining exchange | The investment center">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

	    <link rel="preconnect" href="https://cds.taboola.com/">
        <link rel="preconnect" href="https://ip2c.org/">
        <link rel="preconnect" href="https://static.ads-twitter.com/">
        <link rel="preconnect" href="https://connect.facebook.net/">
        <link rel="preconnect" href="https://www.googletagmanager.com/">
        <link rel="preconnect" href="https://widget.caponemarket.io/">

        <link rel="preload" href="./themes/brokerkit/assets/fonts/Gilroy-Light.woff" as="font" crossorigin="anonymous">
        <link rel="preload" href="./themes/brokerkit/assets/fonts/GilroyRegular" as="font" crossorigin="anonymous">
        <link rel="preload" href="./themes/brokerkit/assets/fonts/GilroyMedium" as="font" crossorigin="anonymous">
        <link rel="preload" href="./themes/brokerkit/assets/fonts/fontello/fontelloe6cc%EF%B9%9686913304" as="font" crossorigin="anonymous">

	    <link rel="preload" href="./themes/brokerkit/assets/fonts/HelveticaNeue" as="font" crossorigin="anonymous">
        <link rel="preload" href="./themes/brokerkit/assets/fonts/HelveticaNeueBold" as="font" crossorigin="anonymous">
        <link rel="preload" href="./themes/brokerkit/assets/fonts/HelveticaNeueLight" as="font" crossorigin="anonymous">
        <link rel="preload" href="./themes/brokerkit/assets/fonts/GilroyExtraBold" as="font" crossorigin="anonymous">

	    <link rel="preload" href="./themes/brokerkit/assets/fonts/HelveticaNeueCyr-Medium.woff" as="font" crossorigin="anonymous">
	    <link rel="preload" href="./themes/brokerkit/assets/fonts/HelveticaNeue-Thin.woff" as="font" crossorigin="anonymous">

        <link href="{{ asset('assets/css/a37bdc4323115892c3891b89343a7a23-1632297961.css')}} " rel="stylesheet">
	    <script src="{{ asset('assets/js/jquery-3.6.0.min.js')}} " crossorigin="anonymous"></script>
	    <script type="text/javascript" src="{{ asset('assets/js/jquery.lazy.min.js') }} "></script>
        <script type="text/javascript" src="{{ asset('assets/js/jquery.lazy.plugins.min.js') }} "></script>
                            

                    
            </head>
    <body>
        <style>.forex-button-pandats.simple-button-pandats.spinner-button-pandats {
                border: none !important;
            }
        </style>

        
        <div class="appbanner" style="display: none;">
    <div class="container appbanner-ios">
        <div class="icon">
            <img src="{{ asset('assets/img/appbanner-logo.svg') }}  ">  
        </div>
        <div class="text">
            <div class="text-title">vertex mining exchange - stocks & trading</div>
            <div><a href="#IOS-App-Coming-Soon" target="_blank">App Coming Soon</a></div>
            <div class="stars">
                                    <img src="{{ asset('assets/img/star-on.svg') }} ">
                                    <img src="{{ asset('assets/img/star-on.svg') }} ">
                                    <img src="{{ asset('assets/css/img/star-on.svg') }} ">
                                    <img src="{{ asset('assets/img/star-on.svg') }}">
                                    <img src="{{ asset('assets/img/star-on.svg') }}">
                                            </div>
        </div>
        <div class="close">
            <a href="#" onclick="appBannerClose(); return false;"><img src="{{ asset('assets/images/appbanner-close.svg') }} "></a>
        </div>
    </div>
    <div class="container appbanner-android">
        <div class="icon">
            <img src="images/appbanner-logo.svg">
        </div>
        <div class="text">
            <div class="text-title">vertex mining exchange - stocks & trading</div>
            <div><a href="#App-Coming-Soon" target="_blank">App Coming Soon</a></div>
            <div class="stars">
                                    <img src="images/star-on.svg">
                                    <img src="images/star-on.svg">
                                    <img src="images/star-on.svg">
                                    <img src="images/star-on.svg">
                                                    <img src="images/star-off.svg">
                            </div>
        </div>
        <div class="close">
            <a href="#" onclick="appBannerClose(); return false;"><img src="images/appbanner-close.svg"></a>
        </div>
    </div>
</div>
<script type="text/javascript">
    window.addEventListener('load', (event) => {
        let iosActive = 1;
        let androidActive = 1;

        if ( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
            let appBannerClosed = localStorage.getItem('appbanner-close');
            if (appBannerClosed !== '1') {
                if (navigator.userAgent.indexOf('Android') !== -1 || navigator.userAgent.indexOf('android') !== -1) {
                    // Android
                    if (androidActive) {
                        document.querySelector('.header').style.top = '80px';
                        document.querySelector('.appbanner-ios').style.display = 'none';
                        document.querySelector('.appbanner-android').style.display = 'flex';
                        document.querySelector('.appbanner').style.display = 'block';
                    }
                } else {
                    // iOS
                    if (iosActive) {
                        document.querySelector('.header').style.top = '80px';
                        document.querySelector('.appbanner-android').style.display = 'none';
                        document.querySelector('.appbanner-ios').style.display = 'flex';
                        document.querySelector('.appbanner').style.display = 'block';
                    }
                }
            }
        }
    });
    function appBannerClose()
    {
        document.querySelector('.header').style.top = '0';
        localStorage.setItem('appbanner-close', '1');
        document.querySelector('.appbanner').style.display = 'none';
    }
</script>
        
        <header class="header">
    <div class="hamburger hamburger_white">
        <div class="hamburger__box">
            <div class="hamburger__inner"></div>
        </div>
    </div>

    <a href="/" class="header__logo header__logo_light">
        <img class="header__logo-desktop" src="images/logo.svg" alt="vertex mining exchange">
        <img class="header__logo-mobile" src="images/logo-small.svg" alt="vertex mining exchange">
    </a>
    <a href="index" class="header__logo header__logo_dark">
        <img class="" src="images/logo-small-dark.svg" alt="vertex mining exchange">
    </a>
    <div class="header__content">
        <div class="header__menu-section">
            <ul class="main-menu nav nav-pills">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                            <li class="main-menu__item dropdown  ">
                    <div class="main-menu__item-dropdown">
                                                <div class="main-menu__link dropdown-toggle" data-toggle="dropdown">
                            Products
                        </div>
                                                <span class="main-menu__item-arrow dropdown-toggle"><i class="m-icon icon-down-open-big"></i></span>
                        <span class="main-menu__item-arrow main-menu__item-arrow_reverse dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                    </div>
                                        <div class="main-menu__list-wrap">
                <ul class="main-menu__list">
                                            
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="pdetail" target="_self" class="main-menu__list-link">
                                    Product Details
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="forextrading" target="_self" class="main-menu__list-link">
                                    Forex Trading
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="cfd" target="_self" class="main-menu__list-link">
                                    CFD Trading
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="stocks" target="_self" class="main-menu__list-link">
                                    Purchase Stocks
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="portfolio" target="_self" class="main-menu__list-link">
                                    Portfolio Management
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                          
                                                            </ul>
                </div>
                            </li>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                            <li class="main-menu__item dropdown  ">
                    <div class="main-menu__item-dropdown">
                                                <div class="main-menu__link dropdown-toggle" data-toggle="dropdown">
                            Markets
                        </div>
                                                <span class="main-menu__item-arrow dropdown-toggle"><i class="m-icon icon-down-open-big"></i></span>
                        <span class="main-menu__item-arrow main-menu__item-arrow_reverse dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                    </div>
                                        <div class="main-menu__list-wrap">
                <ul class="main-menu__list">
                                            
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Range of Markets
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="m_forex" target="_self" class="main-menu__inner-list-link">
                                                        Forex
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_metals" target="_self" class="main-menu__inner-list-link">
                                                        Precious Metals
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_energy" target="_self" class="main-menu__inner-list-link">
                                                        Energy Products
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_agric" target="_self" class="main-menu__inner-list-link">
                                                        Agriculture
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_stock" target="_self" class="main-menu__inner-list-link">
                                                        Stocks
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_indices" target="_self" class="main-menu__inner-list-link">
                                                        Indices
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_digital" target="_self" class="main-menu__inner-list-link">
                                                        Digital Currency
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_bonds" target="_self" class="main-menu__inner-list-link">
                                                        Bonds
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                        
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Popular Markets
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="p_eur" target="_self" class="main-menu__inner-list-link">
                                                        EUR/USD
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="p_usd" target="_self" class="main-menu__inner-list-link">
                                                        USD/JPY
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="p_gbp" target="_self" class="main-menu__inner-list-link">
                                                        GBP/USD
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="p_bitcoin" target="_self" class="main-menu__inner-list-link">
                                                        Bitcoin
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="p_dax" target="_self" class="main-menu__inner-list-link">
                                                        DAX
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="p_gold" target="_self" class="main-menu__inner-list-link">
                                                        Gold
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                            </ul>
                </div>
                            </li>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                            <li class="main-menu__item dropdown  ">
                    <div class="main-menu__item-dropdown">
                                                <div class="main-menu__link dropdown-toggle" data-toggle="dropdown">
                            Trading
                        </div>
                                                <span class="main-menu__item-arrow dropdown-toggle"><i class="m-icon icon-down-open-big"></i></span>
                        <span class="main-menu__item-arrow main-menu__item-arrow_reverse dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                    </div>
                                        <div class="main-menu__list-wrap">
                <ul class="main-menu__list">
                                            
                                                                                                                                                                                                                                                            
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Platforms
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="index" target="_self" class="main-menu__inner-list-link">
                                                        MetaTrader 4
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="index" target="_self" class="main-menu__inner-list-link">
                                                        MetaTrader 5
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="https://vertexminingexchange.com/register" target="_self" class="main-menu__inner-list-link">
                                                        vertex mining exchange Trader
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                                    
                                                                                                                                                                                                                                                                                                                                                                    
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Accounts
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="a_trading" target="_self" class="main-menu__inner-list-link">
                                                        Trading Accounts
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="a_deposit" target="_self" class="main-menu__inner-list-link">
                                                        Deposits & Withdrawals
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="a_fees" target="_self" class="main-menu__inner-list-link">
                                                        Fees
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="a_hours" target="_self" class="main-menu__inner-list-link">
                                                        Trading Hours
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="a_acess" target="_self" class="main-menu__inner-list-link">
                                                        Access the Stocks Market
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                                    
                                                                                                                                                                                                                                                                                                                                                                    
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Education
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="e_introduce" target="_self" class="main-menu__inner-list-link">
                                                        Introduction to Trading
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="e_how" target="_self" class="main-menu__inner-list-link">
                                                        How to start trading
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="e_glossary" target="_self" class="main-menu__inner-list-link">
                                                        Glossary
                                                    </a>
                                                </li>
                                                                                                                                                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="e_pratical" target="_self" class="main-menu__inner-list-link">
                                                        Practical Traders
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                                    
                                                                                                                                                                                                        
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Tools
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="t_economic" target="_self" class="main-menu__inner-list-link">
                                                        Economic Calendar
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="t_leverage" target="_self" class="main-menu__inner-list-link">
                                                        Leverage & Margin
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                            </ul>
                </div>
                            </li>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                            <li class="main-menu__item dropdown  ">
                    <div class="main-menu__item-dropdown">
                                                <div class="main-menu__link dropdown-toggle" data-toggle="dropdown">
                            vertex mining exchange                        </div>
                                                <span class="main-menu__item-arrow dropdown-toggle"><i class="m-icon icon-down-open-big"></i></span>
                        <span class="main-menu__item-arrow main-menu__item-arrow_reverse dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                    </div>
                                        <div class="main-menu__list-wrap">
                <ul class="main-menu__list">
                                            
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="whytrade" target="_self" class="main-menu__list-link">
                                    Why Trade with vertex mining exchange                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="contact" target="_self" class="main-menu__list-link">
                                    Contact Us
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="faq" target="_self" class="main-menu__list-link">
                                    FAQ
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="tradesec" target="_self" class="main-menu__list-link">
                                    Trader Security
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <!--<li class="main-menu__list-item  ">
                                                                <a href="/en/legal" target="_self" class="main-menu__list-link">
                                    Legal
                                </a>
                                                                                            </li>-->
                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                        
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Market News
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="news_needtoknow" target="_self" class="main-menu__inner-list-link">
                                                        What You Need To know
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="news_elon" target="_self" class="main-menu__inner-list-link">
                                                        Elon Musk – The Success Story
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="news_learn" target="_self" class="main-menu__inner-list-link">
                                                        Learn Elon Musk’s Secrets To Success
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="news_doyouknow" target="_self" class="main-menu__inner-list-link">
                                                        Do you know about these companies founded by Elon Musk?
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="news_amazon" target="_self" class="main-menu__inner-list-link">
                                                        Amazon is planning to accept Bitcoin payments.
                                                    </a>
                                                </li>
                                                                                                                                                                                                            </ul>
                                </div>
                                                            </li>
                                                            </ul>
                </div>
                            </li>
            </ul>
        </div>

        <div class="lang-switch">
    <div class="lang-switch__current">
                <div class="lang-switch__current-flag" style="background-image: url(images/en.png)"></div>
        en
    </div>
    <div class="lang-switch__list">
                                        <a class="lang-switch__list-item" href="#" data-request="onSwitchLocale" data-request-data="locale: 'de'">
            de
                    </a>
                    </div>

</div>
        
        <panda-forex-login show-logout="false"></panda-forex-login>
        <a href="https://vertexminingexchange.com/login" class="login-link">Login</a>
        <a href="https://vertexminingexchange.com/register" class="sign-up-btn">Sign up</a>

            </div>

    <div class="header__mobile-menu">
        <div class="lang-switch">
    <div class="lang-switch__current">
                <div class="lang-switch__current-flag" style="background-image: url(images/en.png)"></div>
        en
    </div>
    <div class="lang-switch__list">
                                        <a class="lang-switch__list-item" href="#" data-request="onSwitchLocale" data-request-data="locale: 'de'">
            de
                    </a>
                    </div>

</div>
        <div class="header__mobile-menu-btns">
            <a href="https://vertexminingexchange.com/login" class="login-link">Login</a>

            <!--            <panda-forex-login show-logout="false" redirect-after-login=""></panda-forex-login>-->
            <a href="https://vertexminingexchange.com/login" class="log-in-btn">Log In</a>
            <a href="https://vertexminingexchange.com/register" class="sign-up-btn">Sign up</a>
        </div>

        <ul class="main-menu main-menu_mobile">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                            <li class="main-menu__item dropdown  ">
                    <div class="main-menu__item-dropdown">
                                                <div class="main-menu__link dropdown-toggle" data-toggle="dropdown">
                            Products
                        </div>
                                                <span class="main-menu__item-arrow dropdown-toggle"><i class="m-icon icon-down-open-big"></i></span>
                        <span class="main-menu__item-arrow main-menu__item-arrow_reverse dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                    </div>
                                        <div class="main-menu__list-wrap">
                <ul class="main-menu__list">
                                            
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="pdetail" target="_self" class="main-menu__list-link">
                                    Product Details
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="forextrading" target="_self" class="main-menu__list-link">
                                    Forex Trading
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="cfd" target="_self" class="main-menu__list-link">
                                    CFD Trading
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="stocks" target="_self" class="main-menu__list-link">
                                    Purchase Stocks
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="portfolio" target="_self" class="main-menu__list-link">
                                    Portfolio Management
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            
                                                            </ul>
                </div>
                            </li>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                            <li class="main-menu__item dropdown  ">
                    <div class="main-menu__item-dropdown">
                                                <div class="main-menu__link dropdown-toggle" data-toggle="dropdown">
                            Markets
                        </div>
                                                <span class="main-menu__item-arrow dropdown-toggle"><i class="m-icon icon-down-open-big"></i></span>
                        <span class="main-menu__item-arrow main-menu__item-arrow_reverse dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                    </div>
                                        <div class="main-menu__list-wrap">
                <ul class="main-menu__list">
                                            
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Range of Markets
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="m_forex" target="_self" class="main-menu__inner-list-link">
                                                        Forex
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_metals" target="_self" class="main-menu__inner-list-link">
                                                        Precious Metals
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_energy" target="_self" class="main-menu__inner-list-link">
                                                        Energy Products
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_agric" target="_self" class="main-menu__inner-list-link">
                                                        Agriculture
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_stock" target="_self" class="main-menu__inner-list-link">
                                                        Stocks
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_indices" target="_self" class="main-menu__inner-list-link">
                                                        Indices
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_digital" target="_self" class="main-menu__inner-list-link">
                                                        Digital Currency
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="m_bonds" targetm_bonds="_self" class="main-menu__inner-list-link">
                                                        Bonds
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                        
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Popular Markets
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="p_eur" target="_self" class="main-menu__inner-list-link">
                                                        EUR/USD
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="p_usd" target="_self" class="main-menu__inner-list-link">
                                                        USD/JPY
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="p_gbp" target="_self" class="main-menu__inner-list-link">
                                                        GBP/USD
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="p_bitcoin" target="_self" class="main-menu__inner-list-link">
                                                        Bitcoin
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="p_dax" target="_self" class="main-menu__inner-list-link">
                                                        DAX
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="p_gold" target="_self" class="main-menu__inner-list-link">
                                                        Gold
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                            </ul>
                </div>
                            </li>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                            <li class="main-menu__item dropdown  ">
                    <div class="main-menu__item-dropdown">
                                                <div class="main-menu__link dropdown-toggle" data-toggle="dropdown">
                            Trading
                        </div>
                                                <span class="main-menu__item-arrow dropdown-toggle"><i class="m-icon icon-down-open-big"></i></span>
                        <span class="main-menu__item-arrow main-menu__item-arrow_reverse dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                    </div>
                                        <div class="main-menu__list-wrap">
                <ul class="main-menu__list">
                                            
                                                                                                                                                                                                                                                            
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Platforms
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="index" target="_self" class="main-menu__inner-list-link">
                                                        MetaTrader 4
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="index" target="_self" class="main-menu__inner-list-link">
                                                        MetaTrader 5
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="https://moneyroute-exchange.com/account" target="_self" class="main-menu__inner-list-link">
                                                        vertex mining exchange Trader
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                                    
                                                                                                                                                                                                                                                                                                                                                                    
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Accounts
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="a_trading" target="_self" class="main-menu__inner-list-link">
                                                        Trading Accounts
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="a_deposit" target="_self" class="main-menu__inner-list-link">
                                                        Deposits & Withdrawals
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="a_fees" target="_self" class="main-menu__inner-list-link">
                                                        Fees
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="a_hours" target="_self" class="main-menu__inner-list-link">
                                                        Trading Hours
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="a_acess" target="_self" class="main-menu__inner-list-link">
                                                        Access the Stocks Market
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                                    
                                                                                                                                                                                                                                                                                                                                                                    
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Education
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="e_introduce" target="_self" class="main-menu__inner-list-link">
                                                        Introduction to Trading
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="e_how" target="_self" class="main-menu__inner-list-link">
                                                        How to start trading
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="e_glossary" target="_self" class="main-menu__inner-list-link">
                                                        Glossary
                                                    </a>
                                                </li>
                                                                                                                                                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="e_pratical" target="_self" class="main-menu__inner-list-link">
                                                        Practical Traders
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                                    
                                                                                                                                                                                                        
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Tools
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="t_economic" target="_self" class="main-menu__inner-list-link">
                                                        Economic Calendar
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="t_leverage" target="_self" class="main-menu__inner-list-link">
                                                        Leverage & Margin
                                                    </a>
                                                </li>
                                                                                                                        </ul>
                                </div>
                                                            </li>
                                                            </ul>
                </div>
                            </li>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                            <li class="main-menu__item dropdown  ">
                    <div class="main-menu__item-dropdown">
                                                <div class="main-menu__link dropdown-toggle" data-toggle="dropdown">
                            vertex mining exchange                        </div>
                                                <span class="main-menu__item-arrow dropdown-toggle"><i class="m-icon icon-down-open-big"></i></span>
                        <span class="main-menu__item-arrow main-menu__item-arrow_reverse dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                    </div>
                                        <div class="main-menu__list-wrap">
                <ul class="main-menu__list">
                                            
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="whytrade" target="_self" class="main-menu__list-link">
                                    Why Trade with vertex mining exchange                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="contact" target="_self" class="main-menu__list-link">
                                    Contact Us
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="faq" target="_self" class="main-menu__list-link">
                                    FAQ
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <li class="main-menu__list-item  ">
                                                                <a href="tradesec" target="_self" class="main-menu__list-link">
                                    Trader Security
                                </a>
                                                                                            </li>
                                                                    
                                                                                                
                            <!--<li class="main-menu__list-item  ">
                                                                <a href="/en/legal" target="_self" class="main-menu__list-link">
                                    Legal
                                </a>
                                                                                            </li>-->
                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                        
                            <li class="main-menu__list-item  ">
                                                                <div class="main-menu__list-dropdown">
                                                                        <div class="main-menu__list-link dropdown-toggle">
                                        Market News
                                    </div>
                                                                        <span class="main-menu__list-arrow dropdown-toggle"><i class="m-icon icon-right-open-big"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_mobile dropdown-toggle"><i class="m-icon icon-right-open"></i></span>
                                    <span class="main-menu__list-arrow main-menu__list-arrow_reverse dropdown-toggle"><i class="m-icon icon-down-open"></i></span>
                                </div>
                                                                                                <div class="main-menu__inner-list-wrap">
                                    <ul class="main-menu__inner-list ">
                                                                                                                                    <li class="main-menu__inner-list-item ">
                                                    <a href="news_needtoknow" target="_self" class="main-menu__inner-list-link">
                                                        What You Need To know
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="news_elon" target="_self" class="main-menu__inner-list-link">
                                                        Elon Musk – The Success Story
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="news_learn" target="_self" class="main-menu__inner-list-link">
                                                        Learn Elon Musk’s Secrets To Success
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="news_doyouknow" target="_self" class="main-menu__inner-list-link">
                                                        Do you know about these companies founded by Elon Musk?
                                                    </a>
                                                </li>
                                                                                                                                                                                <li class="main-menu__inner-list-item ">
                                                    <a href="news_amazon" target="_self" class="main-menu__inner-list-link">
                                                        Amazon is planning to accept Bitcoin payments.
                                                    </a>
                                                </li>
                                                                                                                                                                                                            </ul>
                                </div>
                                                            </li>
                                                            </ul>
                </div>
                            </li>
            </ul>
    </div>
</header>